library(cheddar)
# I. Food web properties calculation using cheddar####
#1. sum 6 ponds of each treatment####
#1.1 Load sum web separately for each treatment
Pond_C <- LoadCommunity('Pathway of the sum web')
Pond_C

CPS(Pond_C, c('NumberOfTrophicLinks',
             'NumberOfNodes','DirectedConnectance','Omnivory','NvMSlope')) # Community properties

collection0 <- CommunityCollection(list(Pond_C,Pond_WNI))
table0 <- NvMTriTrophicTable_P(collection0)#NvMTriTrophicTable_P function is in the below section
table0

NPS(Pond0) # Node properties
TLPS(Pond0)# Trophic links
SumBiomassByClass(Pond0)#total biomass in each ??category?? node property
SumBiomassByClass(Pond0, class='functional.group') #total biomass in each ??functional.group??
Trophicpond0 <- NvMTriTrophicStatistics(Pond0)
Trophicpond0

#1.2 Plots#
#Example of Ponds_C
PondCPlotNvM <- function()
{
  par(mfcol=c(1, 1),
      mgp=c(1.5, 0.5, 0),  # Axes - axis title, axis labels, axis line
      mar=c(3,3,2,1))      # Margins - bottom, left, top, right
  PlotNvM(Pond_C,node.labels='node',
          cex.main=1, # size of the title 'Pond47'
          cex.axis=0.5,
          pch = 21, #Point shape, as circle
          cex =(log(NPS(Pond_C)$Totalbiomass+1))^(1/2), lwd = 1, col = "black",
          xlim=c(-12,3), ylim=c(0,14))
  models <- NvMLinearRegressions(Pond_C)
  colours <- PlotLinearModels(models,lwd=1.5)}
PondCPlotNvM()
#PondCPlotNvM <- PondCPlotNvM()
tiff("PondCPlotNvM.tiff", width = 2.5, height = 2.5, units = 'in', res = 300, compression = 'none')
PondCPlotNvM()
dev.off()


# 2. load 48 ponds####
Foodweb2021 <- LoadCollection('Pathway of all food webs')
Foodweb2021
Foodweb2021 <- OrderCollection(Foodweb2021,'Pondcode')
CollectionCPS(Foodweb2021)

Foodweb2021[['Pond1']]

#2.0 Plots####
tiff("FoodwebPlot1.tiff", width = 10, height = 14, units = 'in', res = 300, compression = 'none')

par(mfrow=c(8,6), mar=c(1,1,1,1))
for(i in 1:length(Foodweb2021)){
  web <- Foodweb2021[[i]]
  bio <- log(NPS(web)$Totalbiomass+1)^(1/2)   ## Not sure why you raise this to the power of 0.5
  PlotWebByLevel(web, pch=21, cex=bio)
}


dev.off()



#2.1 food web properties statistics #####
Foodwebproperties <- CollectionCPS(Foodweb2021, c('Temp','Eutroph','Pesticide',
                                              'NumberOfTrophicLinks',
                                              'NumberOfNodes','DirectedConnectance','Omnivory','NvMSlope',
                                             'ShortWeightedTrophicLevel','title' ))
library(tidyverse)
Foodwebproperties <- Foodwebproperties %>% rename("Pondcode" = "title")
Foodwebproperties

library(plyr)
Foodwebproperties$MeanTrophicLevel <- rowMeans(Foodwebproperties[9:22],na.rm = T)
Foodwebproperties

library(ggplot2)
#construct interactions
Foodwebproperties$Temp_Pesticide <- interaction(Foodwebproperties$Temp, Foodwebproperties$Pesticide)
Foodwebproperties$Eutroph_Pesticide <- interaction(Foodwebproperties$Eutroph, Foodwebproperties$Pesticide)
Foodwebproperties$Treatment <- interaction(Foodwebproperties$Temp,Foodwebproperties$Eutroph, Foodwebproperties$Pesticide)


##2.1.1 Number of nodes####
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
Nodes_Cal <- ddply(Foodwebproperties, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(NumberOfNodes)), 
                           mean = mean(NumberOfNodes,na.rm=TRUE),
                           sd = sd(NumberOfNodes,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Nodes_Cal

Nodes_Cal$Treatment <- interaction(Nodes_Cal$Eutroph, Nodes_Cal$Pesticide,Nodes_Cal$Temp)
Nodes_Cal$Treatment1 <- interaction(Nodes_Cal$Eutroph, Nodes_Cal$Pesticide)
Nodes_Cal$Treatment1 <- revalue(Nodes_Cal$Treatment1, c("0.0"="0", "E.0"="N", "0.I"="I", "E.I"="N*I"))#Rename names

Nodes_plot <- ggplot(data=Nodes_Cal, aes(x = Treatment1, y = mean,fill=Temp)) + #
  geom_errorbar(aes( ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  scale_fill_manual(values = c("#00CCFF","red"))+
  coord_cartesian(ylim = c(10, 13))+
  xlab("Treatments") + labs (y = expression(bold(Nodes))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)
Nodes_plot

tiff("Nodes_plot.tiff", width = 2.5, height = 2, units = 'in', res = 300, compression = 'none')
Nodes_plot
dev.off()

m1 <- glm(NumberOfNodes ~ Pesticide * Temp * Eutroph, data = Foodwebproperties,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
library(car)
Anova(m1, type = "II")


library(MuMIn)
# Fit the full model
options(na.action = "na.fail")

full_model <- lm(NumberOfNodes ~ Pesticide * Temp * Eutroph, data = Foodwebproperties)

# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)

# Display the best model summary
summary(best_model)

m1 <- glm(NumberOfNodes ~ Temp, data = Foodwebproperties,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

library(effectsize)

m_interaction2 <- lm(
  NumberOfNodes ~ Temp, data = Foodwebproperties,
  contrasts = list(
    Temp = "contr.sum",
    Pesticide = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, type = 2))

##2.1.2 Number of Trophic links####
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
Links_Cal <- ddply(Foodwebproperties, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(NumberOfTrophicLinks)), 
                   mean = mean(NumberOfTrophicLinks,na.rm=TRUE),
                   sd = sd(NumberOfTrophicLinks,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Links_Cal

Links_Cal$Treatment <- interaction(Links_Cal$Eutroph, Links_Cal$Pesticide,Links_Cal$Temp)
Links_Cal$Treatment1 <- interaction(Links_Cal$Eutroph, Links_Cal$Pesticide)
Links_Cal$Treatment1 <- revalue(Links_Cal$Treatment1, c("0.0"="0", "E.0"="N", "0.I"="I", "E.I"="N*I"))#Rename names

Links_plot <- ggplot(data=Links_Cal, aes(x = Treatment1, y = mean,fill=Temp)) + #
  geom_errorbar(aes( ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  scale_fill_manual(values = c("#00CCFF","red")) +
  coord_cartesian(ylim = c(10, 35))+
  xlab("Treatments") + labs (y = expression(bold(Links))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)
Links_plot

tiff("Links_plot.tiff", width = 2.5, height = 2, units = 'in', res = 300, compression = 'none')
Links_plot
dev.off()

m1 <- glm(log(NumberOfTrophicLinks) ~ Pesticide * Temp * Eutroph, data = Foodwebproperties,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
library(car)
Anova(m1, type = "III")


library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- lm(log(NumberOfTrophicLinks) ~ Pesticide * Temp * Eutroph, data = Foodwebproperties)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- glm(log(NumberOfTrophicLinks) ~ Temp, data = Foodwebproperties,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

library(effectsize)

m_interaction2 <- lm(
  log(NumberOfTrophicLinks) ~ Temp, data = Foodwebproperties,
  contrasts = list(
    Temp = "contr.sum",
    Pesticide = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, type = 2))

##2.1.3 Connectance ####
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
Connectance_Cal <- ddply(Foodwebproperties, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(DirectedConnectance)), 
                   mean = mean(DirectedConnectance,na.rm=TRUE),
                   sd = sd(DirectedConnectance,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Connectance_Cal

Connectance_Cal$Treatment <- interaction(Connectance_Cal$Eutroph, Connectance_Cal$Pesticide,Connectance_Cal$Temp)
Connectance_Cal$Treatment1 <- interaction(Connectance_Cal$Eutroph, Connectance_Cal$Pesticide)
Connectance_Cal$Treatment1 <- revalue(Connectance_Cal$Treatment1, c("0.0"="0", "E.0"="N", "0.I"="I", "E.I"="N*I"))#Rename names

Connectance_plot <- ggplot(data=Connectance_Cal, aes(x = Treatment1, y = mean,fill=Temp)) + #
  geom_errorbar(aes( ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  scale_fill_manual(values = c("#00CCFF","red")) +
  coord_cartesian(ylim = c(0.10, 0.23))+
  xlab("Treatments") + labs (y = expression(bold(Connectance))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)
Connectance_plot

tiff("Connectance_plot.tiff", width = 2.5, height = 2, units = 'in', res = 300, compression = 'none')
Connectance_plot
dev.off()

m1 <- glm(DirectedConnectance ~ Pesticide * Temp * Eutroph, data = Foodwebproperties,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
library(car)
Anova(m1, type = "II")


library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- lm(DirectedConnectance ~ Pesticide * Temp * Eutroph, data = Foodwebproperties)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- lm(DirectedConnectance ~ Pesticide * Temp, data = Foodwebproperties)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

library(effectsize)

m_interaction2 <- lm(
  DirectedConnectance ~ Pesticide * Temp, data = Foodwebproperties,
  contrasts = list(
    Temp = "contr.sum",
    Pesticide = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, type = 2))

##2.1.4 Omnivory ####
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
Omnivory_Cal <- ddply(Foodwebproperties, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(Omnivory)), 
                         mean = mean(Omnivory,na.rm=TRUE),
                         sd = sd(Omnivory,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Omnivory_Cal

Omnivory_Cal$Treatment <- interaction(Omnivory_Cal$Eutroph, Omnivory_Cal$Pesticide,Omnivory_Cal$Temp)
Omnivory_Cal$Treatment1 <- interaction(Omnivory_Cal$Eutroph, Omnivory_Cal$Pesticide)
Omnivory_Cal$Treatment1 <- revalue(Omnivory_Cal$Treatment1, c("0.0"="0", "E.0"="N", "0.I"="I", "E.I"="N*I"))#Rename names

Omnivory_plot <- ggplot(data=Omnivory_Cal, aes(x = Treatment1, y = mean,fill=Temp)) + #
  geom_errorbar(aes( ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  scale_fill_manual(values = c("#00CCFF","red")) +
  coord_cartesian(ylim = c(0.06, 0.32))+
  xlab("Treatments") + labs (y = expression(bold(Omnivory))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)
Omnivory_plot

tiff("Omnivory_plot.tiff", width = 2.5, height = 2, units = 'in', res = 300, compression = 'none')
Omnivory_plot
dev.off()

m1 <- glm(log(Omnivory+0.1) ~ Pesticide * Temp * Eutroph, data = Foodwebproperties,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
library(car)
Anova(m1, type = "II")

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- lm(log(Omnivory+0.1) ~ Pesticide * Temp * Eutroph, data = Foodwebproperties)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- lm(log(Omnivory+0.1) ~ Pesticide + Temp, data = Foodwebproperties)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

library(effectsize)

m_interaction2 <- lm(
  log(Omnivory+0.1) ~ Pesticide + Temp,data = Foodwebproperties,
  contrasts = list(
    Temp = "contr.sum",
    Pesticide = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, type = 2))

##2.1.5 Mean trophic level ####
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
MeanTrophicLevel_Cal <- ddply(Foodwebproperties, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(MeanTrophicLevel)), 
                      mean = mean(MeanTrophicLevel,na.rm=TRUE),
                      sd = sd(MeanTrophicLevel,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
MeanTrophicLevel_Cal

MeanTrophicLevel_Cal$Treatment <- interaction(MeanTrophicLevel_Cal$Eutroph, MeanTrophicLevel_Cal$Pesticide,MeanTrophicLevel_Cal$Temp)
MeanTrophicLevel_Cal$Treatment1 <- interaction(MeanTrophicLevel_Cal$Eutroph, MeanTrophicLevel_Cal$Pesticide)
MeanTrophicLevel_Cal$Treatment1 <- revalue(MeanTrophicLevel_Cal$Treatment1, c("0.0"="0", "E.0"="N", "0.I"="I", "E.I"="N*I"))#Rename names

MeanTrophicLevel_plot <- ggplot(data=MeanTrophicLevel_Cal, aes(x = Treatment1, y = mean,fill=Temp)) + #
  geom_errorbar(aes( ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  scale_fill_manual(values = c("#00CCFF","red")) +
  coord_cartesian(ylim = c(1.69, 1.93))+
  xlab("Treatments") + labs (y = expression(bold(Mean~trophic~level))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)
MeanTrophicLevel_plot

tiff("MeanTrophicLevel_plot.tiff", width = 2.5, height = 2, units = 'in', res = 300, compression = 'none')
MeanTrophicLevel_plot
dev.off()

m1 <- glm(log(MeanTrophicLevel) ~ Pesticide * Temp * Eutroph, data = Foodwebproperties,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
library(car)
Anova(m1, type = "II")

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- lm(log(MeanTrophicLevel) ~ Pesticide * Temp * Eutroph, data = Foodwebproperties)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- lm(log(MeanTrophicLevel) ~ Pesticide * Temp, data = Foodwebproperties)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

library(effectsize)

m_interaction2 <- lm(
  log(MeanTrophicLevel) ~ Pesticide * Temp, data = Foodwebproperties,
  contrasts = list(
    Temp = "contr.sum",
    Pesticide = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, type = 2))

##2.1.6 NvM slopes ####
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
NvMSlope_Cal <- ddply(Foodwebproperties, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(NvMSlope)), 
                              mean = mean(NvMSlope,na.rm=TRUE),
                              sd = sd(NvMSlope,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
NvMSlope_Cal

NvMSlope_Cal$Treatment <- interaction(NvMSlope_Cal$Eutroph, NvMSlope_Cal$Pesticide,NvMSlope_Cal$Temp)
NvMSlope_Cal$Treatment1 <- interaction(NvMSlope_Cal$Eutroph, NvMSlope_Cal$Pesticide)
NvMSlope_Cal$Treatment1 <- revalue(NvMSlope_Cal$Treatment1, c("0.0"="0", "E.0"="N", "0.I"="I", "E.I"="N*I"))#Rename names

NvMSlope_plot <- ggplot(data=NvMSlope_Cal, aes(x = Treatment1, y = mean+1,fill=Temp)) + #
  geom_errorbar(aes( ymax = mean +1 + se, ymin = mean+1-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge2", alpha=1, width = 0.8) +
  scale_fill_manual(values = c("#00CCFF","red")) +
  scale_y_continuous(labels = function(x) x-1) + # subtract 1 from y-axis labels
  coord_cartesian(ylim = c(0.02, 0.24))+ # add 1 to mean and plot first
  #coord_cartesian(ylim = c(-0.98, -0.76))+
  xlab("Treatments") + labs (y = expression(bold(NvM~slope))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)
NvMSlope_plot

tiff("NvMSlope_plot.tiff", width = 2.5, height = 2, units = 'in', res = 300, compression = 'none')
NvMSlope_plot
dev.off()

m1 <- glm(NvMSlope ~ Pesticide * Temp * Eutroph, data = Foodwebproperties,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
#m1 <- lm(NvMSlope ~ Pesticide * Temp * Eutroph, data = Foodwebproperties)#[which(Macrophyte$Eutroph == "1"),]

hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
library(car)
Anova(m1, type = "II")
anova(m1, test = "F")

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- glm(NvMSlope ~ Pesticide * Temp * Eutroph, data = Foodwebproperties,family=gaussian)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- glm(NvMSlope ~ Pesticide * Eutroph, data = Foodwebproperties,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
library(car)
Anova(m1, type = "II")

library(effectsize)

m_interaction2 <- lm(
  NvMSlope ~ Pesticide * Eutroph, data = Foodwebproperties,
  contrasts = list(
    Eutroph = "contr.sum",
    Pesticide = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, type = 2))

#2.2 NvMTriTrophicStatistics analysis####

#NvMtrophic2021 <- NvMTriTrophicTable(Foodweb2021)
#NvMtrophic2021
#write.csv(NvMtrophic2021,"C:/Users/PYZ/Desktop/2021 Mesocosm/Data/R food web analysis/Mesocosm2021/NvMtrophic2021.csv", row.names = T)

#add mean link angle function in the plot####
NvMTriTrophicTable_P <-function (collection) 
{
  if (!is.CommunityCollection(collection)) 
    stop("Not a CommunityCollection")
  UnsafeMean <- function(x) {
    ifelse(is.null(x), NA, mean(x))
  }
  res <- lapply(collection, function(community) {
    unadjusted <- community
    community <- RemoveNodes(community, remove = with(NPS(community), 
                                                      node[is.na(M) | is.na(N)]))
    community <- RemoveCannibalisticLinks(community)
    community <- RemoveIsolatedNodes(community)
    tts <- NvMTriTrophicStatistics(community)
    lp <- tts[["links"]]
    tncp <- tts[["three.node.chains"]]
    tcp <- tts[["trophic.chains"]]
    community.span <- diff(range(Log10M(community))) + diff(range(Log10N(community)))
    wiggling <- mean(tcp$sum.chain.length)/mean(tcp$chain.span)
    return(c(`Mean link length` = mean(lp$length), 
             `Mean link angle` = mean(lp$angle),
             `Mean L upper` = UnsafeMean(tncp$Lupper), `Mean L lower` = UnsafeMean(tncp$Llower), 
             `2 x mean link length` = 2 * mean(lp$length), 
             `Mean 2-span` = UnsafeMean(tncp$two.span), 
             `Mean L upper + L lower` = UnsafeMean(tncp$Lupper + 
                                                     tncp$Llower), `2 x mean link length / mean 2-span` = 2 * 
               mean(lp$length)/UnsafeMean(tncp$two.span), `Mean L upper + L lower/ mean 2-span` = UnsafeMean(tncp$Lupper + 
                                                                                                               tncp$Llower)/UnsafeMean(tncp$two.span), `Mean count chain length` = mean(tcp$count.chain.length), 
             `Mean count chain length x mean link length` = mean(tcp$count.chain.length) * 
               mean(lp$length), `Community span` = community.span, 
             `Mean count chain length x mean link length / community span` = mean(tcp$count.chain.length) * 
               mean(lp$length)/community.span, `Mean sum chain lengths` = mean(tcp$sum.chain.length), 
             `Mean chain span` = mean(tcp$chain.span), `Mean chain span / community span` = mean(tcp$chain.span)/community.span, 
             `Mean sum chain lengths / mean chain span` = mean(tcp$sum.chain.length)/mean(tcp$chain.span), 
             `Mean sum chain lengths / community span` = mean(tcp$sum.chain.length)/community.span, 
             L = NumberOfTrophicLinks(community), `S^2` = NumberOfNodes(community)^2, 
             `L/S^2` = DirectedConnectance(community), `L/S` = LinkageDensity(community), 
             L = NumberOfTrophicLinks(unadjusted), `S^2` = NumberOfNodes(unadjusted)^2, 
             `L/S^2` = DirectedConnectance(unadjusted), 
             `L/S` = LinkageDensity(unadjusted)))
  })
  res <- do.call("cbind", res)
  colnames(res) <- names(collection)
  return(res)
}

NvMtrophic2021_P <- NvMTriTrophicTable_P(Foodweb2021)
NvMtrophic2021 <- as.data.frame(t(NvMtrophic2021_P))
NvMtrophic2021$Pondcode <- rownames(NvMtrophic2021)
NvMtrophic2021


##2.2.0 merge link data####

Linksanalysis2021<- merge(Foodwebproperties,NvMtrophic2021,by="Pondcode" )
#write.csv(Linksanalysis2021,"C:/Users/PYZ/Desktop/2021 Mesocosm/Data/R food web analysis/Mesocosm2021/Linksanalysis2021.csv", row.names = T)
colnames(Linksanalysis2021)[colnames(Linksanalysis2021) == "Mean link length"] <- "Mean.link.length"
colnames(Linksanalysis2021)[colnames(Linksanalysis2021) == "Mean link angle"] <- "Mean.link.angle"

Linksanalysis2021$Temp <- as.factor(Linksanalysis2021$Temp)
Linksanalysis2021$Eutroph <- as.factor(Linksanalysis2021$Eutroph)
Linksanalysis2021$Pesticide <- as.factor(Linksanalysis2021$Pesticide)

#construct interactions
Linksanalysis2021$Temp_Pesticide <- interaction(Linksanalysis2021$Temp, Linksanalysis2021$Pesticide)
Linksanalysis2021$Eutroph_Pesticide <- interaction(Linksanalysis2021$Eutroph, Linksanalysis2021$Pesticide)
Linksanalysis2021$Treatment <- interaction(Linksanalysis2021$Temp,Linksanalysis2021$Eutroph, Linksanalysis2021$Pesticide)
str(Linksanalysis2021)
head(Linksanalysis2021)
head(Linksanalysis2021$`Mean link length`)

library(ggplot2)
##2.2.1 mean link length####
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
Mean.link.length_Cal <- ddply(Linksanalysis2021, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(Mean.link.length)), 
                      mean = mean(Mean.link.length,na.rm=TRUE),
                      sd = sd(Mean.link.length,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Mean.link.length_Cal

Mean.link.length_Cal$Treatment <- interaction(Mean.link.length_Cal$Eutroph, Mean.link.length_Cal$Pesticide,Mean.link.length_Cal$Temp)
Mean.link.length_Cal$Treatment1 <- interaction(Mean.link.length_Cal$Eutroph, Mean.link.length_Cal$Pesticide)
Mean.link.length_Cal$Treatment1 <- revalue(Mean.link.length_Cal$Treatment1, c("0.0"="0", "E.0"="N", "0.I"="I", "E.I"="N*I"))#Rename names

Mean.link.length_plot <- ggplot(data=Mean.link.length_Cal, aes(x = Treatment1, y = mean,fill=Temp)) + #
  geom_errorbar(aes( ymax = mean+ se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge2", alpha=1, width = 0.8) +
  scale_fill_manual(values = c("#00CCFF","red")) +
  coord_cartesian(ylim = c(8, 15))+
  xlab("Treatments") + labs (y = expression(bold(Mean~link~length))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)
Mean.link.length_plot

tiff("Mean.link.length_plot.tiff", width = 2.5, height = 2, units = 'in', res = 300, compression = 'none')
Mean.link.length_plot
dev.off()

m1 <- glm(Mean.link.length ~ Pesticide * Temp * Eutroph, data = Linksanalysis2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
library(car)
Anova(m1, type = "II")

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- glm(Mean.link.length ~ Pesticide * Temp * Eutroph, data = Linksanalysis2021,family=gaussian)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- glm(Mean.link.length ~ Pesticide + Temp + Eutroph, data = Linksanalysis2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

library(effectsize)

m_interaction2 <- lm(
  Mean.link.length ~ Pesticide + Temp + Eutroph, data = Linksanalysis2021,
  contrasts = list(
    Temp = "contr.sum",
    Eutroph = "contr.sum",
    Pesticide = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, type = 2))

##2.2.2 mean link angle####
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
Mean.link.angle_Cal <- ddply(Linksanalysis2021, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(Mean.link.angle)), 
                              mean = mean(Mean.link.angle,na.rm=TRUE),
                              sd = sd(Mean.link.angle,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Mean.link.angle_Cal

Mean.link.angle_Cal$Treatment <- interaction(Mean.link.angle_Cal$Eutroph, Mean.link.angle_Cal$Pesticide,Mean.link.angle_Cal$Temp)
Mean.link.angle_Cal$Treatment1 <- interaction(Mean.link.angle_Cal$Eutroph, Mean.link.angle_Cal$Pesticide)
Mean.link.angle_Cal$Treatment1 <- revalue(Mean.link.angle_Cal$Treatment1, c("0.0"="0", "E.0"="N", "0.I"="I", "E.I"="N*I"))#Rename names

Mean.link.angle_plot <- ggplot(data=Mean.link.angle_Cal, aes(x = Treatment1, y = mean+50,fill=Temp)) + #
  geom_errorbar(aes( ymax = mean+50+ se, ymin = mean+50-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge2", alpha=1, width = 0.8) +
  scale_fill_manual(values = c("#00CCFF","red")) +
  scale_y_continuous(labels = function(x) x-50) + # subtract 50 from y-axis labels
  coord_cartesian(ylim = c(2, 23))+ #first add 50 to mean to plot
  #coord_cartesian(ylim = c(-54, -30))+
  xlab("Treatments") + labs (y = expression(bold(Mean~link~angle))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)
Mean.link.angle_plot

tiff("Mean.link.angle_plot.tiff", width = 2.5, height = 2, units = 'in', res = 300, compression = 'none')
Mean.link.angle_plot
dev.off()

m1 <- glm(Mean.link.angle ~ Pesticide * Temp * Eutroph, data = Linksanalysis2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
library(car)
Anova(m1, type = "II")

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- glm(Mean.link.angle ~ Pesticide * Temp * Eutroph, data = Linksanalysis2021,family=gaussian)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- glm(Mean.link.angle ~ Pesticide * Temp, data = Linksanalysis2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

library(effectsize)

m_interaction2 <- lm(
  Mean.link.angle ~ Pesticide * Temp, data = Linksanalysis2021,
  contrasts = list(
    Temp = "contr.sum",
    Pesticide = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, type = 2))


#**Figure 2 structural properties ####
library(cowplot)
Fig2 <- plot_grid(
                  MeanTrophicLevel_plot, Connectance_plot,
                  NvMSlope_plot, Mean.link.angle_plot,
                  align = "hv",nrow = 2, ncol =2)
Fig2
tiff("Fig2.tiff", width = 5, height = 4, units = 'in', res = 300, compression = 'none')
Fig2
dev.off()

#**Supple. Fig. structural properties ####
library(cowplot)
Supplewebplot <- plot_grid(Nodes_plot, Links_plot,
                 Omnivory_plot, Mean.link.length_plot,
                 align = "hv",nrow = 2, ncol =2)
Supplewebplot
tiff("Supplewebplot.tiff", width = 5, height = 4, units = 'in', res = 300, compression = 'none')
Supplewebplot
dev.off()

#2.3 Resource and Consumer####
WebTLPS <- CollectionTLPS(Foodweb2021,c('M','N','Biomass'))
WebTLPS

WebTLPS$Con_Res_abundance <- log(WebTLPS$consumer.N/WebTLPS$resource.N)
WebTLPS$Con_Res_body <- log(WebTLPS$consumer.M /WebTLPS$resource.M)
WebTLPS$Con_Res_Biomass <- log(WebTLPS$consumer.Biomass /WebTLPS$resource.Biomass)

library(tidyverse)
WebTLPS1 <- WebTLPS %>% group_by(community) %>% dplyr::summarise(across(resource.M:Con_Res_Biomass, mean, na.rm=TRUE))
WebTLPS1 <- WebTLPS1 %>% dplyr::rename(Pondcode = community)
WebTLPS1

#merge dataframe####
Con_Res_web <-merge(WebTLPS1,Linksanalysis2021,by="Pondcode" )

library(ggplot2)
#construct interactions
Con_Res_web$Temp_Pesticide <- interaction(Con_Res_web$Temp, Con_Res_web$Pesticide)
Con_Res_web$Eutroph_Pesticide <- interaction(Con_Res_web$Eutroph, Con_Res_web$Pesticide)
Con_Res_web$Treatment <- interaction(Con_Res_web$Temp,Con_Res_web$Eutroph, Con_Res_web$Pesticide)

##2.3.1 Consumer to resource size####

library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
Con_Res_body_Cal <- ddply(Con_Res_web, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(Con_Res_body)), 
                          mean = mean(Con_Res_body,na.rm=TRUE),
                          sd = sd(Con_Res_body,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Con_Res_body_Cal

Con_Res_body_Cal$Treatment <- interaction(Con_Res_body_Cal$Eutroph, Con_Res_body_Cal$Pesticide,Con_Res_body_Cal$Temp)
Con_Res_body_Cal$Treatment1 <- interaction(Con_Res_body_Cal$Eutroph, Con_Res_body_Cal$Pesticide)
Con_Res_body_Cal$Treatment1 <- revalue(Con_Res_body_Cal$Treatment1, c("0.0"="0", "E.0"="N", "0.I"="I", "E.I"="N*I"))#Rename names

Con_Res_body_plot <- ggplot(data=Con_Res_body_Cal, aes(x = Treatment1, y = mean,fill=Temp)) + #
  geom_errorbar(aes( ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  scale_fill_manual(values = c("#00CCFF","red"))+
  coord_cartesian(ylim = c(10, 14))+
  xlab("Treatments") + labs (y = expression(bold(Consumer:resource~body~mass))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)
Con_Res_body_plot

tiff("Con_Res_body_plot.tiff", width = 3.5, height = 3, units = 'in', res = 300, compression = 'none')
Con_Res_body_plot
dev.off()

m1 <- glm(Con_Res_body ~ Pesticide * Temp * Eutroph, data = Con_Res_web,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
library(car)
Anova(m1, type = "II")


library(MuMIn)
# Fit the full model
options(na.action = "na.fail")

full_model <- lm(Con_Res_body ~ Pesticide * Temp * Eutroph, data = Con_Res_web)

# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)

# Display the best model summary
summary(best_model)

m1 <- glm(Con_Res_body ~ Eutroph, data = Con_Res_web,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

library(effectsize)

m_interaction2 <- lm(
  Con_Res_body ~ , data = Con_Res_web,
  contrasts = list(
    Temp = "contr.sum",
    Pesticide = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, type = 2))

##2.3.2 Consumer to resource abundance####

library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
Con_Res_abundance_Cal <- ddply(Con_Res_web, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(Con_Res_abundance)), 
                               mean = mean(Con_Res_abundance,na.rm=TRUE),
                               sd = sd(Con_Res_abundance,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Con_Res_abundance_Cal

Con_Res_abundance_Cal$Treatment <- interaction(Con_Res_abundance_Cal$Eutroph, Con_Res_abundance_Cal$Pesticide,Con_Res_abundance_Cal$Temp)
Con_Res_abundance_Cal$Treatment1 <- interaction(Con_Res_abundance_Cal$Eutroph, Con_Res_abundance_Cal$Pesticide)
Con_Res_abundance_Cal$Treatment1 <- revalue(Con_Res_abundance_Cal$Treatment1, c("0.0"="0", "E.0"="N", "0.I"="I", "E.I"="N*I"))#Rename names

Con_Res_abundance_plot <- ggplot(data=Con_Res_abundance_Cal, aes(x = Treatment1, y = mean+20,fill=Temp)) + #
  geom_errorbar(aes( ymax = mean +20+ se, ymin = mean+20-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  scale_fill_manual(values = c("#00CCFF","red"))+
  scale_y_continuous(labels = function(x) x-20) + # subtract 20 from y-axis labels
  coord_cartesian(ylim = c(3, 11))+
  xlab("Treatments") + labs (y = expression(bold(Consumer:resource~abundance))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)
Con_Res_abundance_plot

tiff("Con_Res_abundance_plot.tiff", width = 3.5, height = 3, units = 'in', res = 300, compression = 'none')
Con_Res_abundance_plot
dev.off()

m1 <- glm(Con_Res_abundance ~ Pesticide * Temp * Eutroph, data = Con_Res_web,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
library(car)
Anova(m1, type = "II")


library(MuMIn)
# Fit the full model
options(na.action = "na.fail")

full_model <- lm(Con_Res_abundance ~ Pesticide * Temp * Eutroph, data = Con_Res_web)

# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)

# Display the best model summary
summary(best_model)

m1 <- glm(Con_Res_abundance ~ Eutroph + Temp*Pesticide, data = Con_Res_web,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

library(effectsize)

m_interaction2 <- lm(
  Con_Res_abundance ~ Eutroph + Temp*Pesticide, data = Con_Res_web,
  contrasts = list(
    Temp = "contr.sum",
    Pesticide = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, type = 2))




##2.3.3 Consumer to resource Biomass####

library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
Con_Res_Biomass_Cal <- ddply(Con_Res_web, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(Con_Res_Biomass)), 
                             mean = mean(Con_Res_Biomass,na.rm=TRUE),
                             sd = sd(Con_Res_Biomass,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Con_Res_Biomass_Cal

Con_Res_Biomass_Cal$Treatment <- interaction(Con_Res_Biomass_Cal$Eutroph, Con_Res_Biomass_Cal$Pesticide,Con_Res_Biomass_Cal$Temp)
Con_Res_Biomass_Cal$Treatment1 <- interaction(Con_Res_Biomass_Cal$Eutroph, Con_Res_Biomass_Cal$Pesticide)
Con_Res_Biomass_Cal$Treatment1 <- revalue(Con_Res_Biomass_Cal$Treatment1, c("0.0"="0", "E.0"="N", "0.I"="I", "E.I"="N*I"))#Rename names

Con_Res_Biomass_plot <- ggplot(data=Con_Res_Biomass_Cal, aes(x = Treatment1, y = mean,fill=Temp)) + #
  geom_errorbar(aes( ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  scale_fill_manual(values = c("#00CCFF","red"))+
  #coord_cartesian(ylim = c(10, 13))+
  xlab("Treatments") + labs (y = expression(bold(Consumer:resource~biomass))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "top") #c(0.1,0.85)
Con_Res_Biomass_plot

tiff("Con_Res_Biomass_plot.tiff", width = 2.5, height = 2.5, units = 'in', res = 300, compression = 'none')
Con_Res_Biomass_plot
dev.off()

m1 <- glm(Con_Res_Biomass ~ Pesticide * Temp * Eutroph, data = Con_Res_web,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
library(car)
Anova(m1, type = "II")


library(MuMIn)
# Fit the full model
options(na.action = "na.fail")

full_model <- lm(Con_Res_Biomass ~ Pesticide * Temp * Eutroph, data = Con_Res_web)

# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)

# Display the best model summary
summary(best_model)

m1 <- glm(Con_Res_Biomass ~ Eutroph+Temp, data = Con_Res_web,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
Anova(m1)

library(effectsize)

m_interaction2 <- lm(
  Con_Res_Biomass ~ Pesticide, data = Con_Res_web,
  contrasts = list(
    Temp = "contr.sum",
    Pesticide = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, type = 2))


#2.3.4 correlations trivaiate foodweb with consumer resource####
plot(Con_Res_web$Mean.link.length ~ Con_Res_web$Con_Res_body)
plot(Con_Res_web$Mean.link.length ~ Con_Res_web$Con_Res_abundance)


plot(Con_Res_web$Mean.link.angle ~ Con_Res_web$Con_Res_body)
plot(Con_Res_web$Mean.link.angle ~ Con_Res_web$Con_Res_abundance)

##2.1.1 link length vs body mass####
library(ggplot2)

Linklength_size <- ggplot(data = Con_Res_web) +
  #geom_violin(aes(x = Level, y = C, group = Level1), scale = "count", trim = FALSE, width = 0.5, 
  #            linewidth= 0.1, fill = "#ACE0B4", position = position_dodge(width = 0.8)) +
  geom_point(aes(x = Con_Res_body, y = Mean.link.length), position = position_jitter(width = 0.1), alpha = 0.3) +
  geom_smooth(aes(x = Con_Res_body, y = Mean.link.length), method = "lm", se = T,col="#2A5783") +  # Add trend line#scale_fill_manual(values = c("#1f77b4", "#ff7f0e")) +
  #geom_errorbar(aes(ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  #geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  #scale_fill_manual(values = c("#00CCFF","red")) +
  #coord_cartesian(ylim = c(0.09, 0.24)) +
  #scale_y_continuous(limits = c(0, 3000), breaks = seq(0, 1000, 2000))+
  xlab("log(consumer:resource body size)") + labs (y = expression(bold(Mean~link~length))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "top") #c(0.1,0.85)
Linklength_size
tiff("Linklength_size.tiff", width = 3.5, height = 3, units = 'in', res = 300, compression = 'none')
Linklength_size
dev.off()

Linklength_abundance <- ggplot(data = Con_Res_web) +
  #geom_violin(aes(x = Level, y = C, group = Level1), scale = "count", trim = FALSE, width = 0.5, 
  #            linewidth= 0.1, fill = "#ACE0B4", position = position_dodge(width = 0.8)) +
  geom_point(aes(x = Con_Res_abundance, y = Mean.link.length), position = position_jitter(width = 0.1), alpha = 0.3) +
  geom_smooth(aes(x = Con_Res_abundance, y = Mean.link.length), method = "lm", se = T,col="#2A5783") +  # Add trend line#scale_fill_manual(values = c("#1f77b4", "#ff7f0e")) +
  #geom_errorbar(aes(ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  #geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  #scale_fill_manual(values = c("#00CCFF","red")) +
  #coord_cartesian(ylim = c(0.09, 0.24)) +
  #scale_y_continuous(limits = c(0, 3000), breaks = seq(0, 1000, 2000))+
  xlab("log(consumer:resource abundance)") + labs (y = expression(bold(Mean~link~length))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "top") #c(0.1,0.85)
Linklength_abundance
tiff("Linklength_abundance.tiff", width = 3.5, height = 3, units = 'in', res = 300, compression = 'none')
Linklength_abundance
dev.off()

m1 <- lm(Mean.link.length ~ Con_Res_abundance + Con_Res_body, data=Con_Res_web)#
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

##2.1.2 link angle vs body mass####
library(ggplot2)

Linkangle_size <- ggplot(data = Con_Res_web) +
  #geom_violin(aes(x = Level, y = C, group = Level1), scale = "count", trim = FALSE, width = 0.5, 
  #            linewidth= 0.1, fill = "#ACE0B4", position = position_dodge(width = 0.8)) +
  geom_point(aes(x = Con_Res_body, y = Mean.link.angle), position = position_jitter(width = 0.1), alpha = 0.3) +
  #geom_smooth(aes(x = Con_Res_body, y = Mean.link.angle), method = "lm", se = T,col="#2A5783") +  # Add trend line#scale_fill_manual(values = c("#1f77b4", "#ff7f0e")) +
  #geom_errorbar(aes(ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  #geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  #scale_fill_manual(values = c("#00CCFF","red")) +
  #coord_cartesian(ylim = c(0.09, 0.24)) +
  #scale_y_continuous(limits = c(0, 3000), breaks = seq(0, 1000, 2000))+
  xlab("log(consumer:resource body size)") + labs (y = expression(bold(Mean~link~angle))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "top") #c(0.1,0.85)
Linkangle_size
tiff("Linkangle_size.tiff", width = 3.5, height = 3, units = 'in', res = 300, compression = 'none')
Linkangle_size
dev.off()

Linkangle_abundance <- ggplot(data = Con_Res_web) +
  #geom_violin(aes(x = Level, y = C, group = Level1), scale = "count", trim = FALSE, width = 0.5, 
  #            linewidth= 0.1, fill = "#ACE0B4", position = position_dodge(width = 0.8)) +
  geom_point(aes(x = Con_Res_abundance, y = Mean.link.angle), position = position_jitter(width = 0.1), alpha = 0.3) +
  geom_smooth(aes(x = Con_Res_abundance, y = Mean.link.angle), method = "lm", se = T,col="#2A5783") +  # Add trend line#scale_fill_manual(values = c("#1f77b4", "#ff7f0e")) +
  #geom_errorbar(aes(ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  #geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  #scale_fill_manual(values = c("#00CCFF","red")) +
  #coord_cartesian(ylim = c(0.09, 0.24)) +
  #scale_y_continuous(limits = c(0, 3000), breaks = seq(0, 1000, 2000))+
  xlab("log(consumer:resource abundance)") + labs (y = expression(bold(Mean~link~angle))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "top") #c(0.1,0.85)
Linkangle_abundance
tiff("Linkangle_abundance.tiff",width = 3.5, height = 3, units = 'in', res = 300, compression = 'none')
Linkangle_abundance
dev.off()

m1 <- lm(Mean.link.angle ~ Con_Res_abundance, data=Con_Res_web)#
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

#*Align plots*link length/angle ####
library(cowplot)
LinksPlots <- plot_grid(Con_Res_body_plot, Con_Res_abundance_plot, 
                        Linklength_size, Linklength_abundance,
                        Linkangle_size, Linkangle_abundance,
                        align = "hv",nrow = 3, ncol =2)
LinksPlots
tiff("LinksPlots.tiff", width = 7, height = 9, units = 'in', res = 300, compression = 'none')
LinksPlots
dev.off()

#***********************####
#II.Energy flux calculation***#####
library(fluxweb)
library(igraph)

#construct functions####
fluxind <- function(fluxes, loop=FALSE){
  res<-c()
  # The flux matrix
  W.net<-as.matrix(fluxes) #fluxmatrix from fluxweb
  
  ### Taxon-specific Shannon indices of inflows
  # sum of k species inflows --> colsums
  sum.in<-apply(W.net, 2, sum)
  
  # Diversity of k species inflows
  # columns divided by the total col sum
  H.in.mat<- t(t(W.net)/sum.in)*t(log(t(W.net)/sum.in)) 
  H.in.mat[!is.finite(H.in.mat)] <- 0 #converts NaN to 0's
  H.in<- apply(H.in.mat, 2, sum)*-1
  
  # Effective number of prey or resources = N(R,k) 
  # The reciprocal of H(R,k) --> N (R,k) is the equivalent number of prey for species k
  N.res<-ifelse(sum.in==0, H.in, exp(H.in))
  
  ### Taxon-specific Shannon indices of outflows
  # sum of k speies outflows --> rowsums
  sum.out<-apply(W.net, 1, sum)
  
  # Diversity of k species outflows
  # rows divided by the total row sum
  H.out.mat<- (W.net/sum.out)*log(W.net/sum.out) 
  H.out.mat[!is.finite(H.out.mat)] <- 0 #converts NaN to 0's
  H.out<- apply(H.out.mat, 1, sum)*-1
  
  # Effective number of predators or consumers = N(C,k) 
  # The reciprocal of H(C,k) --> N (C,k) is the equivalent number of predators for species k
  N.con<-ifelse(sum.out==0, H.out, exp(H.out))
  
  ### Quantitative Weighted connectance
  no.species<-ncol(W.net)
  
  # The weighted link density (LDw) is:
  # In the weighted version the effective number of predators for species i is weighted by i's 
  # contribution to the total outflow the same is the case for the inflows
  tot.mat<- sum(W.net)
  # LD.w <- (sum((sum.in/tot.mat)*N.res) + sum((sum.out/tot.mat)*N.con))/2
  # equivalent to next formula, but next one is closer to manuscript
  LD <- 1/(2*tot.mat)*(sum(sum.in*N.res) + sum(sum.out*N.con))
  
  #Weighted connectance
  res$lwC<- LD/ifelse(loop, no.species, no.species-1)
  
  # positional.index
  pos.ind<- sum.in*N.res/(sum.in*N.res+sum.out*N.con) #postional index
  basal.sp<- pos.ind[pos.ind==0] #basal species = 0
  top.sp<- pos.ind[pos.ind==1] #defintion according to Bersier et al. 2002 top species = [0.99, 1]
  
  con.sp<-length(pos.ind)-length(basal.sp)# all consumer taxa except basal
  # weighted quantitative Generality
  res$lwG<-sum(sum.in*N.res/sum(W.net))
  
  res.sp<- length(pos.ind)-length(top.sp)
  # weighted quantitative Vulnerability
  res$lwV<-sum(sum.out*N.con/sum(W.net))
  
  return(res)
}



plotfw <- function(net, col=NULL, lab=NULL, size=NULL,
                   nylevel=7, maxsize=10, labcex=0.01,
                   ynum=6, ylab= "Trophic Level", ...){
  n <- vcount(net)
  if (!is.null(col)){
    V(net)$color <- col
  } else{
    V(net)$color <- rainbow(vcount(net))
  }
  if (!is.null(lab)){
    V(net)$name <- lab
  }
  if (!is.null(size)){
    V(net)$size <- size
  } else {
    V(net)$size <- maxsize/2
  }
  
  tl <- trophiclevels(net)
  dgpred <- tl
  
  bks <- c(0.9, seq(1.9, max(tl), length.out = nylevel))
  ynod <- cut(tl, breaks = bks, include.lowest = TRUE, 
              labels = 1:(length(bks)-1))
  
  maxx <- max(table(ynod))
  xnod <- rep(0,n)
  for (i in 1:nylevel){
    l <- sum(ynod==i)
    
    ltr <- (l/maxx)**(1/2)*maxx
    if (l>1) {
      xnod[ynod==i] <- seq(-ltr,ltr,length.out = l)
    } else {
      xnod[ynod==i] <- 0
    }
  }
  
  coo <- cbind(xnod,tl)
  
  #y axis with 1 and continuous axis from 2 to max TL.
  yax <- c(1, seq(2, max(tl), length.out = ynum-1))
  labax <- round(yax, 1)
  #rescale xax between -1 and 1
  laby <- (yax-min(yax))/(max(yax)-min(yax))*2 - 1
  
  plot(net, layout= coo, vertex.label.color="black", 
       vertex.label.cex=labcex, ...)
  axis(2, at = laby, labels = labax)
  #mtext(ylab, side = 2, line=2)#add lable of y-axis
  res <- data.frame(coo, "size"= V(net)$size, "color"= V(net)$color)
  names(res) <- c("x", "y", "size", "color")
  row.names(res) <- V(net)$name
  invisible(res)
}

trophiclevels <- function(net){
  #Get adjacency matrix 
  mat <- get.adjacency(net, sparse=F)
  
  #Detect basal node
  basal <- rownames(subset(mat, apply(mat, 2, sum)==0) & apply(mat, 1, sum)!= 0)
  #Compute the shortest path to basal node
  paths_prey <- suppressWarnings(shortest.paths(graph = net, v= V(net), to = V(net)[basal], 
                                                mode = "in", weights = NULL, algorithm = "unweighted"))
  
  paths_prey[is.infinite(paths_prey)] <- NA
  shortest_paths <- suppressWarnings(as.matrix(apply(paths_prey, 1, min, na.rm=TRUE)))
  #for species with no prey apart of them
  shortest_paths[is.infinite(shortest_paths)] <- NA
  
  # Shortest TL
  sTL <- 1 + shortest_paths
  
  # Compute average prey trophic level
  # inspired from cheddar package calculation
  W <- t(mat)
  rs <- rowSums(W)
  W <- W/matrix(rs, ncol = ncol(W), nrow = nrow(W))
  W[0 == rs, ] <- 0
  I <- diag(ncol(W))
  tl0<-rowSums(I - W)
  result <- tryCatch(solve(I - W), error = function(e) e)
  if ("error" %in% class(result)) {
    avtl <- rep(NA, ncol(pm))
    names(avtl) <- colnames(pm)
  }
  else {
    avtl <- rowSums(result)
  }
  
  # Short-weighted TL is the average between 
  # Shortest TL and average prey TL
  SWTL <- (sTL + avtl)/2
  
  return(SWTL)
}


#0.0.1 Transform egde list to matrix#
#Links <-  read.csv('C:/Users/zpynz/Desktop/2021 Mesocosm/Data/R food web analysis/FluxwebAnalysis/Pond47/trophic.links.csv')

#Links <- graph.data.frame(Links)

#Linkmatrix <- get.adjacency(Links, sparse = FALSE)
#Linkmatrix
#write.csv(Linkmatrix,"C:/Users/zpynz/Desktop/2021 Mesocosm/Data/R food web analysis/FluxwebAnalysis/Pond47/Linkmatrix.csv", row.names = TRUE)




#1.0 fluxweb plots for sum of the 6 ponds in each treatment####
#Note:for fluxweb calculation, in each web, mean biomass of macrophyte is set to 1, abundance of macrophyte is equal to their total biomass.
library(cheddar)
Sumweb2021 <- LoadCollection('Pathway of the sum web')
Sumweb2021

tiff("FluxwebSum.tiff", width = 9, height = 4, units = 'in', res = 600, compression = 'none')
par(mfrow=c(2,4), mar=c(0.1,0.5,1,0.1))#
for(i in 1:length(Sumweb2021)){
  Pond0 <- Sumweb2021[[i]]
  #bio <- log(NPS(web)$Totalbiomass+1)^(1/2)   ## Not sure why you raise this to the power of 0.5
  #PlotWebByLevel(web, pch=21, cex=bio)
  info <- NPS(Pond0)
  Links <- TLPS(Pond0)
  Properties <- CPS(Pond0)
  net <- graph_from_data_frame(d=Links, vertices =info$node, directed = T)
  #Color the functional groups
  info$fg <- as.factor(info$fg)
  levels(info$fg)
  colFG<- c("orange", "blue","green", "cyan")
  # Assign the colors to each node (taxon)
  info$colfg <- colFG[as.numeric(info$fg)]
  biomass <- info$Totalbiomass
  sizeB <- (biomass)^0.45
  #calculate metabolic rates of all organisms
  info$losses <- exp((-0.29 * log(info$M) + info$x0) - (0.69/(0.00008617343*(273.15+Properties$Temperature))))
  #plot the food web as an interaction matrix (called adjacency matrix)
  netmatrix <- get.adjacency(net, sparse=F)
  fluxes <- fluxing(netmatrix, biomass, info$losses, 
                    info$efficiencies, ef.level="prey")*86.4
  # Create a network with link weights
  netLW <- graph_from_adjacency_matrix(fluxes, weighted=TRUE)
  wid1 <- ((E(netLW)$weight))/2 + 0.5
  #wid <- 0.2+(sqrt(E(netLW)$weight)/max(sqrt(E(netLW)$weight))*10)
  
  # Remove the border of the frame
  V(netLW)$frame.color=NA
  
  plotfw(netLW,  size=sizeB, col=info$colfg,
         edge.width=wid1, edge.arrow.size=0.01, lab = info$Code, 
         labcex=1, main = Properties$title)
}

dev.off()


#2  fluxweb for each Pond####
library(cheddar)
Fluxweb2021 <- LoadCollection('pathway for all 48 ponds')
Fluxweb2021
Fluxweb2021 <- OrderCollection(Fluxweb2021,'Pondcode')
#Fluxweb2021 <- Fluxweb2021[1:2]

#2.1 plot for 48 link-weighted  webs####
tiff("Fluxweb2021.tiff", width = 8, height = 9, units = 'in', res = 300, compression = 'none')
par(mfrow=c(8,6), mar=c(0.1,0.5,1,0.1))#
for(i in 1:length(Fluxweb2021)){
  Pond0 <- Fluxweb2021[[i]]
  #bio <- log(NPS(web)$Totalbiomass+1)^(1/2)   ## Not sure why you raise this to the power of 0.5
  #PlotWebByLevel(web, pch=21, cex=bio)
  info <- NPS(Pond0)
  #if ("Bellamya" %in% rownames(info)) {
  #  info["Bellamya", "M"] <- info["Bellamya", "M"] * 0.2
  #}
  Links <- TLPS(Pond0)
  Properties <- CPS(Pond0)
  net <- graph_from_data_frame(d=Links, vertices =info$node, directed = T)
  #Color the functional groups
  info$fg <- as.factor(info$fg)
  levels(info$fg)
  #colFG<- c("orange", "blue","green", "cyan")
  # Assign the colors to each node (taxon)
  #info$colfg <- colFG[as.numeric(info$fg)]
  #info$colfg <-  c("Benthos"="orange","Fish"="blue","Producer"="green","Zooplankton"="cyan")[info$fg]
  for(i in 1:length(info$fg)) {if(info$fg[i] == "Producer"){
    info$colfg[i] <- "green"
  } else if (info$fg[i] =="Benthos"){
    info$colfg[i] <- "orange"
  } else if (info$fg[i] =="Zooplankton"){
    info$colfg[i] <- "cyan"
  }else if (info$fg[i] =="Fish"){
    info$colfg[i] <- "blue"
  }}
  
  biomass <- info$Totalbiomass
  sizeB <- ((biomass)^(1/3))*3
  #calculate metabolic rates of all organisms
  info$losses <- exp((-0.29 * log(info$M) + info$x0) - (0.69/(0.00008617343*(273.15+Properties$Temperature))))
  #plot the food web as an interaction matrix (called adjacency matrix)
  netmatrix <- get.adjacency(net, sparse=F)
  fluxes <- fluxing(netmatrix, biomass, info$losses, 
                    info$efficiencies, ef.level="prey")*86.4
  # Create a network with link weights
  netLW <- graph_from_adjacency_matrix(fluxes, weighted=TRUE)
  wid1 <- E(netLW)$weight+0.5
  
  # Remove the border of the frame
  V(netLW)$frame.color=NA
  
  plotfw(netLW,  size=sizeB, col=info$colfg,
         edge.width=wid1, edge.arrow.size=0.01, #lab = info$Code, labcex=1,
         main = Properties$title)
}

dev.off()

#2.2 Food web properties for 48 link-weighted webs####

N_Lweightedweb2021 <-data.frame()
for(i in 1:length(Fluxweb2021)){
  Pond0 <- Fluxweb2021[[i]]
  info <- NPS(Pond0)
  #if ("Bellamya" %in% rownames(info)) {
  #info["Bellamya", "M"] <- info["Bellamya", "M"] * 0.2
  #}
  Links <- TLPS(Pond0)
  Properties <- CPS(Pond0)
  
  net <- graph_from_data_frame(d=Links, vertices =info$node, directed = T)
  
  biomass <- info$Totalbiomass
  #calculate metabolic rates of all organisms
  info$losses <- exp((-0.29 * log(info$M) + info$x0) - (0.69/(0.00008617343*(273.15+Properties$Temperature))))
  #plot the food web as an interaction matrix (called adjacency matrix)
  netmatrix <- get.adjacency(net, sparse=F)
  fluxes <- fluxing(netmatrix, biomass, info$losses, 
                    info$efficiencies, ef.level="prey")*86.4
  # Create a network with link weights
  netLW <- graph_from_adjacency_matrix(fluxes, weighted=TRUE)
  
  #1.Topological indicators
  #Species richness
  S <- vcount(net)
  #Connectance
  C <- ecount(net)/(S*(S-1))
  #Generality
  # Identify predator nodes, i.e. taxa with at least one prey
  pred <- degree(net, mode="in")>0
  # Compute mean generality of the food web, i.e. mean number of prey per predators
  G <- sum(degree(net, mode="in")[pred])/sum(pred)
  #vulnerability
  # Identify prey nodes, i.e. taxa with at least one predator
  prey <- degree(net, mode="out")>0
  # Compute the mean vulnerability, i.e. mean number of predators per prey
  V <- sum(degree(net, mode="out")[prey])/sum(prey)
  #Mean shortest path
  # shortest path length between all pair of nodes
  sp <- shortest.paths(net)
  # Mean shortest path length between different species
  # [upper.tri(sp)] remove the diagonal.
  # Diagonal is by default set to 0 (path to itself)
  # which artificially lower the mean shortest path.
  ShortPath <- mean(sp[upper.tri(sp)]) 
  #short-weighted trophic levels
  # Compute the trophic level for each node  
  tlnodes <- trophiclevels(net)
  # Calculate the average trophic level of the food web
  TL <- mean(tlnodes)
  #Omnivory
  # netmatrix <- get.adjacency(net, sparse=F)
  # Link the trophic level to the interactions
  webtl <- netmatrix*as.vector(tlnodes)
  # Remove the trophic level when no interactions
  webtl[webtl==0] <- NA
  #Compute the standard of the trophic levels of prey 
  omninodes <- apply(webtl,2,sd, na.rm=TRUE)
  # Average the standard deviation over all taxa (with more than 2 preys)  
  Omni <- mean(omninodes, na.rm=TRUE)
  
  #2.Node-weighted indicators
  #Weighted connectance
  nwC <- sum(degree(net)*biomass)/(2*sum(biomass)*(vcount(net)-1))
  #Node-weighted Generality
  # Identify predators, i.e. taxa with at least one prey
  pred <- degree(net, mode="in")>0
  # Compute weigthed in-degree average among predators
  nwG <- sum((degree(net, mode="in")*biomass)[pred])/(sum(biomass[pred]))
  
  # Node-weighted vulnerability
  # Identify prey, i.e. taxa with at least one predator
  prey <- degree(net, mode="out")>0
  # Compute weigthed out-degree average among prey
  nwV <- sum((degree(net, mode="out")*biomass)[prey])/(sum(biomass[prey]))
  
  # Node-weighted Trophic level
  nwTL <- sum(tlnodes*biomass)/sum(biomass)
  
  #3. Link-weighted indicators
  res <- fluxind(fluxes)
  
  #4. Food web functions
  # Total fluxes
  Totalfluxes <- sum(fluxes)
  
  # herbivory
  Plants = colSums(fluxes) == 0
  Herbivory = sum(rowSums(fluxes[Plants,]))
  
  #carnivory
  Carnivory = sum(rowSums(fluxes[!Plants,]))
  
  #Out-fluxes
  Outflux <- apply(fluxes,1,sum)
  #Aggregate per feeding guild
  OutperF <- tapply(Outflux,info$fg,sum)
  
  # In-fluxes
  #Compute the sum of the in-fluxes per species
  Influx <- apply(fluxes,2,sum) # 1 indicates rows
  #Aggregate per feeding guild
  InperF <- tapply(Influx,info$fg,sum)
  
  ZooplanktonIn <- InperF["Zooplankton"]
  BenthosIn <- InperF["Benthos"]
  
  #Pelagic fluxes
  # Check if "Rotifer" and "Copepoda" are present in "fluxes" data frame
  if ("Rotifer" %in% rownames(fluxes) & "Copepoda" %in% colnames(fluxes)) {
    PelagicF <- InperF["Zooplankton"] + OutperF["Zooplankton"] - fluxes["Rotifer", "Copepoda"]
  } else {
    PelagicF <- InperF["Zooplankton"] + OutperF["Zooplankton"]
  }
  
  #Bethic fluxes
  #BenthicF <-  Outflux["Periphyton"] + Outflux["Macrophyte"] + OutperF["Benthos"] + fluxes["Phytoplankton","Bellamya"] + OutperF["Fish"]
  
  # Check if "Macrophyte" and "Fish" are present in "Outflux" and "OutperF" data frames, respectively
  if ("Macrophyte" %in% names(Outflux)) {
    BenthicF <- Outflux["Periphyton"] + Outflux["Macrophyte"] + OutperF["Benthos"]
  } else {
    BenthicF <- Outflux["Periphyton"] + OutperF["Benthos"]
  }
  
  # Check if "Phytoplankton" and "Bellamya" are present in "fluxes" data frame
  if ("Phytoplankton" %in% rownames(fluxes) & "Bellamya" %in% colnames(fluxes)) {
    BenthicF <- BenthicF + fluxes["Phytoplankton", "Bellamya"]
  }else {
    BenthicF <- BenthicF
  }
  
  #Check if "Fish" is present in "OutperF" data frame
  if ("Fish" %in% names(OutperF)) {
    BenthicF <- BenthicF + OutperF["Fish"]
  }else {
    BenthicF <- BenthicF
  }
  
  
  output <- print(c(`title` = Properties$title, `Temp` = Properties$Temp, `Eutroph` = Properties$Eutroph, `Pesticide` = Properties$Pesticide, 
                    `S` = S, `C` = C, `G` = G,`V` = V, `TL ` = TL,`Omni` = Omni, #basic topology
                    `nwC` = nwC, `nwG` = nwG, `nwV` = nwV, `nwTL` = nwTL, #node weighted indicators
                    `lwC` = res$lwC, `lwG` = res$lwG, `lwV` = res$lwV,# link weighted indicators
                    `Totalfluxes` = Totalfluxes, `Herbivory` = Herbivory, `Carnivory` = Carnivory,
                    `PelagicF` = PelagicF, `BenthicF` = BenthicF, `ZooplanktonIn` = ZooplanktonIn,
                    `BenthosIn` = BenthosIn
  ))
  
  N_Lweightedweb2021 <- rbind(N_Lweightedweb2021, output)
}

colnames(N_Lweightedweb2021)<-c("title", "Temp", "Eutroph", "Pesticide", "S", "C", "G", "V", "TL", "Omni",
                                "nwC", "nwG", "nwV", "nwTL", "lwC", "lwG", "lwV",
                                "Totalfluxes","Herbivory", "Carnivory","PelagicF","BenthicF",
                                "ZooplanktonIn","BenthosIn")

N_Lweightedweb2021
write.csv(N_Lweightedweb2021,"pathway", row.names = T)



#2.3 Energy fluxes statistics #####

library(ggplot2)
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
library(dplyr) #plyr need to be loaded before dplyr
library(gridExtra) 

N_Lweightedweb2021 <- N_Lweightedweb2021 %>% mutate_at(c(5:24), as.numeric)
N_Lweightedweb2021 <- N_Lweightedweb2021 %>% mutate_at(c(2:4), as.factor)
str(N_Lweightedweb2021)

##000# Predicted stressor interactions####
columns <- names(N_Lweightedweb2021)[5:24]

##2.3.1 Total flux #### 
library(ggplot2)
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
N_Lweightedweb2021$Totalfluxes <- as.numeric(N_Lweightedweb2021$Totalfluxes)
Totalfluxes_Cal <- ddply(N_Lweightedweb2021, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(Totalfluxes)), 
                         mean = mean(Totalfluxes,na.rm=TRUE),
                         sd = sd(Totalfluxes,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Totalfluxes_Cal

Totalfluxes_Cal$Treatment <- interaction(Totalfluxes_Cal$Eutroph, Totalfluxes_Cal$Pesticide,Totalfluxes_Cal$Temp)
Totalfluxes_Cal$Treatment1 <- interaction(Totalfluxes_Cal$Eutroph, Totalfluxes_Cal$Pesticide)
Totalfluxes_Cal$Treatment1 <- revalue(Totalfluxes_Cal$Treatment1, c("0.0"="0", "E.0"="N", "0.I"="I", "E.I"="N*I"))#Rename names

Totalfluxes_plot <- ggplot(data=Totalfluxes_Cal, aes(x = Treatment1, y = mean,fill=Temp)) + #
  geom_errorbar(aes(ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  scale_fill_manual(values = c("#00CCFF","red"))+
  coord_cartesian(ylim = c(2.5,15))+
  xlab("Treatments") + labs (y = expression(bold(Total~fluxes))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)
Totalfluxes_plot

tiff("Totalfluxes_plot.tiff", width = 2.5, height = 2, units = 'in', res = 300, compression = 'none')
Totalfluxes_plot
dev.off()

m1 <- glm(log(Totalfluxes) ~ Pesticide * Temp * Eutroph, data = N_Lweightedweb2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
library(car)
Anova(m1, type = "II")

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- glm(Totalfluxes ~ Pesticide * Temp * Eutroph, data = N_Lweightedweb2021,family=gaussian)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- glm(log(Totalfluxes) ~ Temp, data = N_Lweightedweb2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

library(effectsize)

m_interaction2 <- lm(
  log(Totalfluxes) ~ Temp, data = N_Lweightedweb2021,
  contrasts = list(
    Temp = "contr.sum",
    Pesticide = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, type = 2))


##2.3.2 Herbivory #### 
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
N_Lweightedweb2021$Herbivory <- as.numeric(N_Lweightedweb2021$Herbivory)
Herbivory_Cal <- ddply(N_Lweightedweb2021, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(Herbivory)), 
                       mean = mean(Herbivory,na.rm=TRUE),
                       sd = sd(Herbivory,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Herbivory_Cal

Herbivory_Cal$Treatment <- interaction(Herbivory_Cal$Eutroph, Herbivory_Cal$Pesticide,Herbivory_Cal$Temp)
Herbivory_Cal$Treatment1 <- interaction(Herbivory_Cal$Eutroph, Herbivory_Cal$Pesticide)
Herbivory_Cal$Treatment1 <- revalue(Herbivory_Cal$Treatment1, c("0.0"="0", "E.0"="N", "0.I"="I", "E.I"="N*I"))#Rename names

Herbivory_plot <- ggplot(data=Herbivory_Cal, aes(x = Treatment1, y = mean,fill=Temp)) + #
  geom_errorbar(aes(ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  scale_fill_manual(values = c("#00CCFF","red"))+
  coord_cartesian(ylim = c(2.5,15))+
  xlab("Treatments") + labs (y = expression(bold(Herbivory))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)
Herbivory_plot

tiff("Herbivory_plot.tiff", width = 2.5, height = 2, units = 'in', res = 300, compression = 'none')
Herbivory_plot
dev.off()

m1 <- glm(log(Herbivory) ~ Pesticide * Temp * Eutroph, data = N_Lweightedweb2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
library(car)
Anova(m1, type = "II")

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- glm(log(Herbivory) ~ Pesticide * Temp * Eutroph, data = N_Lweightedweb2021,family=gaussian)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- glm(log(Herbivory) ~ Temp, data = N_Lweightedweb2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

library(effectsize)

m_interaction2 <- lm(
  log(Herbivory) ~ Temp, data = N_Lweightedweb2021,
  contrasts = list(
    Temp = "contr.sum",
    Pesticide = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, type = 2))

##2.3.3 Carnivory #### 
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
N_Lweightedweb2021$Carnivory <- as.numeric(N_Lweightedweb2021$Carnivory)
Carnivory_Cal <- ddply(N_Lweightedweb2021, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(Carnivory)), 
                       mean = mean(Carnivory,na.rm=TRUE),
                       sd = sd(Carnivory,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Carnivory_Cal

Carnivory_Cal$Treatment <- interaction(Carnivory_Cal$Eutroph, Carnivory_Cal$Pesticide,Carnivory_Cal$Temp)
Carnivory_Cal$Treatment1 <- interaction(Carnivory_Cal$Eutroph, Carnivory_Cal$Pesticide)
Carnivory_Cal$Treatment1 <- revalue(Carnivory_Cal$Treatment1, c("0.0"="0", "E.0"="N", "0.I"="I", "E.I"="N*I"))#Rename names

Carnivory_plot <- ggplot(data=Carnivory_Cal, aes(x = Treatment1, y = mean,fill=Temp)) + #
  geom_errorbar(aes(ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  scale_fill_manual(values = c("#00CCFF","red"))+
  coord_cartesian(ylim = c(0,1.1))+
  xlab("Treatments") + labs (y = expression(bold(Carnivory))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)
Carnivory_plot

tiff("Carnivory_plot.tiff", width = 2.5, height = 2, units = 'in', res = 300, compression = 'none')
Carnivory_plot
dev.off()

m1 <- glm(log(Carnivory+0.1) ~ Pesticide * Temp * Eutroph, data = N_Lweightedweb2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
library(car)
Anova(m1, type = "II")

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- glm(log(Carnivory+0.001) ~ Pesticide * Temp * Eutroph, data = N_Lweightedweb2021,family=gaussian)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- glm(log(Carnivory+0.001) ~ Temp, data = N_Lweightedweb2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

library(effectsize)

m_interaction2 <- lm(
  log(Carnivory+0.001) ~ Temp, data = N_Lweightedweb2021,
  contrasts = list(
    Temp = "contr.sum",
    Pesticide = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, type = 2))

##2.3.4 Carnivory to Herbivory #### 
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
N_Lweightedweb2021$Carni_Herbi <- N_Lweightedweb2021$Carnivory/N_Lweightedweb2021$Herbivory

N_Lweightedweb2021$Carni_Herbi <- as.numeric(N_Lweightedweb2021$Carni_Herbi)
Carni_Herbi_Cal <- ddply(N_Lweightedweb2021, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(Carni_Herbi)), 
                         mean = mean(Carni_Herbi,na.rm=TRUE),
                         sd = sd(Carni_Herbi,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Carni_Herbi_Cal

Carni_Herbi_Cal$Treatment <- interaction(Carni_Herbi_Cal$Eutroph, Carni_Herbi_Cal$Pesticide,Carni_Herbi_Cal$Temp)
Carni_Herbi_Cal$Treatment1 <- interaction(Carni_Herbi_Cal$Eutroph, Carni_Herbi_Cal$Pesticide)
Carni_Herbi_Cal$Treatment1 <- revalue(Carni_Herbi_Cal$Treatment1, c("0.0"="0", "E.0"="N", "0.I"="I", "E.I"="N*I"))#Rename names

Carni_Herbi_plot <- ggplot(data=Carni_Herbi_Cal, aes(x = Treatment1, y = mean,fill=Temp)) + #
  geom_errorbar(aes(ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  scale_fill_manual(values = c("#00CCFF","red"))+
  coord_cartesian(ylim = c(0,0.18))+
  xlab("Treatments") + labs (y = expression(bold(Carni:Herbi))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)
Carni_Herbi_plot

tiff("Carni_Herbi_plot.tiff", width = 2.5, height = 2, units = 'in', res = 300, compression = 'none')
Carni_Herbi_plot
dev.off()

m1 <- glm(log(Carni_Herbi+0.001) ~ Pesticide * Temp * Eutroph, data = N_Lweightedweb2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
library(car)
Anova(m1, type = "II")

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- glm(log(Carni_Herbi+0.001) ~ Pesticide * Temp * Eutroph, data = N_Lweightedweb2021,family=gaussian)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- glm(log(Carni_Herbi+0.001) ~ Temp, data = N_Lweightedweb2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

library(effectsize)

m_interaction2 <- lm(
  log(Carni_Herbi+0.001) ~ Temp, data = N_Lweightedweb2021,
  contrasts = list(
    Temp = "contr.sum",
    Pesticide = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, type = 2))

##2.3.5 PelagicF #### 
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
N_Lweightedweb2021$PelagicF <- as.numeric(N_Lweightedweb2021$PelagicF)
PelagicF_Cal <- ddply(N_Lweightedweb2021, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(PelagicF)), 
                      mean = mean(PelagicF,na.rm=TRUE),
                      sd = sd(PelagicF,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
PelagicF_Cal

PelagicF_Cal$Treatment <- interaction(PelagicF_Cal$Eutroph, PelagicF_Cal$Pesticide,PelagicF_Cal$Temp)
PelagicF_Cal$Treatment1 <- interaction(PelagicF_Cal$Eutroph, PelagicF_Cal$Pesticide)
PelagicF_Cal$Treatment1 <- revalue(PelagicF_Cal$Treatment1, c("0.0"="0", "E.0"="N", "0.I"="I", "E.I"="N*I"))#Rename names

PelagicF_plot <- ggplot(data=PelagicF_Cal, aes(x = Treatment1, y = mean,fill=Temp)) + #
  geom_errorbar(aes(ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  scale_fill_manual(values = c("#00CCFF","red"))+
  #coord_cartesian(ylim = c(0,10))+
  xlab("Treatments") + labs (y = expression(bold(Pelagic~fluxes))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)
PelagicF_plot

tiff("PelagicF_plot.tiff", width = 2.5, height = 2, units = 'in', res = 300, compression = 'none')
PelagicF_plot
dev.off()

m1 <- glm(log(PelagicF) ~ Pesticide * Temp * Eutroph, data = N_Lweightedweb2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary.glm(m1)
summary(m1)
library(car)
Anova(m1, type = "II")

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- glm(log(PelagicF) ~ Pesticide * Temp * Eutroph, data = N_Lweightedweb2021,family=gaussian)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- glm(log(PelagicF) ~ Pesticide, data = N_Lweightedweb2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

library(effectsize)

m_interaction2 <- lm(
  log(PelagicF) ~ Pesticide, data = N_Lweightedweb2021,
  contrasts = list(
    Temp = "contr.sum",
    Pesticide = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, type = 2))

##2.3.6 BenthicF #### 
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
N_Lweightedweb2021$BenthicF <- as.numeric(N_Lweightedweb2021$BenthicF)
BenthicF_Cal <- ddply(N_Lweightedweb2021, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(BenthicF)), 
                      mean = mean(BenthicF,na.rm=TRUE),
                      sd = sd(BenthicF,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
BenthicF_Cal

BenthicF_Cal$Treatment <- interaction(BenthicF_Cal$Eutroph, BenthicF_Cal$Pesticide,BenthicF_Cal$Temp)
BenthicF_Cal$Treatment1 <- interaction(BenthicF_Cal$Eutroph, BenthicF_Cal$Pesticide)
BenthicF_Cal$Treatment1 <- revalue(BenthicF_Cal$Treatment1, c("0.0"="0", "E.0"="N", "0.I"="I", "E.I"="N*I"))#Rename names

BenthicF_plot <- ggplot(data=BenthicF_Cal, aes(x = Treatment1, y = mean,fill=Temp)) + #
  geom_errorbar(aes(ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  scale_fill_manual(values = c("#00CCFF","red"))+
  coord_cartesian(ylim = c(2,11))+
  xlab("Treatments") + labs (y = expression(bold(Benthic~fluxes))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)
BenthicF_plot

tiff("BenthicF_plot.tiff", width = 2.5, height = 2, units = 'in', res = 300, compression = 'none')
BenthicF_plot
dev.off()

m1 <- glm(log(BenthicF) ~ Pesticide * Temp * Eutroph, data = N_Lweightedweb2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
library(car)
Anova(m1, type = "II")

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- glm(log(BenthicF) ~ Pesticide * Temp * Eutroph, data = N_Lweightedweb2021,family=gaussian)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- glm(log(BenthicF) ~ Pesticide * Eutroph + Temp, data = N_Lweightedweb2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

library(effectsize)

m_interaction2 <- lm(
  log(BenthicF) ~ Pesticide * Eutroph + Temp, data = N_Lweightedweb2021,
  contrasts = list(
    Temp = "contr.sum",
    Eutroph = "contr.sum",
    Pesticide = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, type = 2))


##2.3.7 Benthic to Pleagic ratio #### 
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group

N_Lweightedweb2021$Benthic_Pelagic <- N_Lweightedweb2021$BenthicF/N_Lweightedweb2021$PelagicF
N_Lweightedweb2021$Benthic_Pelagic <- as.numeric(N_Lweightedweb2021$Benthic_Pelagic)
Benthic_Pelagic_Cal <- ddply(N_Lweightedweb2021, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(Benthic_Pelagic)), 
                             mean = mean(Benthic_Pelagic,na.rm=TRUE),
                             sd = sd(Benthic_Pelagic,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Benthic_Pelagic_Cal

Benthic_Pelagic_Cal$Treatment <- interaction(Benthic_Pelagic_Cal$Eutroph, Benthic_Pelagic_Cal$Pesticide,Benthic_Pelagic_Cal$Temp)
Benthic_Pelagic_Cal$Treatment1 <- interaction(Benthic_Pelagic_Cal$Eutroph, Benthic_Pelagic_Cal$Pesticide)
Benthic_Pelagic_Cal$Treatment1 <- revalue(Benthic_Pelagic_Cal$Treatment1, c("0.0"="0", "E.0"="N", "0.I"="I", "E.I"="N*I"))#Rename names

Benthic_Pelagic_plot <- ggplot(data=Benthic_Pelagic_Cal, aes(x = Treatment1, y = mean,fill=Temp)) + #
  geom_errorbar(aes(ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  scale_fill_manual(values = c("#00CCFF","red"))+
  #coord_cartesian(ylim = c(1,1.7))+
  xlab("Treatments") + labs (y = expression(bold(Benthic:Pelagic))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)
Benthic_Pelagic_plot

tiff("Benthic_Pelagic_plot.tiff", width = 2.5, height = 2.5, units = 'in', res = 300, compression = 'none')
Benthic_Pelagic_plot
dev.off()

m1 <- glm(log(Benthic_Pelagic) ~ Pesticide * Temp * Eutroph, data = N_Lweightedweb2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
library(car)
Anova(m1, type = "II")

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- glm(log(Benthic_Pelagic) ~ Pesticide * Temp * Eutroph, data = N_Lweightedweb2021,family=gaussian)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- glm(log(Benthic_Pelagic) ~ Pesticide, data = N_Lweightedweb2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

library(effectsize)

m_interaction2 <- lm(
  log(Benthic_Pelagic) ~ Pesticide, data = N_Lweightedweb2021,
  contrasts = list(
    Temp = "contr.sum",
    Eutroph = "contr.sum",
    Pesticide = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, type = 2))


#****Supplement Fig herbivory and carnivory flux####
library(cowplot)
SuppFigFlux <- plot_grid(Herbivory_plot, Carnivory_plot,  
                         Carni_Herbi_plot,
                         align = "v",nrow = 3, ncol =1)
SuppFigFlux
tiff("SuppFigFlux.tiff", width = 2.5, height = 6, units = 'in', res = 300, compression = 'none')
SuppFigFlux
dev.off()

