Sys.setlocale("LC_ALL", "English")# change locale to English

#load the packages#
#library(nlme)

library(gridExtra)
library(cowplot)
library(grid)
library(car)
library(ggplot2)
library(lme4)
#library(nlme)
library(lmerTest)


#Input data####
Mesocosmdata <- read.delim("2021MesocosmTime.txt")

Mesocosmdata$Temp <- as.factor(Mesocosmdata$Temp)
Mesocosmdata$Eutroph <- as.factor(Mesocosmdata$Eutroph)
Mesocosmdata$Pesticide <- as.factor(Mesocosmdata$Pesticide)

#construct interactions
Mesocosmdata$Temp_Pesticide <- interaction(Mesocosmdata$Temp, Mesocosmdata$Pesticide)
Mesocosmdata$Eutroph_Pesticide <- interaction(Mesocosmdata$Eutroph, Mesocosmdata$Pesticide)
library(plyr)
Mesocosmdata$Eutroph_Pesticide <- revalue(Mesocosmdata$Eutroph_Pesticide, c("0.0"="0", "N.0"="N", "0.I"="I", "N.I"="N*I"))#Rename names

Mesocosmdata$Treatment <- interaction(Mesocosmdata$Temp, Mesocosmdata$Eutroph, Mesocosmdata$Pesticide)

#Mesocosmdata$Eutroph_Pesticide <- revalue(Mesocosmdata$Eutroph_Pesticide, c("0.0"="0", "1.0"="E", "0.1"="G", "1.1"="EG"))#Rename names

Mesocosmdata$Date <- as.Date(Mesocosmdata$Date)

summary(Mesocosmdata)



#1.1 Macrophytes PVI####
# Total macrophyte PVI#
Mesocosmdata$Macrophyte <- (Mesocosmdata$P.crispus + Mesocosmdata$Hydrilla)*100 

library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
#Mesocosmdata$Hydrilla <- Mesocosmdata$Hydrilla *100
M_PVI_Cal <- ddply(Mesocosmdata, c("Temp","Pesticide","Eutroph","Date"), summarise, N = sum(!is.na(Macrophyte)), mean = mean(Macrophyte,na.rm=TRUE),
                   sd = sd(Macrophyte,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
M_PVI_Cal
M_PVI_Cal$Treatment <- interaction(M_PVI_Cal$Pesticide, M_PVI_Cal$Eutroph)
M_PVI_Cal$Treatment <- revalue(M_PVI_Cal$Treatment, c("0.0"="0", "0.N"="N", "I.0"="I", "I.N"="N*I"))#Rename names
M_PVI_Cal$Treatment <- factor(M_PVI_Cal$Treatment, levels = c("0","N","I","N*I"))

M_PVI_Cal$Date <- as.Date(M_PVI_Cal$Date)

M_PVI_plot <- ggplot(data = M_PVI_Cal, aes(x = Date, y = mean, colour = Temp, group = Temp)) +
  facet_wrap(~ Treatment, nrow = 1, strip.position = "top")+
  geom_line(aes(linetype = Temp), size = 1) + #geom_smooth(aes(linetype = Treatment),se=F, size = 1) + #geom_line(aes(linetype = Temp), size = 1) +
  geom_point(aes(shape = Temp),size = 1.5) + scale_shape_manual(values = c(15,16)) + #manually select point shape
  geom_errorbar(aes(ymax = mean + se, ymin = mean), size = 1, width = 5) + 
  scale_colour_manual(values = c("#00CCFF","red"))+#manually set color
  xlab("Date") + labs (y = expression(bold(Macrophytes~PVI~('%')))) +
  scale_x_date(date_breaks = "2 month",date_labels = "%b") +
  theme_bw() + 
  theme(legend.title = element_text(face = "bold", size = 14), legend.text = element_text(size = 12, face = "bold"),
        legend.background = element_rect(fill = "white", linetype = "solid"),
        axis.title.x = element_text(face = "bold", size = 14), axis.text.x = element_text(size = 12),
        axis.title.y = element_text(face = "bold", size = 14), axis.text.y = element_text(size = 12),
        panel.grid.minor = element_blank(), panel.grid.major = element_blank(),
        strip.background = element_blank(), strip.placement = "inside", # adjust facet lables
        strip.text.x = element_text(face = "bold", size = 14),
        panel.spacing = unit(0, "lines"), #set panel space
        legend.justification = c(0.5,1), legend.position = "top")
M_PVI_plot

tiff("M_PVI_plot.tiff", width = 8, height = 3, units = 'in', res = 300, compression = 'none')
M_PVI_plot
dev.off()

#Statistics
#lmer analysis 
#m1 <- lmer(asin(sqrt(Macrophyte/100)) ~ Temp * Eutroph * Pesticide +(1|Julian)+(1|Pond),  data = Mesocosmdata, REML = FALSE,na.action = na.omit)#[which(Macrophyte$Eutroph == "1"),]

m1 <- lmer(logit(Macrophyte/100)~ Temp * Eutroph * Pesticide +(1|Julian)+(1|Pond),  data = Mesocosmdata, REML = FALSE,na.action = na.omit)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
library(lmerTest)
summary(m1)
anova(m1)
Anova(m1)

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- lmer(logit(Macrophyte/100)~ Temp * Eutroph * Pesticide +(1|Julian)+(1|Pond),  data = Mesocosmdata, REML = FALSE)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- lmer(logit(Macrophyte/100)~ Temp * Eutroph +(1|Julian)+(1|Pond),  data = Mesocosmdata, REML = FALSE)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
anova(m1)

library(effectsize)

options(es.use_symbols = TRUE) # get nice symbols when printing! (On Windows, requires R >= 4.2.0)

F_to_eta2(
  f = c(1.52, 0.503, 4.69),
  df = c(1, 1, 1),
  df_error = c(47.37, 47.37, 47.37)
)


#1.2 Phytoplankton chl a####
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
#Mesocosmdata$Hydrilla <- Mesocosmdata$Hydrilla *100
Phytoplankton_Cal <- ddply(Mesocosmdata, c("Temp","Eutroph","Pesticide","Date"), summarise, N = sum(!is.na(Phytoplankton)), mean = mean(Phytoplankton,na.rm=TRUE),
                   sd = sd(Phytoplankton,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Phytoplankton_Cal
Phytoplankton_Cal$Treatment <- interaction(Phytoplankton_Cal$Pesticide, Phytoplankton_Cal$Eutroph)
Phytoplankton_Cal$Treatment <- revalue(Phytoplankton_Cal$Treatment, c("0.0"="0", "0.N"="N", "I.0"="I", "I.N"="N*I"))#Rename names
Phytoplankton_Cal$Treatment <- factor(Phytoplankton_Cal$Treatment, levels = c("0","N","I","N*I"))

Phytoplankton_Cal$Date <- as.Date(Phytoplankton_Cal$Date)

Phytoplankton_Cal <- subset(Phytoplankton_Cal, mean > 0)

Phytoplankton_plot <- ggplot(data = Phytoplankton_Cal, aes(x = Date, y = mean, colour = Temp, group = Temp)) +
  facet_wrap(~ Treatment, nrow = 1, strip.position = "top")+
  geom_line(aes(linetype = Temp), size = 1) + #geom_smooth(aes(linetype = Treatment),se=F, size = 1) + #geom_line(aes(linetype = Temp), size = 1) +
  geom_point(aes(shape = Temp),size = 1.5) + scale_shape_manual(values = c(15,16)) + #manually select point shape
  geom_errorbar(aes(ymax = mean + se, ymin = mean), size = 1, width = 5) + 
  scale_colour_manual(values = c("#00CCFF","red"))+#manually set color
  xlab("Date") + labs (y = expression(bold(Phytoplankton~chl~a~(μg~L^-1)))) +
  scale_x_date(date_breaks = "2 month",date_labels = "%b") +
  theme_bw() + 
  theme(legend.title = element_text(face = "bold", size = 14), legend.text = element_text(size = 12, face = "bold"),
        legend.background = element_rect(fill = "white", linetype = "solid"),
        axis.title.x = element_text(face = "bold", size = 14), axis.text.x = element_text(size = 12),
        axis.title.y = element_text(face = "bold", size = 14), axis.text.y = element_text(size = 12),
        panel.grid.minor = element_blank(), panel.grid.major = element_blank(),
        strip.background = element_blank(), strip.placement = "inside", # adjust facet lables
        strip.text.x = element_text(face = "bold", size = 14),
        panel.spacing = unit(0, "lines"), #set panel space
        legend.justification = c(0.5,1), legend.position = "top")
Phytoplankton_plot

tiff("Phytoplankton_plot.tiff", width = 8, height = 3, units = 'in', res = 300, compression = 'none')
Phytoplankton_plot
dev.off()

#Statistics
#lmer analysis 
m1 <- lmer(log(Phytoplankton+0.01) ~ Temp * Eutroph * Pesticide +(1|Julian)+(1|Pond),  data = Mesocosmdata, REML = FALSE,na.action = na.omit)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
library(lmerTest)
summary(m1)
anova(m1)

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- lmer(log(Phytoplankton+0.01)~ Temp * Eutroph * Pesticide +(1|Julian)+(1|Pond),  data = Mesocosmdata, REML = FALSE)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- lmer(log(Phytoplankton+0.01)~ Eutroph * Pesticide +(1|Julian)+(1|Pond),  data = Mesocosmdata, REML = FALSE)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
anova(m1)

library(effectsize)

options(es.use_symbols = TRUE) # get nice symbols when printing! (On Windows, requires R >= 4.2.0)

F_to_eta2(
  f = c(28.5, 49.07, 11.6),
  df = c(1, 1, 1),
  df_error = c(47.34, 47.34, 47.34)
)


#1.3 Periphyton chl a ####
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
#Mesocosmdata$Hydrilla <- Mesocosmdata$Hydrilla *100
Periphyton_Cal <- ddply(Mesocosmdata, c("Temp","Eutroph","Pesticide","Date"), summarise, N = sum(!is.na(Periphyton)), mean = mean(Periphyton,na.rm=TRUE),
                           sd = sd(Periphyton,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Periphyton_Cal
Periphyton_Cal$Treatment <- interaction(Periphyton_Cal$Pesticide, Periphyton_Cal$Eutroph)
Periphyton_Cal$Treatment <- revalue(Periphyton_Cal$Treatment, c("0.0"="0", "0.N"="N", "I.0"="I", "I.N"="N*I"))#Rename names
Periphyton_Cal$Treatment <- factor(Periphyton_Cal$Treatment, levels = c("0","N","I","N*I"))

Periphyton_Cal$Date <- as.Date(Periphyton_Cal$Date)

Periphyton_Cal <- subset(Periphyton_Cal, mean > 0)

Periphyton_plot <- ggplot(data = Periphyton_Cal, aes(x = Date, y = mean, colour = Temp, group = Temp)) +
  facet_wrap(~ Treatment, nrow = 1, strip.position = "top")+
  geom_line(aes(linetype = Temp), size = 1) + #geom_smooth(aes(linetype = Treatment),se=F, size = 1) + #geom_line(aes(linetype = Temp), size = 1) +
  geom_point(aes(shape = Temp),size = 1.5) + scale_shape_manual(values = c(15,16)) + #manually select point shape
  geom_errorbar(aes(ymax = mean + se, ymin = mean), size = 1, width = 5) + 
  scale_colour_manual(values = c("#00CCFF","red"))+#manually set color
  xlab("Date") + labs (y = expression(bold(Periphyton~chl~a~(μg~cm^-2)))) +
  scale_x_date(date_breaks = "2 month",date_labels = "%b") +
  theme_bw() + 
  theme(legend.title = element_text(face = "bold", size = 14), legend.text = element_text(size = 12, face = "bold"),
        legend.background = element_rect(fill = "white", linetype = "solid"),
        axis.title.x = element_text(face = "bold", size = 14), axis.text.x = element_text(size = 12),
        axis.title.y = element_text(face = "bold", size = 14), axis.text.y = element_text(size = 12),
        panel.grid.minor = element_blank(), panel.grid.major = element_blank(),
        strip.background = element_blank(), strip.placement = "inside", # adjust facet lables
        strip.text.x = element_text(face = "bold", size = 14),
        panel.spacing = unit(0, "lines"), #set panel space
        legend.justification = c(0.5,1), legend.position = "top")
Periphyton_plot

tiff("Periphyton_plot.tiff", width = 8, height = 3, units = 'in', res = 300, compression = 'none')
Periphyton_plot
dev.off()

#Statistics
#lmer analysis 
m1 <- lmer(log(Periphyton+0.01) ~ Temp * Eutroph * Pesticide +(1|Julian)+(1|Pond),  data = Mesocosmdata, REML = FALSE,na.action = na.omit)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
library(lmerTest)
summary(m1)
anova(m1)

#m2 <- lmer(log(Periphyton+0.01) ~ Temp * Eutroph * Pesticide +(1|Pond/Julian),  data = Mesocosmdata, REML = FALSE,na.action = na.omit)#[which(Macrophyte$Eutroph == "1"),]
library(nlme)
m2 <- lme(log(Periphyton+0.01) ~ Temp * Eutroph * Pesticide, random = ~1 | Pond/Julian, data = Mesocosmdata, method = "ML", na.action=na.omit)
hist(resid(m2))
qqnorm(resid(m2))
qqline(resid(m2))
summary(m2)
anova(m2)

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- lmer(log(Periphyton+0.01)~ Temp * Eutroph * Pesticide +(1|Julian)+(1|Pond),  data = Mesocosmdata, REML = FALSE)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- lmer(log(Periphyton+0.01)~ Eutroph * Pesticide + Temp * Eutroph + Temp * Pesticide +  +(1|Julian)+(1|Pond),  data = Mesocosmdata, REML = FALSE)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
anova(m1)

library(effectsize)

options(es.use_symbols = TRUE) # get nice symbols when printing! (On Windows, requires R >= 4.2.0)

F_to_eta2(
  f = c(0.412, 32.08, 1.95, 8.73, 3.37, 20.48),
  df = c(1, 1, 1,1,1),
  df_error = c(47.07, 47.07, 47.07,47.07,47.07)
)



#3.1 Turbidity ####
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
#Mesocosmdata$Hydrilla <- Mesocosmdata$Hydrilla *100
Turbidity_Cal <- ddply(Mesocosmdata, c("Temp","Eutroph","Pesticide","Date"), summarise, N = sum(!is.na(Turbidity)), mean = mean(Turbidity,na.rm=TRUE),
                        sd = sd(Turbidity,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Turbidity_Cal
Turbidity_Cal$Treatment <- interaction(Turbidity_Cal$Pesticide, Turbidity_Cal$Eutroph)
Turbidity_Cal$Treatment <- revalue(Turbidity_Cal$Treatment, c("0.0"="0", "0.N"="N", "I.0"="I", "I.N"="N*I"))#Rename names
Turbidity_Cal$Treatment <- factor(Turbidity_Cal$Treatment, levels = c("0","N","I","N*I"))

Turbidity_Cal$Date <- as.Date(Turbidity_Cal$Date)
Turbidity_Cal <- subset(Turbidity_Cal, mean > 0)

Turbidity_plot <- ggplot(data = Turbidity_Cal, aes(x = Date, y = mean, colour = Temp, group = Temp)) +
  facet_wrap(~ Treatment, nrow = 1, strip.position = "top")+
  geom_line(aes(linetype = Temp), size = 1) + #geom_smooth(aes(linetype = Treatment),se=F, size = 1) + #geom_line(aes(linetype = Temp), size = 1) +
  geom_point(aes(shape = Temp),size = 1.5) + scale_shape_manual(values = c(15,16)) + #manually select point shape
  geom_errorbar(aes(ymax = mean + se, ymin = mean), size = 1, width = 5) + 
  scale_colour_manual(values = c("#00CCFF","red"))+#manually set color
  xlab("Date") + labs (y = expression(bold(Turbidity~(NTU)))) +
  scale_x_date(date_breaks = "2 month",date_labels = "%b") +
  theme_bw() + 
  theme(legend.title = element_text(face = "bold", size = 14), legend.text = element_text(size = 12, face = "bold"),
        legend.background = element_rect(fill = "white", linetype = "solid"),
        axis.title.x = element_text(face = "bold", size = 14), axis.text.x = element_text(size = 12),
        axis.title.y = element_text(face = "bold", size = 14), axis.text.y = element_text(size = 12),
        panel.grid.minor = element_blank(), panel.grid.major = element_blank(),
        strip.background = element_blank(), strip.placement = "inside", # adjust facet lables
        strip.text.x = element_text(face = "bold", size = 14),
        panel.spacing = unit(0, "lines"), #set panel space
        legend.justification = c(0.5,1), legend.position = "top")
Turbidity_plot

tiff("Turbidity_plot.tiff", width = 8, height = 3, units = 'in', res = 300, compression = 'none')
Turbidity_plot
dev.off()

#Statistics
#lmer analysis 
m1 <- lmer(sqrt(Turbidity) ~ Temp * Eutroph * Pesticide +(1|Julian)+(1|Pond),  data = Mesocosmdata, REML = FALSE,na.action = na.omit)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
library(lmerTest)
summary(m1)
anova(m1)

Mesocosmdata_Turbi <- na.omit(Mesocosmdata)

library(MuMIn)
# Fit the full model
#options(na.action = "na.omit")
options(na.action = "na.fail")
full_model <- lmer(sqrt(Turbidity)~ Temp * Eutroph * Pesticide +(1|Julian)+(1|Pond),  data = Mesocosmdata_Turbi, REML = FALSE)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- lmer(sqrt(Turbidity)~ Eutroph * Pesticide + Temp +(1|Julian)+(1|Pond),  data = Mesocosmdata_Turbi, REML = FALSE)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
anova(m1)

library(effectsize)

options(es.use_symbols = TRUE) # get nice symbols when printing! (On Windows, requires R >= 4.2.0)

F_to_eta2(
  f = c(18.68, 0.772, 3.38,4.64),
  df = c(1, 1, 1,1),
  df_error = c(47.3, 47.3, 47.3,47.3)
)

#3.2 Conductivity ####
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
#Mesocosmdata$Hydrilla <- Mesocosmdata$Hydrilla *100
Cond_Cal <- ddply(Mesocosmdata, c("Temp","Eutroph","Pesticide","Date"), summarise, N = sum(!is.na(Conductivity)), mean = mean(Conductivity,na.rm=TRUE),
                       sd = sd(Conductivity,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Cond_Cal
Cond_Cal$Treatment <- interaction(Cond_Cal$Pesticide, Cond_Cal$Eutroph)
Cond_Cal$Treatment <- revalue(Cond_Cal$Treatment,c("0.0"="0", "0.N"="N", "I.0"="I", "I.N"="N*I"))#Rename names
Cond_Cal$Treatment <- factor(Cond_Cal$Treatment, levels = c("0","N","I","N*I"))

Cond_Cal$Date <- as.Date(Cond_Cal$Date)
Cond_Cal <- subset(Cond_Cal, mean > 0)

Cond_plot <- ggplot(data = Cond_Cal, aes(x = Date, y = mean, colour = Temp, group = Temp)) +
  facet_wrap(~ Treatment, nrow = 1, strip.position = "top")+
  geom_line(aes(linetype = Temp), size = 1) + #geom_smooth(aes(linetype = Treatment),se=F, size = 1) + #geom_line(aes(linetype = Temp), size = 1) +
  geom_point(aes(shape = Temp),size = 1.5) + scale_shape_manual(values = c(15,16)) + #manually select point shape
  geom_errorbar(aes(ymax = mean + se, ymin = mean), size = 1, width = 5) + 
  scale_colour_manual(values = c("#00CCFF","red"))+#manually set color
  xlab("Date") + labs (y = expression(bold(Conductivity~(??s~cm^-2)))) +
  scale_x_date(date_breaks = "2 month",date_labels = "%b") +
  theme_bw() + 
  theme(legend.title = element_text(face = "bold", size = 14), legend.text = element_text(size = 12, face = "bold"),
        legend.background = element_rect(fill = "white", linetype = "solid"),
        axis.title.x = element_text(face = "bold", size = 14), axis.text.x = element_text(size = 12),
        axis.title.y = element_text(face = "bold", size = 14), axis.text.y = element_text(size = 12),
        panel.grid.minor = element_blank(), panel.grid.major = element_blank(),
        strip.background = element_blank(), strip.placement = "inside", # adjust facet lables
        strip.text.x = element_text(face = "bold", size = 14),
        panel.spacing = unit(0, "lines"), #set panel space
        legend.justification = c(0.5,1), legend.position = "top")
Cond_plot

tiff("Cond_plot.tiff", width = 8, height = 3, units = 'in', res = 300, compression = 'none')
Cond_plot
dev.off()

#Statistics
#lmer analysis 
m1 <- lmer(log(Conductivity) ~ Temp * Eutroph * Pesticide +(1|Julian)+(1|Pond),  data = Mesocosmdata, REML = FALSE,na.action = na.omit)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
library(lmerTest)
summary(m1)
anova(m1)

Mesocosmdata_Cond <- na.omit(Mesocosmdata)

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- lmer(log(Conductivity)~ Temp * Eutroph * Pesticide +(1|Julian)+(1|Pond),  data = Mesocosmdata_Cond, REML = FALSE)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- lmer(log(Conductivity)~ Eutroph * Pesticide + Temp +(1|Julian)+(1|Pond),  data = Mesocosmdata_Cond, REML = FALSE)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
anova(m1)

library(effectsize)

options(es.use_symbols = TRUE) # get nice symbols when printing! (On Windows, requires R >= 4.2.0)

F_to_eta2(
  f = c(96.2, 9.99, 78.47,11.23),
  df = c(1, 1, 1,1),
  df_error = c(46.97, 46.97, 46.97,46.97)
)


#3.3 TN ####
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
#Mesocosmdata$Hydrilla <- Mesocosmdata$Hydrilla *100
TN_Cal <- ddply(Mesocosmdata, c("Temp","Eutroph","Pesticide","Date"), summarise, N = sum(!is.na(TN)), mean = mean(TN,na.rm=TRUE),
                  sd = sd(TN,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
TN_Cal
TN_Cal$Treatment <- interaction(TN_Cal$Pesticide, TN_Cal$Eutroph)
TN_Cal$Treatment <- revalue(TN_Cal$Treatment, c("0.0"="0", "0.N"="N", "I.0"="I", "I.N"="N*I"))#Rename names
TN_Cal$Treatment <- factor(TN_Cal$Treatment, levels = c("0","N","I","N*I"))

TN_Cal$Date <- as.Date(TN_Cal$Date)
TN_Cal <- subset(TN_Cal, mean > 0)

TN_plot <- ggplot(data = TN_Cal, aes(x = Date, y = mean, colour = Temp, group = Temp)) +
  facet_wrap(~ Treatment, nrow = 1, strip.position = "top")+
  geom_line(aes(linetype = Temp), size = 1) + #geom_smooth(aes(linetype = Treatment),se=F, size = 1) + #geom_line(aes(linetype = Temp), size = 1) +
  geom_point(aes(shape = Temp),size = 1.5) + scale_shape_manual(values = c(15,16)) + #manually select point shape
  geom_errorbar(aes(ymax = mean + se, ymin = mean), size = 1, width = 5) + 
  scale_colour_manual(values = c("#00CCFF","red"))+#manually set color
  xlab("Date") + labs (y = expression(bold(TN~(mg~L^-1)))) +
  scale_x_date(date_breaks = "2 month",date_labels = "%b") +
  theme_bw() + 
  theme(legend.title = element_text(face = "bold", size = 14), legend.text = element_text(size = 12, face = "bold"),
        legend.background = element_rect(fill = "white", linetype = "solid"),
        axis.title.x = element_text(face = "bold", size = 14), axis.text.x = element_text(size = 12),
        axis.title.y = element_text(face = "bold", size = 14), axis.text.y = element_text(size = 12),
        panel.grid.minor = element_blank(), panel.grid.major = element_blank(),
        strip.background = element_blank(), strip.placement = "inside", # adjust facet lables
        strip.text.x = element_text(face = "bold", size = 14),
        panel.spacing = unit(0, "lines"), #set panel space
        legend.justification = c(0.5,1), legend.position = "top")
TN_plot

tiff("TN_plot.tiff", width = 8, height = 3, units = 'in', res = 300, compression = 'none')
TN_plot
dev.off()

#Statistics
#lmer analysis 
m1 <- lmer(log(TN) ~ Temp * Eutroph * Pesticide +(1|Julian)+(1|Pond),  data = Mesocosmdata, REML = FALSE,na.action = na.omit)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
library(lmerTest)
summary(m1)
anova(m1)

Mesocosmdata_Cond <- na.omit(Mesocosmdata)

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- lmer(log(TN)~ Temp * Eutroph * Pesticide +(1|Julian)+(1|Pond),  data = Mesocosmdata_Cond, REML = FALSE)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- lmer(log(TN)~ Eutroph * Pesticide + Temp +(1|Julian)+(1|Pond),  data = Mesocosmdata_Cond, REML = FALSE)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
anova(m1)

library(effectsize)

options(es.use_symbols = TRUE) # get nice symbols when printing! (On Windows, requires R >= 4.2.0)

F_to_eta2(
  f = c(142.3, 39.14, 3.52,10),
  df = c(1, 1, 1,1),
  df_error = c(47.15, 47.18, 47.14,47.14)
)

#3.4 NH4 ####
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
#Mesocosmdata$Hydrilla <- Mesocosmdata$Hydrilla *100
NH4_Cal <- ddply(Mesocosmdata, c("Temp","Eutroph","Pesticide","Date"), summarise, N = sum(!is.na(NH4)), mean = mean(NH4,na.rm=TRUE),
                sd = sd(NH4,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
NH4_Cal
NH4_Cal$Treatment <- interaction(NH4_Cal$Pesticide, NH4_Cal$Eutroph)
NH4_Cal$Treatment <- revalue(NH4_Cal$Treatment, c("0.0"="0", "0.N"="N", "I.0"="I", "I.N"="N*I"))#Rename names
NH4_Cal$Treatment <- factor(NH4_Cal$Treatment, levels = c("0","N","I","N*I"))

NH4_Cal$Date <- as.Date(NH4_Cal$Date)
NH4_Cal <- subset(NH4_Cal, mean > 0)

NH4_plot <- ggplot(data = NH4_Cal, aes(x = Date, y = mean, colour = Temp, group = Temp)) +
  facet_wrap(~ Treatment, nrow = 1, strip.position = "top")+
  geom_line(aes(linetype = Temp), size = 1) + #geom_smooth(aes(linetype = Treatment),se=F, size = 1) + #geom_line(aes(linetype = Temp), size = 1) +
  geom_point(aes(shape = Temp),size = 1.5) + scale_shape_manual(values = c(15,16)) + #manually select point shape
  geom_errorbar(aes(ymax = mean + se, ymin = mean), size = 1, width = 5) + 
  scale_colour_manual(values = c("#00CCFF","red"))+#manually set color
  xlab("Date") + labs (y = expression(bold(NH[4]^'+'~(mg~L^-1)))) +
  scale_x_date(date_breaks = "2 month",date_labels = "%b") +
  theme_bw() + 
  theme(legend.title = element_text(face = "bold", size = 14), legend.text = element_text(size = 12, face = "bold"),
        legend.background = element_rect(fill = "white", linetype = "solid"),
        axis.title.x = element_text(face = "bold", size = 14), axis.text.x = element_text(size = 12),
        axis.title.y = element_text(face = "bold", size = 14), axis.text.y = element_text(size = 12),
        panel.grid.minor = element_blank(), panel.grid.major = element_blank(),
        strip.background = element_blank(), strip.placement = "inside", # adjust facet lables
        strip.text.x = element_text(face = "bold", size = 14),
        panel.spacing = unit(0, "lines"), #set panel space
        legend.justification = c(0.5,1), legend.position = "top")
NH4_plot

tiff("NH4_plot.tiff", width = 8, height = 3, units = 'in', res = 300, compression = 'none')
NH4_plot
dev.off()

#Statistics
#lmer analysis 
m1 <- lmer(log(NH4+0.1) ~ Temp * Eutroph * Pesticide +(1|Julian)+(1|Pond),  data = Mesocosmdata, REML = FALSE,na.action = na.omit)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
library(lmerTest)
summary(m1)
anova(m1)

Mesocosmdata_Cond <- na.omit(Mesocosmdata)

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- lmer(log(NH4+0.1)~ Temp * Eutroph * Pesticide +(1|Julian)+(1|Pond),  data = Mesocosmdata_Cond, REML = FALSE)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- lmer(log(NH4+0.1)~ Eutroph + Pesticide * Temp +(1|Julian)+(1|Pond),  data = Mesocosmdata_Cond, REML = FALSE)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
anova(m1)

library(effectsize)

options(es.use_symbols = TRUE) # get nice symbols when printing! (On Windows, requires R >= 4.2.0)

F_to_eta2(
  f = c(50.96, 21.24, 48.99,5.96),
  df = c(1, 1, 1,1),
  df_error = c(47.01, 47.05, 46.99,47.12)
)

#3.5 NO3 ####
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
#Mesocosmdata$Hydrilla <- Mesocosmdata$Hydrilla *100
NO3_Cal <- ddply(Mesocosmdata, c("Temp","Eutroph","Pesticide","Date"), summarise, N = sum(!is.na(NO3)), mean = mean(NH4,na.rm=TRUE),
                 sd = sd(NO3,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
NO3_Cal
NO3_Cal$Treatment <- interaction(NO3_Cal$Pesticide, NO3_Cal$Eutroph)
NO3_Cal$Treatment <- revalue(NO3_Cal$Treatment, c("0.0"="0", "0.N"="N", "I.0"="I", "I.N"="N*I"))#Rename names
NO3_Cal$Treatment <- factor(NO3_Cal$Treatment, levels = c("0","N","I","N*I"))

NO3_Cal$Date <- as.Date(NO3_Cal$Date)
NO3_Cal <- subset(NO3_Cal, mean > 0)

NO3_plot <- ggplot(data = NO3_Cal, aes(x = Date, y = mean, colour = Temp, group = Temp)) +
  facet_wrap(~ Treatment, nrow = 1, strip.position = "top")+
  geom_line(aes(linetype = Temp), size = 1) + #geom_smooth(aes(linetype = Treatment),se=F, size = 1) + #geom_line(aes(linetype = Temp), size = 1) +
  geom_point(aes(shape = Temp),size = 1.5) + scale_shape_manual(values = c(15,16)) + #manually select point shape
  geom_errorbar(aes(ymax = mean + se, ymin = mean), size = 1, width = 5) + 
  scale_colour_manual(values = c("#00CCFF","red"))+#manually set color
  xlab("Date") + labs (y = expression(bold(NO[3]^'-'~(mg~L^-1)))) +
  scale_x_date(date_breaks = "2 month",date_labels = "%b") +
  theme_bw() + 
  theme(legend.title = element_text(face = "bold", size = 14), legend.text = element_text(size = 12, face = "bold"),
        legend.background = element_rect(fill = "white", linetype = "solid"),
        axis.title.x = element_text(face = "bold", size = 14), axis.text.x = element_text(size = 12),
        axis.title.y = element_text(face = "bold", size = 14), axis.text.y = element_text(size = 12),
        panel.grid.minor = element_blank(), panel.grid.major = element_blank(),
        strip.background = element_blank(), strip.placement = "inside", # adjust facet lables
        strip.text.x = element_text(face = "bold", size = 14),
        panel.spacing = unit(0, "lines"), #set panel space
        legend.justification = c(0.5,1), legend.position = "top")
NO3_plot

tiff("NO3_plot.tiff", width = 8, height = 3, units = 'in', res = 300, compression = 'none')
NO3_plot
dev.off()

#Statistics
#lmer analysis 
m1 <- lmer(log(NO3+0.01) ~ Temp * Eutroph * Pesticide +(1|Julian)+(1|Pond),  data = Mesocosmdata, REML = FALSE,na.action = na.omit)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
library(lmerTest)
summary(m1)
anova(m1)

Mesocosmdata_Cond <- na.omit(Mesocosmdata)

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- lmer(log(NO3+0.01)~ Temp * Eutroph * Pesticide +(1|Julian)+(1|Pond),  data = Mesocosmdata_Cond, REML = FALSE)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- lmer(log(NO3+0.01)~ Eutroph * Pesticide +(1|Julian)+(1|Pond),  data = Mesocosmdata_Cond, REML = FALSE)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
anova(m1)

library(effectsize)

options(es.use_symbols = TRUE) # get nice symbols when printing! (On Windows, requires R >= 4.2.0)

F_to_eta2(
  f = c(44.22, 15.87, 2.25),
  df = c(1, 1, 1),
  df_error = c(47.12, 47.16, 47.12)
)

#3.6 TP ####
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
#Mesocosmdata$Hydrilla <- Mesocosmdata$Hydrilla *100
TP_Cal <- ddply(Mesocosmdata, c("Temp","Eutroph","Pesticide","Date"), summarise, N = sum(!is.na(TP)), mean = mean(TP,na.rm=TRUE),
                sd = sd(TP,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
TP_Cal
TP_Cal$Treatment <- interaction(TP_Cal$Pesticide, TP_Cal$Eutroph)
TP_Cal$Treatment <- revalue(TP_Cal$Treatment,c("0.0"="0", "0.N"="N", "I.0"="I", "I.N"="N*I"))#Rename names
TP_Cal$Treatment <- factor(TP_Cal$Treatment, levels = c("0","N","I","N*I"))

TP_Cal$Date <- as.Date(TP_Cal$Date)
TP_Cal <- subset(TP_Cal, mean > 0)

TP_plot <- ggplot(data = TP_Cal, aes(x = Date, y = mean, colour = Temp, group = Temp)) +
  facet_wrap(~ Treatment, nrow = 1, strip.position = "top")+
  geom_line(aes(linetype = Temp), size = 1) + #geom_smooth(aes(linetype = Treatment),se=F, size = 1) + #geom_line(aes(linetype = Temp), size = 1) +
  geom_point(aes(shape = Temp),size = 1.5) + scale_shape_manual(values = c(15,16)) + #manually select point shape
  geom_errorbar(aes(ymax = mean + se, ymin = mean), size = 1, width = 5) + 
  scale_colour_manual(values = c("#00CCFF","red"))+#manually set color
  xlab("Date") + labs (y = expression(bold(TP~(mg~L^-1)))) +
  scale_x_date(date_breaks = "2 month",date_labels = "%b") +
  theme_bw() + 
  theme(legend.title = element_text(face = "bold", size = 14), legend.text = element_text(size = 12, face = "bold"),
        legend.background = element_rect(fill = "white", linetype = "solid"),
        axis.title.x = element_text(face = "bold", size = 14), axis.text.x = element_text(size = 12),
        axis.title.y = element_text(face = "bold", size = 14), axis.text.y = element_text(size = 12),
        panel.grid.minor = element_blank(), panel.grid.major = element_blank(),
        strip.background = element_blank(), strip.placement = "inside", # adjust facet lables
        strip.text.x = element_text(face = "bold", size = 14),
        panel.spacing = unit(0, "lines"), #set panel space
        legend.justification = c(0.5,1), legend.position = "top")
TP_plot

tiff("TP_plot.tiff", width = 8, height = 3, units = 'in', res = 300, compression = 'none')
TP_plot
dev.off()

#Statistics
#lmer analysis 
m1 <- lmer(log(TP+0.01) ~ Temp * Eutroph * Pesticide +(1|Julian)+(1|Pond),  data = Mesocosmdata, REML = FALSE,na.action = na.omit)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
library(lmerTest)
summary(m1)
anova(m1)

Mesocosmdata_Cond <- na.omit(Mesocosmdata)

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- lmer(log(TP+0.01)~ Temp * Eutroph * Pesticide +(1|Julian)+(1|Pond),  data = Mesocosmdata_Cond, REML = FALSE)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- lmer(log(TP+0.01)~ Eutroph * Pesticide + Temp +(1|Julian)+(1|Pond),  data = Mesocosmdata_Cond, REML = FALSE)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
anova(m1)

library(effectsize)

options(es.use_symbols = TRUE) # get nice symbols when printing! (On Windows, requires R >= 4.2.0)

F_to_eta2(
  f = c(74.73, 56.44, 6.43,18.85),
  df = c(1, 1, 1,1),
  df_error = c(47.23, 47.27, 47.23,47.23)
)


#3.7 PO4 ####
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
#Mesocosmdata$Hydrilla <- Mesocosmdata$Hydrilla *100
PO4_Cal <- ddply(Mesocosmdata, c("Temp","Eutroph","Pesticide","Date"), summarise, N = sum(!is.na(PO4)), mean = mean(PO4,na.rm=TRUE),
                sd = sd(PO4,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
PO4_Cal
PO4_Cal$Treatment <- interaction(PO4_Cal$Pesticide, PO4_Cal$Eutroph)
PO4_Cal$Treatment <- revalue(PO4_Cal$Treatment, c("0.0"="0", "0.N"="N", "I.0"="I", "I.N"="N*I"))#Rename names
PO4_Cal$Treatment <- factor(PO4_Cal$Treatment, levels = c("0","N","I","N*I"))

PO4_Cal$Date <- as.Date(PO4_Cal$Date)
PO4_Cal <- subset(PO4_Cal, mean > 0)

PO4_plot <- ggplot(data = PO4_Cal, aes(x = Date, y = mean, colour = Temp, group = Temp)) +
  facet_wrap(~ Treatment, nrow = 1, strip.position = "top")+
  geom_line(aes(linetype = Temp), size = 1) + #geom_smooth(aes(linetype = Treatment),se=F, size = 1) + #geom_line(aes(linetype = Temp), size = 1) +
  geom_point(aes(shape = Temp),size = 1.5) + scale_shape_manual(values = c(15,16)) + #manually select point shape
  geom_errorbar(aes(ymax = mean + se, ymin = mean), size = 1, width = 5) + 
  scale_colour_manual(values = c("#00CCFF","red"))+#manually set color
  xlab("Date") + labs (y = expression(bold(PO[4]^'-3'~(mg~L^-1)))) +
  scale_x_date(date_breaks = "2 month",date_labels = "%b") +
  theme_bw() + 
  theme(legend.title = element_text(face = "bold", size = 14), legend.text = element_text(size = 12, face = "bold"),
        legend.background = element_rect(fill = "white", linetype = "solid"),
        axis.title.x = element_text(face = "bold", size = 14), axis.text.x = element_text(size = 12),
        axis.title.y = element_text(face = "bold", size = 14), axis.text.y = element_text(size = 12),
        panel.grid.minor = element_blank(), panel.grid.major = element_blank(),
        strip.background = element_blank(), strip.placement = "inside", # adjust facet lables
        strip.text.x = element_text(face = "bold", size = 14),
        panel.spacing = unit(0, "lines"), #set panel space
        legend.justification = c(0.5,1), legend.position = "top")
PO4_plot

tiff("PO4_plot.tiff", width = 8, height = 3, units = 'in', res = 300, compression = 'none')
PO4_plot
dev.off()

#Statistics
#lmer analysis 
m1 <- lmer(log(PO4+0.001) ~ Temp * Eutroph * Pesticide +(1|Julian)+(1|Pond),  data = Mesocosmdata, REML = FALSE,na.action = na.omit)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
library(lmerTest)
summary(m1)
anova(m1)

Mesocosmdata_Cond <- na.omit(Mesocosmdata)

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- lmer(log(PO4+0.001)~ Temp * Eutroph * Pesticide +(1|Julian)+(1|Pond),  data = Mesocosmdata_Cond, REML = FALSE)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- lmer(log(PO4+0.001)~ Eutroph * Pesticide + Temp +(1|Julian)+(1|Pond),  data = Mesocosmdata_Cond, REML = FALSE)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
anova(m1)

library(effectsize)

options(es.use_symbols = TRUE) # get nice symbols when printing! (On Windows, requires R >= 4.2.0)

F_to_eta2(
  f = c(44.65, 10.66, 21.32,11.29),
  df = c(1, 1, 1,1),
  df_error = c(46.79, 46.82, 46.78,46.78)
)


#3.8 DO ####
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
#Mesocosmdata$Hydrilla <- Mesocosmdata$Hydrilla *100
DO_Cal <- ddply(Mesocosmdata, c("Temp","Eutroph","Pesticide","Date"), summarise, N = sum(!is.na(DO)), mean = mean(DO,na.rm=TRUE),
                sd = sd(DO,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
DO_Cal
DO_Cal$Treatment <- interaction(DO_Cal$Pesticide, DO_Cal$Eutroph)
DO_Cal$Treatment <- revalue(DO_Cal$Treatment, c("0.0"="0", "0.N"="N", "I.0"="I", "I.N"="N*I"))#Rename names
DO_Cal$Treatment <- factor(DO_Cal$Treatment, levels = c("0","N","I","N*I"))

DO_Cal$Date <- as.Date(DO_Cal$Date)
DO_Cal <- subset(DO_Cal, mean > 0)

DO_plot <- ggplot(data = DO_Cal, aes(x = Date, y = mean, colour = Temp, group = Temp)) +
  facet_wrap(~ Treatment, nrow = 1, strip.position = "top")+
  geom_line(aes(linetype = Temp), size = 1) + #geom_smooth(aes(linetype = Treatment),se=F, size = 1) + #geom_line(aes(linetype = Temp), size = 1) +
  geom_point(aes(shape = Temp),size = 1.5) + scale_shape_manual(values = c(15,16)) + #manually select point shape
  geom_errorbar(aes(ymax = mean + se, ymin = mean), size = 1, width = 5) + 
  scale_colour_manual(values = c("#00CCFF","red"))+#manually set color
  xlab("Date") + labs (y = expression(bold(DO~(mg~L^-1)))) +
  scale_x_date(date_breaks = "2 month",date_labels = "%b") +
  theme_bw() + 
  theme(legend.title = element_text(face = "bold", size = 14), legend.text = element_text(size = 12, face = "bold"),
        legend.background = element_rect(fill = "white", linetype = "solid"),
        axis.title.x = element_text(face = "bold", size = 14), axis.text.x = element_text(size = 12),
        axis.title.y = element_text(face = "bold", size = 14), axis.text.y = element_text(size = 12),
        panel.grid.minor = element_blank(), panel.grid.major = element_blank(),
        strip.background = element_blank(), strip.placement = "inside", # adjust facet lables
        strip.text.x = element_text(face = "bold", size = 14),
        panel.spacing = unit(0, "lines"), #set panel space
        legend.justification = c(0.5,1), legend.position = "top")
DO_plot

tiff("DO_plot.tiff", width = 8, height = 3, units = 'in', res = 300, compression = 'none')
DO_plot
dev.off()

#Statistics
#lmer analysis 
m1 <- lmer(log(DO+10) ~ Temp * Eutroph * Pesticide +(1|Julian)+(1|Pond),  data = Mesocosmdata, REML = FALSE,na.action = na.omit)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
library(lmerTest)
summary(m1)
anova(m1)


Mesocosmdata_Cond <- na.omit(Mesocosmdata)

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- lmer(log(DO+10)~ Temp * Eutroph * Pesticide +(1|Julian)+(1|Pond),  data = Mesocosmdata_Cond, REML = FALSE)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- lmer(log(DO+10)~ Pesticide * Temp +(1|Julian)+(1|Pond),  data = Mesocosmdata_Cond, REML = FALSE)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
anova(m1)

library(effectsize)

options(es.use_symbols = TRUE) # get nice symbols when printing! (On Windows, requires R >= 4.2.0)

F_to_eta2(
  f = c(127.45, 53.51, 9.98),
  df = c(1, 1, 1),
  df_error = c(44.61, 44.53, 44.67)
)


#3.9 pH ####
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
#Mesocosmdata$Hydrilla <- Mesocosmdata$Hydrilla *100
pH_Cal <- ddply(Mesocosmdata, c("Temp","Eutroph","Pesticide","Date"), summarise, N = sum(!is.na(pH)), mean = mean(pH,na.rm=TRUE),
                sd = sd(pH,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
pH_Cal
pH_Cal$Treatment <- interaction(pH_Cal$Pesticide, pH_Cal$Eutroph)
pH_Cal$Treatment <- revalue(pH_Cal$Treatment,c("0.0"="0", "0.N"="N", "I.0"="I", "I.N"="N*I"))#Rename names
pH_Cal$Treatment <- factor(pH_Cal$Treatment, levels = c("0","N","I","N*I"))

pH_Cal$Date <- as.Date(pH_Cal$Date)
pH_Cal <- subset(pH_Cal, mean > 0)

pH_plot <- ggplot(data = pH_Cal, aes(x = Date, y = mean, colour = Temp, group = Temp)) +
  facet_wrap(~ Treatment, nrow = 1, strip.position = "top")+
  geom_line(aes(linetype = Temp), size = 1) + #geom_smooth(aes(linetype = Treatment),se=F, size = 1) + #geom_line(aes(linetype = Temp), size = 1) +
  geom_point(aes(shape = Temp),size = 1.5) + scale_shape_manual(values = c(15,16)) + #manually select point shape
  geom_errorbar(aes(ymax = mean + se, ymin = mean), size = 1, width = 5) + 
  scale_colour_manual(values = c("#00CCFF","red"))+#manually set color
  xlab("Date") + labs (y = expression(bold(pH))) +
  scale_x_date(date_breaks = "2 month",date_labels = "%b") +
  theme_bw() + 
  theme(legend.title = element_text(face = "bold", size = 14), legend.text = element_text(size = 12, face = "bold"),
        legend.background = element_rect(fill = "white", linetype = "solid"),
        axis.title.x = element_text(face = "bold", size = 14), axis.text.x = element_text(size = 12),
        axis.title.y = element_text(face = "bold", size = 14), axis.text.y = element_text(size = 12),
        panel.grid.minor = element_blank(), panel.grid.major = element_blank(),
        strip.background = element_blank(), strip.placement = "inside", # adjust facet lables
        strip.text.x = element_text(face = "bold", size = 14),
        panel.spacing = unit(0, "lines"), #set panel space
        legend.justification = c(0.5,1), legend.position = "top")
pH_plot

tiff("pH_plot.tiff", width = 8, height = 3, units = 'in', res = 300, compression = 'none')
pH_plot
dev.off()

#Statistics
#lmer analysis 
m1 <- lmer(pH ~ Temp * Eutroph * Pesticide +(1|Julian)+(1|Pond),  data = Mesocosmdata, REML = FALSE,na.action = na.omit)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
library(lmerTest)
summary(m1)
anova(m1)

Mesocosmdata_Cond <- na.omit(Mesocosmdata)

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- lmer(pH~ Temp * Eutroph * Pesticide +(1|Julian)+(1|Pond),  data = Mesocosmdata_Cond, REML = FALSE)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- lmer(pH~ Pesticide * Temp + Eutroph * Temp + Pesticide * Eutroph  +(1|Julian)+(1|Pond),  data = Mesocosmdata_Cond, REML = FALSE)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
anova(m1)

library(effectsize)

options(es.use_symbols = TRUE) # get nice symbols when printing! (On Windows, requires R >= 4.2.0)

F_to_eta2(
  f = c(139.1, 0.407, 29.99,5.90,3.47,6.81),
  df = c(1, 1, 1,1,1,1),
  df_error = c(46, 46, 46,46,46,46)
)


#4 Calculate interaction changes over time####
#4.0 Loading data####
MesocosmTime2021 <- read.delim("2021MesocosmTime.txt")

MesocosmTime2021$Temp <- as.factor(MesocosmTime2021$Temp)
MesocosmTime2021$Eutroph <- as.factor(MesocosmTime2021$Eutroph)
MesocosmTime2021$Pesticide <- as.factor(MesocosmTime2021$Pesticide)
MesocosmTime2021$Date <- as.Date(MesocosmTime2021$Date)
MesocosmTime2021$Macrophyte <- (MesocosmTime2021$P.crispus + MesocosmTime2021$Hydrilla)*100 
#construct interactions
#MesocosmTime2021$Temp_Pesticide <- interaction(MesocosmTime2021$Temp, MesocosmTime2021$Pesticide)
#MesocosmTime2021$Eutroph_Pesticide <- interaction(MesocosmTime2021$Eutroph, MesocosmTime2021$Pesticide)

#MesocosmTime2021$Eutroph_Pesticide <- revalue(MesocosmTime2021$Eutroph_Pesticide, c("0.0"="0", "E.0"="N", "0.I"="I", "E.I"="N*I"))#Rename names

#MesocosmTime2021$Treatment <- interaction(MesocosmTime2021$Temp, MesocosmTime2021$Eutroph, MesocosmTime2021$Pesticide)

#MesocosmTime2021$Eutroph_Pesticide <- revalue(MesocosmTime2021$Eutroph_Pesticide, c("0.0"="0", "1.0"="E", "0.1"="G", "1.1"="EG"))#Rename names

#{get summary stats and set up dataframe}
library(tidyverse)
#create treatment column
MesocosmTime2021 <- MesocosmTime2021 %>% unite('Treatment', Temp:Pesticide, remove = FALSE)
summary(MesocosmTime2021)

#4.1 Phytoplankton Chl a interaction####

#mean and error of each column
summary_mean <- MesocosmTime2021 %>% group_by(Treatment, Date) %>% summarise_at(c("Julian", "Phytoplankton"), mean, na.rm=TRUE)

summary_SD <- MesocosmTime2021 %>% group_by(Treatment, Date) %>% summarise_at(c("Phytoplankton"), sd, na.rm=TRUE) 

#transpose and name columns
# Transpose the data by Treatment
library(reshape2)
summary_mean <- dcast(summary_mean, Date + Julian ~ Treatment, value.var = "Phytoplankton")
summary_mean <- summary_mean %>%rename_with( ~ paste0("mean_", .x),-c(Date, Julian))

summary_SD <- dcast(summary_SD, Date ~ Treatment, value.var = "Phytoplankton")
summary_SD <- summary_SD %>% rename_with( ~ paste0("SD_", .x), -Date)

#merge datasets and ensure as.numeric 
DF <- merge(summary_mean,summary_SD, by="Date")
DF <- DF %>% mutate_at(vars(2:18), as.numeric)

#4.1.1 Additive null model####
#(1) WI {calculate null model predictions for stressor pair W and I}####

#Here I have focused on the stressors coded as W and I. You will need to run it again for other stressor pair combinations

#Calculate additive null model prediction for each row
DF <- DF %>% mutate(AdditiveNullModel_WI = mean_W_0_0 + mean_0_0_I - mean_0_0_0)

#{calculate null model predictions for stressor pair W and I}

####Generate variables for effect size calculations
#There are 6 reps and  the standard equation for stressor 1 and pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_WI = sqrt(((5*(SD_W_0_0)^2) + 5*(SD_0_0_I)^2 ) / (6+6-2))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate(j = (1-(3 / (4*(6+(n_p)-2)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_WI = sqrt( ( ((6-1)*(SD_W_0_I)^2) +((n_p)-1)*(Sd_p_WI)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for additive null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdAdditive_WI = ((mean_W_0_I -  AdditiveNullModel_WI) / s_WI) * j )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdAdditive_WI = ifelse (AdditiveNullModel_WI - mean_0_0_0 < 0, -HedgesdAdditive_WI, HedgesdAdditive_WI) )

#Vd - the variance around each interaction effect size for additive
DF <- DF %>% mutate ( VdAdditive_WI = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdAdditive_WI)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is additive or non-additive}
#It is likely to be additive with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_WI = sqrt(VdAdditive_WI))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 24)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_WI = SE_WI*T_value)
DF <- DF %>% mutate (upper_WI = HedgesdAdditive_WI+CI_WI)
DF <- DF %>% mutate (lower_WI = HedgesdAdditive_WI-CI_WI)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (interaction_WI = case_when(upper_WI>0 & lower_WI<0 ~ "Additive", upper_WI>0 & lower_WI>0 ~ 'Synergistic', upper_WI<0 & lower_WI<0 ~ 'Antagonistic'))

#(2) EI {calculate null model predictions for stressor pair E and I}####

#Here I have focused on the stressors coded as E and I. You will need to run it again for other stressor pair combinations

####Calculate additive null model prediction for each row
DF <- DF %>% mutate(AdditiveNullModel_EI = mean_0_E_0 + mean_0_0_I - mean_0_0_0)

#{calculate null model predictions for stressor pair W and I}

####Generate variables for effect size calculations
#There are 6 reps and  the standard equation for stressor 1 and pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_EI = sqrt(((5*(SD_0_E_0)^2) + 5*(SD_0_0_I)^2 ) / (6+6-2))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate( j = (1-(3 / (4*(6+(n_p)-2)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_EI = sqrt( ( ((6-1)*(SD_0_E_I)^2) +((n_p)-1)*(Sd_p_EI)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for additive null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdAdditive_EI = ((mean_0_E_I -  AdditiveNullModel_EI) / s_EI) * j )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdAdditive_EI = ifelse (AdditiveNullModel_EI - mean_0_0_0 < 0, -HedgesdAdditive_EI, HedgesdAdditive_EI) )

#Vd - the variance around each interaction effect size for additive
DF <- DF %>% mutate ( VdAdditive_EI = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdAdditive_EI)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is additive or non-additive}
#It is likely to be additive with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_EI = sqrt(VdAdditive_EI))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 24)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_EI = SE_EI*T_value)
DF <- DF %>% mutate (upper_EI = HedgesdAdditive_EI+CI_EI)
DF <- DF %>% mutate (lower_EI = HedgesdAdditive_EI-CI_EI)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (interaction_EI = case_when(upper_EI>0 & lower_EI<0 ~ "Additive", upper_EI>0 & lower_EI>0 ~ 'Synergistic', upper_EI<0 & lower_EI<0 ~ 'Antagonistic'))


#(3) WE {calculate null model predictions for stressor pair W and E}####

#Here I have focused on the stressors coded as W and E. You will need to run it again for other stressor pair combinations

####Calculate additive null model prediction for each row
DF <- DF %>% mutate(AdditiveNullModel_WE = mean_W_0_0 + mean_0_E_0 - mean_0_0_0)

#{calculate null model predictions for stressor pair W and I}

####Generate variables for effect size calculations
#There are 6 reps and  the standard equation for stressor 1 and pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_WE = sqrt(((5*(SD_W_0_0)^2) + 5*(SD_0_E_0)^2 ) / (6+6-2))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate( j = (1-(3 / (4*(6+(n_p)-2)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_WE = sqrt( ( ((6-1)*(SD_W_E_0)^2) +((n_p)-1)*(Sd_p_WE)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for additive null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdAdditive_WE = ((mean_W_E_0 -  AdditiveNullModel_WE) / s_WE) * j )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdAdditive_WE = ifelse (AdditiveNullModel_WE - mean_0_0_0 < 0, -HedgesdAdditive_WE, HedgesdAdditive_WE) )

#Vd - the variance around each interaction effect size for additive
DF <- DF %>% mutate ( VdAdditive_WE = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdAdditive_WE)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is additive or non-additive}
#It is likely to be additive with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_WE = sqrt(VdAdditive_WE))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 24)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_WE = SE_WE*T_value)
DF <- DF %>% mutate (upper_WE = HedgesdAdditive_WE+CI_WE)
DF <- DF %>% mutate (lower_WE = HedgesdAdditive_WE-CI_WE)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (interaction_WE = case_when(upper_WE>0 & lower_WE<0 ~ "Additive", upper_WE>0 & lower_WE>0 ~ 'Synergistic', upper_WE<0 & lower_WE<0 ~ 'Antagonistic'))

#(4) WEI {calculate null model predictions for three stressors}####

####Calculate additive null model prediction for each row
DF <- DF %>% mutate(AdditiveNullModel_WEI = mean_W_0_0 + mean_0_E_0 + mean_0_0_I - 2*mean_0_0_0)

#{calculate null model predictions for stressor pair W,E and I}

####Generate variables for effect size calculations
#There are 6 reps and  the standard equation for stressor 1 and pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_WEI = sqrt(((5*(SD_W_0_0)^2) + 5*(SD_0_E_0)^2 + 5*(SD_0_0_I)^2 ) / (6+6+6-3))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate( j_WEI = (1-(3 / (4*(6+6+(n_p)-3)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_WEI = sqrt( ( ((6-1)*(SD_W_E_I)^2) +((n_p)-1)*(Sd_p_WEI)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for additive null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdAdditive_WEI = ((mean_W_E_I -  AdditiveNullModel_WEI) / s_WEI) * j_WEI )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdAdditive_WEI = ifelse (AdditiveNullModel_WEI - mean_0_0_0 < 0, -HedgesdAdditive_WEI, HedgesdAdditive_WEI) )

#Vd - the variance around each interaction effect size for additive
DF <- DF %>% mutate ( VdAdditive_WEI = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdAdditive_WEI)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is additive or non-additive}
#It is likely to be additive with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_WEI = sqrt(VdAdditive_WEI))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 30)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_WEI = SE_WEI*T_value)
DF <- DF %>% mutate (upper_WEI = HedgesdAdditive_WEI+CI_WEI)
DF <- DF %>% mutate (lower_WEI = HedgesdAdditive_WEI-CI_WEI)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (interaction_WEI = case_when(upper_WEI>0 & lower_WEI<0 ~ "Additive", upper_WEI>0 & lower_WEI>0 ~ 'Synergistic', upper_WEI<0 & lower_WEI<0 ~ 'Antagonistic'))

#(5) plot ####

# use gather to merge the variables
DF_Hedgesd <- DF[,c("Date", "Julian","HedgesdAdditive_EI","HedgesdAdditive_WI","HedgesdAdditive_WE","HedgesdAdditive_WEI")] %>%
  gather(key = "StressorCombination", value = "Hedgesd", HedgesdAdditive_EI, HedgesdAdditive_WI,HedgesdAdditive_WE, HedgesdAdditive_WEI)

# Rename columns
DF_Hedgesd <- DF_Hedgesd %>%
  mutate(StressorCombination = str_replace(StressorCombination, "HedgesdAdditive_", ""))


DF_CI <- DF[,c("Date", "CI_EI","CI_WI","CI_WE","CI_WEI")] %>%
  gather(key = "StressorCombination", value = "CI", CI_EI, CI_WI,CI_WE, CI_WEI)

# Rename columns
DF_CI <- DF_CI %>%
  mutate(StressorCombination = str_replace(StressorCombination, "CI_", ""))

#merge datasets and ensure as.numeric 
DF_merged <- merge(DF_Hedgesd,DF_CI, by="row.names")
#DF_merged <- DF_merged %>% mutate_at(vars(2:18), as.numeric)


DF_merged$Date <- as.Date(DF_merged$Date)

#DF$interaction_WI <- as.factor(DF$interaction_WI)

library(ggplot2)
Phytoplankton_Inter_plot <- DF_merged %>%
  ggplot(aes(x= Date.x, y = Hedgesd, group = StressorCombination.x))+
  #geom_smooth(aes(color = StressorCombination.x),se=F, size = 1) + 
  geom_hline(yintercept = 0, linetype="solid", color = "grey75",size =1.5) +
  geom_point(aes(color = StressorCombination.x, shape= StressorCombination.x),position = position_dodge(width = 5), size = 2)+ 
  geom_errorbar(aes(ymin=Hedgesd-CI, ymax=Hedgesd+CI, color = StressorCombination.x),size=1, width = .2,position=position_dodge(width = 5))+
  scale_color_manual(values = c("black","red","blue","orange"))+
  ylab("Hedge's d") + labs (x = expression(bold(Date))) +
  #scale_y_continuous(limits=c(-9,9))+
  scale_x_date(date_breaks = "1 month",date_labels = "%b %d") +
  #ggtitle("Additive null model") +
  theme(plot.title = element_text(face = "bold", size = 14,color = "brown", hjust = 0.5,vjust=-9),
        axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(size = 12, vjust=0.5), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 12), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "top") # +  #c(0.1,0.85)  
#coord_flip() flip x and y axis
Phytoplankton_Inter_plot

tiff("Phytoplankton_Inter_plot.tiff", width = 8, height = 6, units = 'in', res = 300, compression = 'none')
Phytoplankton_Inter_plot
dev.off()



#.0 Loading data
MesocosmTime2021 <- read.delim("2021MesocosmTime.txt")

MesocosmTime2021$Temp <- as.factor(MesocosmTime2021$Temp)
MesocosmTime2021$Eutroph <- as.factor(MesocosmTime2021$Eutroph)
MesocosmTime2021$Pesticide <- as.factor(MesocosmTime2021$Pesticide)
MesocosmTime2021$Date <- as.Date(MesocosmTime2021$Date)
MesocosmTime2021$Macrophyte <- (MesocosmTime2021$P.crispus + MesocosmTime2021$Hydrilla)*100 
#construct interactions
#MesocosmTime2021$Temp_Pesticide <- interaction(MesocosmTime2021$Temp, MesocosmTime2021$Pesticide)
#MesocosmTime2021$Eutroph_Pesticide <- interaction(MesocosmTime2021$Eutroph, MesocosmTime2021$Pesticide)

#MesocosmTime2021$Eutroph_Pesticide <- revalue(MesocosmTime2021$Eutroph_Pesticide, c("0.0"="0", "E.0"="N", "0.I"="I", "E.I"="N*I"))#Rename names

#MesocosmTime2021$Treatment <- interaction(MesocosmTime2021$Temp, MesocosmTime2021$Eutroph, MesocosmTime2021$Pesticide)

#MesocosmTime2021$Eutroph_Pesticide <- revalue(MesocosmTime2021$Eutroph_Pesticide, c("0.0"="0", "1.0"="E", "0.1"="G", "1.1"="EG"))#Rename names

#{get summary stats and set up dataframe}
library(tidyverse)
#create treatment column
MesocosmTime2021 <- MesocosmTime2021 %>% unite('Treatment', Temp:Pesticide, remove = FALSE)
summary(MesocosmTime2021)

#4.2 Macrophyte interaction####

#mean and error of each column
summary_mean <- MesocosmTime2021 %>% group_by(Treatment, Date) %>% summarise_at(c("Julian", "Macrophyte"), mean, na.rm=TRUE)

summary_SD <- MesocosmTime2021 %>% group_by(Treatment, Date) %>% summarise_at(c("Macrophyte"), sd, na.rm=TRUE) 

#transpose and name columns
# Transpose the data by Treatment
library(reshape2)
summary_mean <- dcast(summary_mean, Date + Julian ~ Treatment, value.var = "Macrophyte")
summary_mean <- summary_mean %>%rename_with( ~ paste0("mean_", .x),-c(Date, Julian))

summary_SD <- dcast(summary_SD, Date ~ Treatment, value.var = "Macrophyte")
summary_SD <- summary_SD %>% rename_with( ~ paste0("SD_", .x), -Date)

#merge datasets and ensure as.numeric 
DF <- merge(summary_mean,summary_SD, by="Date")
DF <- DF %>% mutate_at(vars(2:18), as.numeric)

#4.2.1 Additive null model####
#(1) WI {calculate null model predictions for stressor pair W and I}####

#Here I have focused on the stressors coded as W and I. You will need to run it again for other stressor pair combinations

#Calculate additive null model prediction for each row
DF <- DF %>% mutate(AdditiveNullModel_WI = mean_W_0_0 + mean_0_0_I - mean_0_0_0)

#{calculate null model predictions for stressor pair W and I}

####Generate variables for effect size calculations
#There are 6 reps and  the standard equation for stressor 1 and pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_WI = sqrt(((5*(SD_W_0_0)^2) + 5*(SD_0_0_I)^2 ) / (6+6-2))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate(j = (1-(3 / (4*(6+(n_p)-2)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_WI = sqrt( ( ((6-1)*(SD_W_0_I)^2) +((n_p)-1)*(Sd_p_WI)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for additive null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdAdditive_WI = ((mean_W_0_I -  AdditiveNullModel_WI) / s_WI) * j )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdAdditive_WI = ifelse (AdditiveNullModel_WI - mean_0_0_0 < 0, -HedgesdAdditive_WI, HedgesdAdditive_WI) )

#Vd - the variance around each interaction effect size for additive
DF <- DF %>% mutate ( VdAdditive_WI = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdAdditive_WI)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is additive or non-additive}
#It is likely to be additive with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_WI = sqrt(VdAdditive_WI))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 24)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_WI = SE_WI*T_value)
DF <- DF %>% mutate (upper_WI = HedgesdAdditive_WI+CI_WI)
DF <- DF %>% mutate (lower_WI = HedgesdAdditive_WI-CI_WI)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (interaction_WI = case_when(upper_WI>0 & lower_WI<0 ~ "Additive", upper_WI>0 & lower_WI>0 ~ 'Synergistic', upper_WI<0 & lower_WI<0 ~ 'Antagonistic'))

#(2) EI {calculate null model predictions for stressor pair E and I}####

#Here I have focused on the stressors coded as E and I. You will need to run it again for other stressor pair combinations

####Calculate additive null model prediction for each row
DF <- DF %>% mutate(AdditiveNullModel_EI = mean_0_E_0 + mean_0_0_I - mean_0_0_0)

#{calculate null model predictions for stressor pair W and I}

####Generate variables for effect size calculations
#There are 6 reps and  the standard equation for stressor 1 and pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_EI = sqrt(((5*(SD_0_E_0)^2) + 5*(SD_0_0_I)^2 ) / (6+6-2))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate( j = (1-(3 / (4*(6+(n_p)-2)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_EI = sqrt( ( ((6-1)*(SD_0_E_I)^2) +((n_p)-1)*(Sd_p_EI)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for additive null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdAdditive_EI = ((mean_0_E_I -  AdditiveNullModel_EI) / s_EI) * j )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdAdditive_EI = ifelse (AdditiveNullModel_EI - mean_0_0_0 < 0, -HedgesdAdditive_EI, HedgesdAdditive_EI) )

#Vd - the variance around each interaction effect size for additive
DF <- DF %>% mutate ( VdAdditive_EI = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdAdditive_EI)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is additive or non-additive}
#It is likely to be additive with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_EI = sqrt(VdAdditive_EI))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 24)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_EI = SE_EI*T_value)
DF <- DF %>% mutate (upper_EI = HedgesdAdditive_EI+CI_EI)
DF <- DF %>% mutate (lower_EI = HedgesdAdditive_EI-CI_EI)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (interaction_EI = case_when(upper_EI>0 & lower_EI<0 ~ "Additive", upper_EI>0 & lower_EI>0 ~ 'Synergistic', upper_EI<0 & lower_EI<0 ~ 'Antagonistic'))


#(3) WE {calculate null model predictions for stressor pair W and E}####

#Here I have focused on the stressors coded as W and E. You will need to run it again for other stressor pair combinations

####Calculate additive null model prediction for each row
DF <- DF %>% mutate(AdditiveNullModel_WE = mean_W_0_0 + mean_0_E_0 - mean_0_0_0)

#{calculate null model predictions for stressor pair W and I}

####Generate variables for effect size calculations
#There are 6 reps and  the standard equation for stressor 1 and pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_WE = sqrt(((5*(SD_W_0_0)^2) + 5*(SD_0_E_0)^2 ) / (6+6-2))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate( j = (1-(3 / (4*(6+(n_p)-2)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_WE = sqrt( ( ((6-1)*(SD_W_E_0)^2) +((n_p)-1)*(Sd_p_WE)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for additive null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdAdditive_WE = ((mean_W_E_0 -  AdditiveNullModel_WE) / s_WE) * j )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdAdditive_WE = ifelse (AdditiveNullModel_WE - mean_0_0_0 < 0, -HedgesdAdditive_WE, HedgesdAdditive_WE) )

#Vd - the variance around each interaction effect size for additive
DF <- DF %>% mutate ( VdAdditive_WE = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdAdditive_WE)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is additive or non-additive}
#It is likely to be additive with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_WE = sqrt(VdAdditive_WE))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 24)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_WE = SE_WE*T_value)
DF <- DF %>% mutate (upper_WE = HedgesdAdditive_WE+CI_WE)
DF <- DF %>% mutate (lower_WE = HedgesdAdditive_WE-CI_WE)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (interaction_WE = case_when(upper_WE>0 & lower_WE<0 ~ "Additive", upper_WE>0 & lower_WE>0 ~ 'Synergistic', upper_WE<0 & lower_WE<0 ~ 'Antagonistic'))

#(4) WEI {calculate null model predictions for three stressors}####

####Calculate additive null model prediction for each row
DF <- DF %>% mutate(AdditiveNullModel_WEI = mean_W_0_0 + mean_0_E_0 + mean_0_0_I - 2*mean_0_0_0)

#{calculate null model predictions for stressor pair W,E and I}

####Generate variables for effect size calculations
#There are 6 reps and  the standard equation for stressor 1 and pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_WEI = sqrt(((5*(SD_W_0_0)^2) + 5*(SD_0_E_0)^2 + 5*(SD_0_0_I)^2 ) / (6+6+6-3))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate( j_WEI = (1-(3 / (4*(6+6+(n_p)-3)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_WEI = sqrt( ( ((6-1)*(SD_W_E_I)^2) +((n_p)-1)*(Sd_p_WEI)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for additive null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdAdditive_WEI = ((mean_W_E_I -  AdditiveNullModel_WEI) / s_WEI) * j_WEI )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdAdditive_WEI = ifelse (AdditiveNullModel_WEI - mean_0_0_0 < 0, -HedgesdAdditive_WEI, HedgesdAdditive_WEI) )

#Vd - the variance around each interaction effect size for additive
DF <- DF %>% mutate ( VdAdditive_WEI = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdAdditive_WEI)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is additive or non-additive}
#It is likely to be additive with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_WEI = sqrt(VdAdditive_WEI))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 30)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_WEI = SE_WEI*T_value)
DF <- DF %>% mutate (upper_WEI = HedgesdAdditive_WEI+CI_WEI)
DF <- DF %>% mutate (lower_WEI = HedgesdAdditive_WEI-CI_WEI)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (interaction_WEI = case_when(upper_WEI>0 & lower_WEI<0 ~ "Additive", upper_WEI>0 & lower_WEI>0 ~ 'Synergistic', upper_WEI<0 & lower_WEI<0 ~ 'Antagonistic'))

#(5) plot ####

# use gather to merge the variables
DF_Hedgesd <- DF[,c("Date", "Julian","HedgesdAdditive_EI","HedgesdAdditive_WI","HedgesdAdditive_WE","HedgesdAdditive_WEI")] %>%
  gather(key = "StressorCombination", value = "Hedgesd", HedgesdAdditive_EI, HedgesdAdditive_WI,HedgesdAdditive_WE, HedgesdAdditive_WEI)

# Rename columns
DF_Hedgesd <- DF_Hedgesd %>%
  mutate(StressorCombination = str_replace(StressorCombination, "HedgesdAdditive_", ""))


DF_CI <- DF[,c("Date", "CI_EI","CI_WI","CI_WE","CI_WEI")] %>%
  gather(key = "StressorCombination", value = "CI", CI_EI, CI_WI,CI_WE, CI_WEI)

# Rename columns
DF_CI <- DF_CI %>%
  mutate(StressorCombination = str_replace(StressorCombination, "CI_", ""))

#merge datasets and ensure as.numeric 
DF_merged <- merge(DF_Hedgesd,DF_CI, by="row.names")
#DF_merged <- DF_merged %>% mutate_at(vars(2:18), as.numeric)


DF_merged$Date <- as.Date(DF_merged$Date)

#DF$interaction_WI <- as.factor(DF$interaction_WI)

library(ggplot2)
Macrophyte_Inter_plot <- DF_merged %>%
  ggplot(aes(x= Date.x, y = Hedgesd, group = StressorCombination.x))+
  #geom_smooth(aes(color = StressorCombination.x),se=F, size = 1) + 
  geom_hline(yintercept = 0, linetype="solid", color = "grey75",size =1.5) +
  geom_point(aes(color = StressorCombination.x, shape= StressorCombination.x),position = position_dodge(width = 5), size = 2)+ 
  geom_errorbar(aes(ymin=Hedgesd-CI, ymax=Hedgesd+CI, color = StressorCombination.x),size=1, width = .2,position=position_dodge(width = 5))+
  scale_color_manual(values = c("black","red","blue","orange"))+
  ylab("Hedge's d") + labs (x = expression(bold(Date))) +
  #scale_y_continuous(limits=c(-9,9))+
  scale_x_date(date_breaks = "1 month",date_labels = "%b %d") +
  #ggtitle("Additive null model") +
  theme(plot.title = element_text(face = "bold", size = 14,color = "brown", hjust = 0.5,vjust=-9),
        axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(size = 12, vjust=0.5), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 12), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "top") # +  #c(0.1,0.85)  
#coord_flip() flip x and y axis
Macrophyte_Inter_plot

tiff("Macrophyte_Inter_plot.tiff", width = 8, height = 6, units = 'in', res = 300, compression = 'none')
Macrophyte_Inter_plot
dev.off()


#.0 Loading data
MesocosmTime2021 <- read.delim("2021MesocosmTime.txt")

MesocosmTime2021$Temp <- as.factor(MesocosmTime2021$Temp)
MesocosmTime2021$Eutroph <- as.factor(MesocosmTime2021$Eutroph)
MesocosmTime2021$Pesticide <- as.factor(MesocosmTime2021$Pesticide)
MesocosmTime2021$Date <- as.Date(MesocosmTime2021$Date)
MesocosmTime2021$Macrophyte <- (MesocosmTime2021$P.crispus + MesocosmTime2021$Hydrilla)*100 
#construct interactions
#MesocosmTime2021$Temp_Pesticide <- interaction(MesocosmTime2021$Temp, MesocosmTime2021$Pesticide)
#MesocosmTime2021$Eutroph_Pesticide <- interaction(MesocosmTime2021$Eutroph, MesocosmTime2021$Pesticide)

#MesocosmTime2021$Eutroph_Pesticide <- revalue(MesocosmTime2021$Eutroph_Pesticide, c("0.0"="0", "E.0"="N", "0.I"="I", "E.I"="N*I"))#Rename names

#MesocosmTime2021$Treatment <- interaction(MesocosmTime2021$Temp, MesocosmTime2021$Eutroph, MesocosmTime2021$Pesticide)

#MesocosmTime2021$Eutroph_Pesticide <- revalue(MesocosmTime2021$Eutroph_Pesticide, c("0.0"="0", "1.0"="E", "0.1"="G", "1.1"="EG"))#Rename names

#{get summary stats and set up dataframe}
library(tidyverse)
#create treatment column
MesocosmTime2021 <- MesocosmTime2021 %>% unite('Treatment', Temp:Pesticide, remove = FALSE)
summary(MesocosmTime2021)

#4.3 Turbidity interaction####

#mean and error of each column
summary_mean <- MesocosmTime2021 %>% group_by(Treatment, Date) %>% summarise_at(c("Julian", "Turbidity"), mean, na.rm=TRUE)

summary_SD <- MesocosmTime2021 %>% group_by(Treatment, Date) %>% summarise_at(c("Turbidity"), sd, na.rm=TRUE) 

#transpose and name columns
# Transpose the data by Treatment
library(reshape2)
summary_mean <- dcast(summary_mean, Date + Julian ~ Treatment, value.var = "Turbidity")
summary_mean <- summary_mean %>%rename_with( ~ paste0("mean_", .x),-c(Date, Julian))

summary_SD <- dcast(summary_SD, Date ~ Treatment, value.var = "Turbidity")
summary_SD <- summary_SD %>% rename_with( ~ paste0("SD_", .x), -Date)

#merge datasets and ensure as.numeric 
DF <- merge(summary_mean,summary_SD, by="Date")
DF <- DF %>% mutate_at(vars(2:18), as.numeric)

#4.3.1 Additive null model####
#(1) WI {calculate null model predictions for stressor pair W and I}####

#Here I have focused on the stressors coded as W and I. You will need to run it again for other stressor pair combinations

#Calculate additive null model prediction for each row
DF <- DF %>% mutate(AdditiveNullModel_WI = mean_W_0_0 + mean_0_0_I - mean_0_0_0)

#{calculate null model predictions for stressor pair W and I}

####Generate variables for effect size calculations
#There are 6 reps and  the standard equation for stressor 1 and pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_WI = sqrt(((5*(SD_W_0_0)^2) + 5*(SD_0_0_I)^2 ) / (6+6-2))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate(j = (1-(3 / (4*(6+(n_p)-2)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_WI = sqrt( ( ((6-1)*(SD_W_0_I)^2) +((n_p)-1)*(Sd_p_WI)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for additive null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdAdditive_WI = ((mean_W_0_I -  AdditiveNullModel_WI) / s_WI) * j )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdAdditive_WI = ifelse (AdditiveNullModel_WI - mean_0_0_0 < 0, -HedgesdAdditive_WI, HedgesdAdditive_WI) )

#Vd - the variance around each interaction effect size for additive
DF <- DF %>% mutate ( VdAdditive_WI = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdAdditive_WI)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is additive or non-additive}
#It is likely to be additive with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_WI = sqrt(VdAdditive_WI))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 24)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_WI = SE_WI*T_value)
DF <- DF %>% mutate (upper_WI = HedgesdAdditive_WI+CI_WI)
DF <- DF %>% mutate (lower_WI = HedgesdAdditive_WI-CI_WI)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (interaction_WI = case_when(upper_WI>0 & lower_WI<0 ~ "Additive", upper_WI>0 & lower_WI>0 ~ 'Synergistic', upper_WI<0 & lower_WI<0 ~ 'Antagonistic'))

#(2) EI {calculate null model predictions for stressor pair E and I}####

#Here I have focused on the stressors coded as E and I. You will need to run it again for other stressor pair combinations

####Calculate additive null model prediction for each row
DF <- DF %>% mutate(AdditiveNullModel_EI = mean_0_E_0 + mean_0_0_I - mean_0_0_0)

#{calculate null model predictions for stressor pair W and I}

####Generate variables for effect size calculations
#There are 6 reps and  the standard equation for stressor 1 and pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_EI = sqrt(((5*(SD_0_E_0)^2) + 5*(SD_0_0_I)^2 ) / (6+6-2))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate( j = (1-(3 / (4*(6+(n_p)-2)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_EI = sqrt( ( ((6-1)*(SD_0_E_I)^2) +((n_p)-1)*(Sd_p_EI)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for additive null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdAdditive_EI = ((mean_0_E_I -  AdditiveNullModel_EI) / s_EI) * j )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdAdditive_EI = ifelse (AdditiveNullModel_EI - mean_0_0_0 < 0, -HedgesdAdditive_EI, HedgesdAdditive_EI) )

#Vd - the variance around each interaction effect size for additive
DF <- DF %>% mutate ( VdAdditive_EI = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdAdditive_EI)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is additive or non-additive}
#It is likely to be additive with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_EI = sqrt(VdAdditive_EI))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 24)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_EI = SE_EI*T_value)
DF <- DF %>% mutate (upper_EI = HedgesdAdditive_EI+CI_EI)
DF <- DF %>% mutate (lower_EI = HedgesdAdditive_EI-CI_EI)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (interaction_EI = case_when(upper_EI>0 & lower_EI<0 ~ "Additive", upper_EI>0 & lower_EI>0 ~ 'Synergistic', upper_EI<0 & lower_EI<0 ~ 'Antagonistic'))


#(3) WE {calculate null model predictions for stressor pair W and E}####

#Here I have focused on the stressors coded as W and E. You will need to run it again for other stressor pair combinations

####Calculate additive null model prediction for each row
DF <- DF %>% mutate(AdditiveNullModel_WE = mean_W_0_0 + mean_0_E_0 - mean_0_0_0)

#{calculate null model predictions for stressor pair W and I}

####Generate variables for effect size calculations
#There are 6 reps and  the standard equation for stressor 1 and pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_WE = sqrt(((5*(SD_W_0_0)^2) + 5*(SD_0_E_0)^2 ) / (6+6-2))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate( j = (1-(3 / (4*(6+(n_p)-2)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_WE = sqrt( ( ((6-1)*(SD_W_E_0)^2) +((n_p)-1)*(Sd_p_WE)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for additive null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdAdditive_WE = ((mean_W_E_0 -  AdditiveNullModel_WE) / s_WE) * j )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdAdditive_WE = ifelse (AdditiveNullModel_WE - mean_0_0_0 < 0, -HedgesdAdditive_WE, HedgesdAdditive_WE) )

#Vd - the variance around each interaction effect size for additive
DF <- DF %>% mutate ( VdAdditive_WE = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdAdditive_WE)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is additive or non-additive}
#It is likely to be additive with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_WE = sqrt(VdAdditive_WE))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 24)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_WE = SE_WE*T_value)
DF <- DF %>% mutate (upper_WE = HedgesdAdditive_WE+CI_WE)
DF <- DF %>% mutate (lower_WE = HedgesdAdditive_WE-CI_WE)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (interaction_WE = case_when(upper_WE>0 & lower_WE<0 ~ "Additive", upper_WE>0 & lower_WE>0 ~ 'Synergistic', upper_WE<0 & lower_WE<0 ~ 'Antagonistic'))

#(4) WEI {calculate null model predictions for three stressors}####

####Calculate additive null model prediction for each row
DF <- DF %>% mutate(AdditiveNullModel_WEI = mean_W_0_0 + mean_0_E_0 + mean_0_0_I - 2*mean_0_0_0)

#{calculate null model predictions for stressor pair W,E and I}

####Generate variables for effect size calculations
#There are 6 reps and  the standard equation for stressor 1 and pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_WEI = sqrt(((5*(SD_W_0_0)^2) + 5*(SD_0_E_0)^2 + 5*(SD_0_0_I)^2 ) / (6+6+6-3))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate( j_WEI = (1-(3 / (4*(6+6+(n_p)-3)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_WEI = sqrt( ( ((6-1)*(SD_W_E_I)^2) +((n_p)-1)*(Sd_p_WEI)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for additive null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdAdditive_WEI = ((mean_W_E_I -  AdditiveNullModel_WEI) / s_WEI) * j_WEI )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdAdditive_WEI = ifelse (AdditiveNullModel_WEI - mean_0_0_0 < 0, -HedgesdAdditive_WEI, HedgesdAdditive_WEI) )

#Vd - the variance around each interaction effect size for additive
DF <- DF %>% mutate ( VdAdditive_WEI = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdAdditive_WEI)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is additive or non-additive}
#It is likely to be additive with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_WEI = sqrt(VdAdditive_WEI))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 30)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_WEI = SE_WEI*T_value)
DF <- DF %>% mutate (upper_WEI = HedgesdAdditive_WEI+CI_WEI)
DF <- DF %>% mutate (lower_WEI = HedgesdAdditive_WEI-CI_WEI)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (interaction_WEI = case_when(upper_WEI>0 & lower_WEI<0 ~ "Additive", upper_WEI>0 & lower_WEI>0 ~ 'Synergistic', upper_WEI<0 & lower_WEI<0 ~ 'Antagonistic'))

#(5) plot ####

# use gather to merge the variables
DF_Hedgesd <- DF[,c("Date", "Julian","HedgesdAdditive_EI","HedgesdAdditive_WI","HedgesdAdditive_WE","HedgesdAdditive_WEI")] %>%
  gather(key = "StressorCombination", value = "Hedgesd", HedgesdAdditive_EI, HedgesdAdditive_WI,HedgesdAdditive_WE, HedgesdAdditive_WEI)

# Rename columns
DF_Hedgesd <- DF_Hedgesd %>%
  mutate(StressorCombination = str_replace(StressorCombination, "HedgesdAdditive_", ""))


DF_CI <- DF[,c("Date", "CI_EI","CI_WI","CI_WE","CI_WEI")] %>%
  gather(key = "StressorCombination", value = "CI", CI_EI, CI_WI,CI_WE, CI_WEI)

# Rename columns
DF_CI <- DF_CI %>%
  mutate(StressorCombination = str_replace(StressorCombination, "CI_", ""))

#merge datasets and ensure as.numeric 
DF_merged <- merge(DF_Hedgesd,DF_CI, by="row.names")
#DF_merged <- DF_merged %>% mutate_at(vars(2:18), as.numeric)


DF_merged$Date <- as.Date(DF_merged$Date)

#DF$interaction_WI <- as.factor(DF$interaction_WI)

library(ggplot2)
Turbidity_Inter_plot <- DF_merged %>%
  ggplot(aes(x= Date.x, y = Hedgesd, group = StressorCombination.x))+
  #geom_smooth(aes(color = StressorCombination.x),se=F, size = 1) + 
  geom_hline(yintercept = 0, linetype="solid", color = "grey75",size =1.5) +
  geom_point(aes(color = StressorCombination.x, shape= StressorCombination.x),position = position_dodge(width = 5), size = 2)+ 
  geom_errorbar(aes(ymin=Hedgesd-CI, ymax=Hedgesd+CI, color = StressorCombination.x),size=1, width = .2,position=position_dodge(width = 5))+
  scale_color_manual(values = c("black","red","blue","orange"))+
  ylab("Hedge's d") + labs (x = expression(bold(Date))) +
  #scale_y_continuous(limits=c(-9,9))+
  scale_x_date(date_breaks = "1 month",date_labels = "%b %d") +
  #ggtitle("Additive null model") +
  theme(plot.title = element_text(face = "bold", size = 14,color = "brown", hjust = 0.5,vjust=-9),
        axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(size = 12, vjust=0.5), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 12), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "top") # +  #c(0.1,0.85)  
#coord_flip() flip x and y axis
Turbidity_Inter_plot

tiff("Turbidity_Inter_plot.tiff", width = 8, height = 6, units = 'in', res = 300, compression = 'none')
Turbidity_Inter_plot
dev.off()


#4.4 Periphyton interaction####

#mean and error of each column
summary_mean <- MesocosmTime2021 %>% group_by(Treatment, Date) %>% summarise_at(c("Julian", "Periphyton"), mean, na.rm=TRUE)

summary_SD <- MesocosmTime2021 %>% group_by(Treatment, Date) %>% summarise_at(c("Periphyton"), sd, na.rm=TRUE) 

#transpose and name columns
# Transpose the data by Treatment
library(reshape2)
summary_mean <- dcast(summary_mean, Date + Julian ~ Treatment, value.var = "Periphyton")
summary_mean <- summary_mean %>%rename_with( ~ paste0("mean_", .x),-c(Date, Julian))

summary_SD <- dcast(summary_SD, Date ~ Treatment, value.var = "Periphyton")
summary_SD <- summary_SD %>% rename_with( ~ paste0("SD_", .x), -Date)

#merge datasets and ensure as.numeric 
DF <- merge(summary_mean,summary_SD, by="Date")
DF <- DF %>% mutate_at(vars(2:18), as.numeric)

#4.4.1 Additive null model####
#(1) WI {calculate null model predictions for stressor pair W and I}####

#Here I have focused on the stressors coded as W and I. You will need to run it again for other stressor pair combinations

#Calculate additive null model prediction for each row
DF <- DF %>% mutate(AdditiveNullModel_WI = mean_W_0_0 + mean_0_0_I - mean_0_0_0)

#{calculate null model predictions for stressor pair W and I}

####Generate variables for effect size calculations
#There are 6 reps and  the standard equation for stressor 1 and pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_WI = sqrt(((5*(SD_W_0_0)^2) + 5*(SD_0_0_I)^2 ) / (6+6-2))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate(j = (1-(3 / (4*(6+(n_p)-2)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_WI = sqrt( ( ((6-1)*(SD_W_0_I)^2) +((n_p)-1)*(Sd_p_WI)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for additive null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdAdditive_WI = ((mean_W_0_I -  AdditiveNullModel_WI) / s_WI) * j )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdAdditive_WI = ifelse (AdditiveNullModel_WI - mean_0_0_0 < 0, -HedgesdAdditive_WI, HedgesdAdditive_WI) )

#Vd - the variance around each interaction effect size for additive
DF <- DF %>% mutate ( VdAdditive_WI = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdAdditive_WI)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is additive or non-additive}
#It is likely to be additive with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_WI = sqrt(VdAdditive_WI))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 24)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_WI = SE_WI*T_value)
DF <- DF %>% mutate (upper_WI = HedgesdAdditive_WI+CI_WI)
DF <- DF %>% mutate (lower_WI = HedgesdAdditive_WI-CI_WI)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (interaction_WI = case_when(upper_WI>0 & lower_WI<0 ~ "Additive", upper_WI>0 & lower_WI>0 ~ 'Synergistic', upper_WI<0 & lower_WI<0 ~ 'Antagonistic'))

#(2) EI {calculate null model predictions for stressor pair E and I}####

#Here I have focused on the stressors coded as E and I. You will need to run it again for other stressor pair combinations

####Calculate additive null model prediction for each row
DF <- DF %>% mutate(AdditiveNullModel_EI = mean_0_E_0 + mean_0_0_I - mean_0_0_0)

#{calculate null model predictions for stressor pair W and I}

####Generate variables for effect size calculations
#There are 6 reps and  the standard equation for stressor 1 and pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_EI = sqrt(((5*(SD_0_E_0)^2) + 5*(SD_0_0_I)^2 ) / (6+6-2))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate( j = (1-(3 / (4*(6+(n_p)-2)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_EI = sqrt( ( ((6-1)*(SD_0_E_I)^2) +((n_p)-1)*(Sd_p_EI)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for additive null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdAdditive_EI = ((mean_0_E_I -  AdditiveNullModel_EI) / s_EI) * j )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdAdditive_EI = ifelse (AdditiveNullModel_EI - mean_0_0_0 < 0, -HedgesdAdditive_EI, HedgesdAdditive_EI) )

#Vd - the variance around each interaction effect size for additive
DF <- DF %>% mutate ( VdAdditive_EI = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdAdditive_EI)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is additive or non-additive}
#It is likely to be additive with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_EI = sqrt(VdAdditive_EI))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 24)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_EI = SE_EI*T_value)
DF <- DF %>% mutate (upper_EI = HedgesdAdditive_EI+CI_EI)
DF <- DF %>% mutate (lower_EI = HedgesdAdditive_EI-CI_EI)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (interaction_EI = case_when(upper_EI>0 & lower_EI<0 ~ "Additive", upper_EI>0 & lower_EI>0 ~ 'Synergistic', upper_EI<0 & lower_EI<0 ~ 'Antagonistic'))


#(3) WE {calculate null model predictions for stressor pair W and E}####

#Here I have focused on the stressors coded as W and E. You will need to run it again for other stressor pair combinations

####Calculate additive null model prediction for each row
DF <- DF %>% mutate(AdditiveNullModel_WE = mean_W_0_0 + mean_0_E_0 - mean_0_0_0)

#{calculate null model predictions for stressor pair W and I}

####Generate variables for effect size calculations
#There are 6 reps and  the standard equation for stressor 1 and pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_WE = sqrt(((5*(SD_W_0_0)^2) + 5*(SD_0_E_0)^2 ) / (6+6-2))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate( j = (1-(3 / (4*(6+(n_p)-2)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_WE = sqrt( ( ((6-1)*(SD_W_E_0)^2) +((n_p)-1)*(Sd_p_WE)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for additive null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdAdditive_WE = ((mean_W_E_0 -  AdditiveNullModel_WE) / s_WE) * j )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdAdditive_WE = ifelse (AdditiveNullModel_WE - mean_0_0_0 < 0, -HedgesdAdditive_WE, HedgesdAdditive_WE) )

#Vd - the variance around each interaction effect size for additive
DF <- DF %>% mutate ( VdAdditive_WE = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdAdditive_WE)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is additive or non-additive}
#It is likely to be additive with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_WE = sqrt(VdAdditive_WE))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 24)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_WE = SE_WE*T_value)
DF <- DF %>% mutate (upper_WE = HedgesdAdditive_WE+CI_WE)
DF <- DF %>% mutate (lower_WE = HedgesdAdditive_WE-CI_WE)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (interaction_WE = case_when(upper_WE>0 & lower_WE<0 ~ "Additive", upper_WE>0 & lower_WE>0 ~ 'Synergistic', upper_WE<0 & lower_WE<0 ~ 'Antagonistic'))

#(4) WEI {calculate null model predictions for three stressors}####

####Calculate additive null model prediction for each row
DF <- DF %>% mutate(AdditiveNullModel_WEI = mean_W_0_0 + mean_0_E_0 + mean_0_0_I - 2*mean_0_0_0)

#{calculate null model predictions for stressor pair W,E and I}

####Generate variables for effect size calculations
#There are 6 reps and  the standard equation for stressor 1 and pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_WEI = sqrt(((5*(SD_W_0_0)^2) + 5*(SD_0_E_0)^2 + 5*(SD_0_0_I)^2 ) / (6+6+6-3))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate( j_WEI = (1-(3 / (4*(6+6+(n_p)-3)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_WEI = sqrt( ( ((6-1)*(SD_W_E_I)^2) +((n_p)-1)*(Sd_p_WEI)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for additive null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdAdditive_WEI = ((mean_W_E_I -  AdditiveNullModel_WEI) / s_WEI) * j_WEI )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdAdditive_WEI = ifelse (AdditiveNullModel_WEI - mean_0_0_0 < 0, -HedgesdAdditive_WEI, HedgesdAdditive_WEI) )

#Vd - the variance around each interaction effect size for additive
DF <- DF %>% mutate ( VdAdditive_WEI = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdAdditive_WEI)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is additive or non-additive}
#It is likely to be additive with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_WEI = sqrt(VdAdditive_WEI))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 30)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_WEI = SE_WEI*T_value)
DF <- DF %>% mutate (upper_WEI = HedgesdAdditive_WEI+CI_WEI)
DF <- DF %>% mutate (lower_WEI = HedgesdAdditive_WEI-CI_WEI)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (interaction_WEI = case_when(upper_WEI>0 & lower_WEI<0 ~ "Additive", upper_WEI>0 & lower_WEI>0 ~ 'Synergistic', upper_WEI<0 & lower_WEI<0 ~ 'Antagonistic'))

#(5) plot ####

# use gather to merge the variables
DF_Hedgesd <- DF[,c("Date", "Julian","HedgesdAdditive_EI","HedgesdAdditive_WI","HedgesdAdditive_WE","HedgesdAdditive_WEI")] %>%
  gather(key = "StressorCombination", value = "Hedgesd", HedgesdAdditive_EI, HedgesdAdditive_WI,HedgesdAdditive_WE, HedgesdAdditive_WEI)

# Rename columns
DF_Hedgesd <- DF_Hedgesd %>%
  mutate(StressorCombination = str_replace(StressorCombination, "HedgesdAdditive_", ""))


DF_CI <- DF[,c("Date", "CI_EI","CI_WI","CI_WE","CI_WEI")] %>%
  gather(key = "StressorCombination", value = "CI", CI_EI, CI_WI,CI_WE, CI_WEI)

# Rename columns
DF_CI <- DF_CI %>%
  mutate(StressorCombination = str_replace(StressorCombination, "CI_", ""))

#merge datasets and ensure as.numeric 
DF_merged <- merge(DF_Hedgesd,DF_CI, by="row.names")
#DF_merged <- DF_merged %>% mutate_at(vars(2:18), as.numeric)


DF_merged$Date <- as.Date(DF_merged$Date)

#DF$interaction_WI <- as.factor(DF$interaction_WI)

library(ggplot2)
Periphyton_Inter_plot <- DF_merged %>%
  ggplot(aes(x= Date.x, y = Hedgesd, group = StressorCombination.x))+
  #geom_smooth(aes(color = StressorCombination.x),se=F, size = 1) + 
  geom_hline(yintercept = 0, linetype="solid", color = "grey75",size =1.5) +
  geom_point(aes(color = StressorCombination.x, shape= StressorCombination.x),position = position_dodge(width = 5), size = 2)+ 
  geom_errorbar(aes(ymin=Hedgesd-CI, ymax=Hedgesd+CI, color = StressorCombination.x),size=1, width = .2,position=position_dodge(width = 5))+
  scale_color_manual(values = c("black","red","blue","orange"))+
  ylab("Hedge's d") + labs (x = expression(bold(Date))) +
  #scale_y_continuous(limits=c(-9,9))+
  scale_x_date(date_breaks = "1 month",date_labels = "%b %d") +
  #ggtitle("Additive null model") +
  theme(plot.title = element_text(face = "bold", size = 14,color = "brown", hjust = 0.5,vjust=-9),
        axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(size = 12, vjust=0.5), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 12), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "top") # +  #c(0.1,0.85)  
#coord_flip() flip x and y axis
Periphyton_Inter_plot

tiff("Periphyton_Inter_plot.tiff", width = 8, height = 6, units = 'in', res = 300, compression = 'none')
Periphyton_Inter_plot
dev.off()
