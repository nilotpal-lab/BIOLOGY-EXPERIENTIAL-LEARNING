# **Title: Multiple stressors simplify freshwater food webs**

 Access this dataset on Dryad (doi:10.5061/dryad.866t1g1zj)

 We have conducted a large-scale mesocosm experiment to quantify the single and combined effects of three common anthropogenic stressors, including warming, increased nutrient loading, and insecticide pollution, on the network structure and energetic processes of shallow lake food webs. We constructed similar food webs at the beginning of the experiment, monitored water quality and biological parameters during the experiment and quantified food web components at the end of the experiment.

We have submitted our raw data water quality and biological parameters during the experiment (Parameters_over_time.xlsx), biomass and abundance of food web components at the end of the experiment (Food_web_components.xlsx). A multilevel metadata includes food web meta data for each pond and sum of the six ponds of each treatment: (FoodwebMetadata.zip). R scripts (MesocosmFinal.R; TimeSeries.R; Interaction-null-models.R; FoodwebProperties.R)

 **Food_web_components.xlsx**:

The file includes the biomass and abundance of all food web components at the end of the experiment. This file consists of two sheets, the first sheet is the code explanation for the data of the second sheet. This data is the input data for R codes: MesocosmFinal.R and Interaction-null-models.R.

•         Pond: Code for each mesocosm pond

•         Temp: Warming treatment, 0 indicates ambient, W indicates heated

•         Eutroph: Nutrient loading treatment, 0 indicates no addtion of nutrients, N indicates nitrogen and phosphorus addtion

•         Insecticide: Insecticide treatment, 0 indicates no addition of insecticide, I indicates insecticide addtion

•         Code: Treatment code for each pond

•         Hydrilla : Biomass of Potamogeton cripus at the end of the experiment (g per mesocosm)

•         P.crispus: Biomass of Hydrilla verticillata at the end of the experiment (g per mesocosm)

•         Carp_B: Biomass of the crucian carp Carassius auratus auratus at the end of the experiment (g per mesocosm)

•         Carp_N: Number of the crucian carp Carassius auratus auratus at the end of the experiment

•         Rhodeus_B: Biomass of the bitterling Rhodeus sinensis at the end of the experiment (g per mesocosm)

•         Rhodeus_N: Number of the bitterling Rhodeus sinensis at the end of the experiment

•         Shrimp_B: Biomass of the shrimp Macrobrachium nipponense at the end of the experiment (g per mesocosm)

•         Shrimp_N: Number of the shrimp Macrobrachium nipponense at the end of the experiment

•         Predator_Species: Number of the predator species, including fish and shrimp

•         Bellamya_N : Number of the snail Bellamya aeruginosa at the end of the experiment

•         Bellamya_B:      Biomass of the snail Bellamya aeruginosa at the end of the experiment (g per mesocosm)

•         Radix_N: Number of the snail Radix swinhoei at the end of the experiment

•         Radix_B: Biomass of the snail Radix swinhoei at the end of the experiment (g per mesocosm)

•         Cladocera_A: Abundance of zooplankton Cladocera at the end of the experiment (ind. per mesocosm)

•         Copepoda_A: Abundance of zooplankton Copepoda at the end of the experiment (ind. per mesocosm)

•         Rotifers_A: Abundance of zooplankton Rotifers at the end of the experiment (ind. per mesocosm)

•         Cladocera_B: Total biomass of zooplankton Cladocera at the end of the experiment (g per mesocosm)

•         Copepoda_B: Total biomass of zooplankton Copepoda at the end of the experiment (g per mesocosm)

•         Rotifers_B: Total biomass of zooplankton Rotifers at the end of the experiment (g per mesocosm)

•         Oligochaeta_B: Total biomass of zoobenthos Oligochaeta at the end of the experiment (g per mesocosm)

•         Oligochaeta_N: Abundance of zoobenthos Oligochaeta at the end of the experiment (ind. per mesocosm)

•         Snail_Other_B: Total biomass of some other tiny snails at the end of the experiment (g per mesocosm)

•         Snail_Other_N: Abundance of some other tiny snails at the end of the experiment (ind. per mesocosm)

•         Insecta_B: Total biomass of insecta at the end of the experiment (g per mesocosm)

•         Insecta_N: Abundance of insecta at the end of the experiment (ind. per mesocosm)

•         Phytoplankton_B: Total biomass of phytoplankton at the end of the experiment (g per mesocosm)

•         Phytoplankton_A: Total abundance of phytoplankton at the end of the experiment (ind. per mesocosm)

•         Periphyton_B: Total biomass of periphyton at the end of the experiment (g per mesocosm)

•         Periphyton_A: Total abundance of periphyton at the end of the experiment (ind. per mesocosm)

 

**Parameters_over_time.xlsx:**

The file includes the background water quality and biological parameters which has measured during the experiment. This file consists of two sheets, the first sheet is the code explanation for the data of the second sheet. This data is the input data for R codes: TimeSeries.R.

•         Pond: Code for each mesocosm pond

•         Temp: Warming treatment, 0 indicates ambient, W indicates heated

•         Eutroph:       Nutrient loading treatment, 0 indicates no addtion of nutrients, N indicates nitrogen and phosphorus addtion

•         Insecticide: Insecticide treatment, 0 indicates no addition of insecticide, I indicates insecticide addtion

•         Code: Treatment code for each pond

•         Julian: Julian day of the year

•         Date: Date of each sampling day

•         P.crispus: PVI of Potamogeton cripus

•         Hydrilla : PVI of Hydrilla verticillata

•         DO: Total dissolved oxygen concentration in the water column during the experiment (mg L-1)

•         pH: pH in the water column in the water column during the experiment

•         Conductivity: Conductivity in the water column during the experiment (µs cm-2)

•         Turbidity: Water turbidity in each sampling day (NTU)

•         TN: Total nitrogen concentration in the water column during the experiment (mg L-1)

•         NH4: Ammonia nitrogen concentration in the water column during the experiment (mg L-1)

•         NO3: Nitrate concentration in the water column during the experiment (mg L-1)

•         TP: Total phosphorus concentration in the water column during the experiment (mg L-1)

•         PO4: Phosphate concentration in the water column during the experiment (mg L-1)

•         Phytoplankton: Chl a concentration of phytoplankton during the experiment (µg L-1)

•         Periphyton: Chl a concentration of periphyton during the experiment (µg cm-2)

 **FoodwebMetadata.zip**:

This file includes food web meta data for each pond and sum of the six ponds of each treatment. For each web, including three CSV files: nodes.csv, properties.csv, and trophic.links.csv. These files are arranged in accordance to the input format of R package *cheddar*.

nodes.csv

•         node: each node represents a group of organisms in the food web

•         category: the category of the organisms belongs

•         functional.group: the functional group of the organisms belongs

•         M: mean body biomass of each individual

•         N: abundance of the organism

•         Code: code number of each organism

•         Totalbiomass: the total biomass of each group of organisms in the food web

 properties.csv

•         title: the code of the pond

•         M.units: unit of the mean body biomass

•         N.units: unit of the abundance

•         Temp: Warming treatment, 0 indicates ambient, W indicates heated

•         Eutroph:       Nutrient loading treatment, 0 indicates no addtion of nutrients, N indicates nitrogen and phosphorus addition

•         Pesticide: Insecticide treatment, 0 indicates no addition of insecticide, I indicates insecticide addition

•         Pondnumber: the code number of the pond

trophic.links.csv

•         resource: the food for the consumer

•         consumer: the consumer of the food

 **MesocosmFinal.R:** the input data is from Food_web_components.xlsx, and the file includes the codes for Fig. 1, Fig. S7, Fig. S9, Fig. S10 and Table S3.

 **FoodwebProperties.R**: the input data is from FoodwebMetadata.zip, and the file includes the codes for food web structure traits and energy fluxes analysis for each food web, producing Fig. 2, Fig. 3, Fig. S4, Fig. S5, Fig. S6, Fig. S8, Fig. S11, Fig. S12 and Table 1.

 **TimeSeries.R**: the input data is from Parameters_over_time.xlsx, and the file includes the codes for Fig. S13, Fig. S14, Fig. S15 and Table S4.

 **Interaction-null-models.R**: the input data is from Food_web_components.xlsx, and the file includes the codes for Fig. S18 and Fig.S19.

 Annotations are provided throughout the script through 1) library loading, 2) dataset loading and cleaning, 3) analyses, and 4) figure creation. If you have any problems with the data or codes, please feel free to contact Peiyu Zhang ([zhangpeiyu@ihb.ac.cn](mailto:zhangpeiyu@ihb.ac.cn)).
