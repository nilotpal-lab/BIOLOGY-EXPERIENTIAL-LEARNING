#Sys.setlocale("LC_ALL", "English")# change locale to English

#load the packages#
#library(nlme)

library(gridExtra)
library(cowplot)
library(grid)
library(car)
library(lme4)
#plot
library(ggplot2)

#0 Data loading####
Final2021<- read.delim("2021Final.txt")

Final2021$Temp <- as.factor(Final2021$Temp)
Final2021$Eutroph <- as.factor(Final2021$Eutroph)
Final2021$Pesticide <- as.factor(Final2021$Pesticide)

#construct interactions
Final2021$Temp_Pesticide <- interaction(Final2021$Temp, Final2021$Pesticide)
Final2021$Eutroph_Pesticide <- interaction(Final2021$Eutroph, Final2021$Pesticide)
library(plyr)
Final2021$Eutroph_Pesticide <- revalue(Final2021$Eutroph_Pesticide, c("0.0"="0", "N.0"="N", "0.I"="I", "N.I"="N*I"))#Rename names
Final2021$Treatment <- interaction(Final2021$Temp,Final2021$Eutroph, Final2021$Pesticide)

#1.1 Primary producers####
##1.1.1 Total Macrophyte biomass####
Final2021$Macrophyte <-Final2021$Hydrilla + Final2021$P.crispus

library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
Macrophyte_Cal <- ddply(Final2021, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(Macrophyte)), 
                   mean = mean(Macrophyte,na.rm=TRUE),
                   sd = sd(Macrophyte,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Macrophyte_Cal

Macrophyte_Cal$Treatment <- interaction(Macrophyte_Cal$Eutroph, Macrophyte_Cal$Pesticide,Macrophyte_Cal$Temp)
Macrophyte_Cal$Treatment1 <- interaction(Macrophyte_Cal$Eutroph, Macrophyte_Cal$Pesticide)
Macrophyte_Cal$Treatment1 <- revalue(Macrophyte_Cal$Treatment1, c("0.0"="0", "N.0"="N", "0.I"="I", "N.I"="N*I"))#Rename names

Macrophyte_plot <- ggplot(data=Macrophyte_Cal, aes(x = Treatment1, y = mean,fill=Temp)) + #
  geom_errorbar(aes( ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  scale_fill_manual(values = c("#00CCFF","red"))+
  xlab("Treatments") + labs (y = expression(bold(Macrophytes))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)top
Macrophyte_plot

tiff("Macrophyte_plot.tiff", width = 2.5, height = 2, units = 'in', res = 300, compression = 'none')
Macrophyte_plot
dev.off()

#glm analysis 
m1 <- glm(log(Macrophyte+1) ~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
Anova(m1, type = "II")

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- glm(log(Macrophyte+1) ~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- glm(log(Macrophyte+1) ~ Pesticide, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
Anova(m1)


library(effectsize)

m_interaction2 <- lm(
  log(Macrophyte+1) ~ Pesticide,
  data = Final2021, 
  contrasts = list(
    Pesticide = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, partial = T,type = 2))


##1.1.2 Phytoplankton####
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
Phytoplankton_B_Cal <- ddply(Final2021, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(Phytoplankton_B)), 
                        mean = mean(Phytoplankton_B,na.rm=TRUE),
                        sd = sd(Phytoplankton_B,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Phytoplankton_B_Cal

Phytoplankton_B_Cal$Treatment <- interaction(Phytoplankton_B_Cal$Eutroph, Phytoplankton_B_Cal$Pesticide,Phytoplankton_B_Cal$Temp)
Phytoplankton_B_Cal$Treatment1 <- interaction(Phytoplankton_B_Cal$Eutroph, Phytoplankton_B_Cal$Pesticide)
Phytoplankton_B_Cal$Treatment1 <- revalue(Phytoplankton_B_Cal$Treatment1, c("0.0"="0", "N.0"="N", "0.I"="I", "N.I"="N*I"))#Rename names

Phytoplankton_B_plot <- ggplot(data=Phytoplankton_B_Cal, aes(x = Treatment1, y = mean,fill=Temp)) + #
  geom_errorbar(aes( ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  scale_fill_manual(values = c("#00CCFF","red"))+
  xlab("Treatments") + labs (y = expression(bold(Phytoplankton))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)
Phytoplankton_B_plot

tiff("Phytoplankton_B_plot.tiff", width = 2.5, height = 2, units = 'in', res = 300, compression = 'none')
Phytoplankton_B_plot
dev.off()

#glm analysis 
m1 <- glm(log(Phytoplankton_B+1) ~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
Anova(m1, type = "II")

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- glm(log(Phytoplankton_B+1) ~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- lm(log(Phytoplankton_B+1) ~ Pesticide + Eutroph, data = Final2021)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

library(effectsize)

m_interaction2 <- lm(
  log(Phytoplankton_B+1) ~ Pesticide + Eutroph,
  data = Final2021, 
  contrasts = list(
    Eutroph = "contr.sum",
    Pesticide = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, partial = T,type = 2))

##1.1.3 Periphyton####
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
Periphyton_B_Cal <- ddply(Final2021, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(Periphyton_B)), 
                             mean = mean(Periphyton_B,na.rm=TRUE),
                             sd = sd(Periphyton_B,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Periphyton_B_Cal

Periphyton_B_Cal$Treatment <- interaction(Periphyton_B_Cal$Eutroph, Periphyton_B_Cal$Pesticide,Periphyton_B_Cal$Temp)
Periphyton_B_Cal$Treatment1 <- interaction(Periphyton_B_Cal$Eutroph, Periphyton_B_Cal$Pesticide)
Periphyton_B_Cal$Treatment1 <- revalue(Periphyton_B_Cal$Treatment1, c("0.0"="0", "N.0"="N", "0.I"="I", "N.I"="N*I"))#Rename names

Periphyton_B_plot <- ggplot(data=Periphyton_B_Cal, aes(x = Treatment1, y = mean,fill=Temp)) + #
  geom_errorbar(aes( ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  scale_fill_manual(values = c("#00CCFF","red"))+
  xlab("Treatments") + labs (y = expression(bold(Periphyton))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)
Periphyton_B_plot

tiff("Periphyton_B_plot.tiff", width = 2.5, height = 2, units = 'in', res = 300, compression = 'none')
Periphyton_B_plot
dev.off()

#glm analysis 
m1 <- glm(Periphyton_B ~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
Anova(m1, type = "II")

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- glm(Periphyton_B ~ Pesticide * Temp * Eutroph, data = Final2021,family=quasipoisson(link = "log"))
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- glm(Periphyton_B ~ 1, data = Final2021,family=quasipoisson(link = "log"))#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

##1.1.4 Total Primary producer####
Final2021$Producer <-Final2021$Hydrilla + Final2021$P.crispus + Final2021$Phytoplankton_B + Final2021$Periphyton_B
                
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
Producer_Cal <- ddply(Final2021, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(Producer)), 
                          mean = mean(Producer,na.rm=TRUE),
                          sd = sd(Producer,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Producer_Cal

Producer_Cal$Treatment <- interaction(Producer_Cal$Eutroph, Producer_Cal$Pesticide,Producer_Cal$Temp)
Producer_Cal$Treatment1 <- interaction(Producer_Cal$Eutroph, Producer_Cal$Pesticide)
Producer_Cal$Treatment1 <- revalue(Producer_Cal$Treatment1, c("0.0"="0", "N.0"="N", "0.I"="I", "N.I"="N*I"))#Rename names

Producer_B_plot <- ggplot(data=Producer_Cal, aes(x = Treatment1, y = mean,fill=Temp)) + #
  geom_errorbar(aes( ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  scale_fill_manual(values = c("#00CCFF","red"))+
  xlab("Treatments") + labs (y = expression(bold(Producer~(g)))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "top") #c(0.1,0.85)
Producer_B_plot

tiff("Producer_B_plot.tiff", width = 2.5, height = 2.5, units = 'in', res = 300, compression = 'none')
Producer_B_plot
dev.off()

#glm analysis 
m1 <- glm(log(Producer) ~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
Anova(m1, type = "II")

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- glm(log(Producer) ~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- glm(log(Producer) ~ Pesticide + Temp, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

library(effectsize)

m_interaction2 <- lm(
  log(Producer) ~ Pesticide + Temp,
  data = Final2021, 
  contrasts = list(
    Temp = "contr.sum",
    Pesticide = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, partial = T,type = 2))

#1.2 Secondary Consumers####
##1.2.1 Carp biomass####
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
Carp_B_Cal <- ddply(Final2021, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(Carp_B)), 
                        mean = mean(Carp_B,na.rm=TRUE),
                        sd = sd(Carp_B,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Carp_B_Cal

Carp_B_Cal$Treatment <- interaction(Carp_B_Cal$Eutroph, Carp_B_Cal$Pesticide,Carp_B_Cal$Temp)
Carp_B_Cal$Treatment1 <- interaction(Carp_B_Cal$Eutroph, Carp_B_Cal$Pesticide)
Carp_B_Cal$Treatment1 <- revalue(Carp_B_Cal$Treatment1, c("0.0"="0", "N.0"="N", "0.I"="I", "N.I"="N*I"))#Rename names

Carp_B_plot <- ggplot(data=Carp_B_Cal, aes(x = Treatment1, y = mean,fill=Temp)) + #
  geom_errorbar(aes( ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  scale_fill_manual(values = c("#00CCFF","red"))+
  xlab("Treatments") + labs (y = expression(bold(Carp))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)
Carp_B_plot

tiff("Carp_B_plot.tiff", width = 2.5, height = 2, units = 'in', res = 300, compression = 'none')
Carp_B_plot
dev.off()

#glm analysis 
m1 <- glm(sqrt(Carp_B) ~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
Anova(m1, type = "II")

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- glm(sqrt(Carp_B)~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- glm(sqrt(Carp_B) ~ Pesticide+Temp, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

library(effectsize)

m_interaction2 <- lm(
  sqrt(Carp_B) ~ Pesticide+Temp,  data = Final2021,
  contrasts = list(
    Temp = "contr.sum",
    Pesticide = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, type = 2))

##1.2.2 Bitterling biomass####
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
Rhodeus_B_Cal <- ddply(Final2021, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(Rhodeus_B)), 
                    mean = mean(Rhodeus_B,na.rm=TRUE),
                    sd = sd(Rhodeus_B,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Rhodeus_B_Cal

Rhodeus_B_Cal$Treatment <- interaction(Rhodeus_B_Cal$Eutroph, Rhodeus_B_Cal$Pesticide,Rhodeus_B_Cal$Temp)
Rhodeus_B_Cal$Treatment1 <- interaction(Rhodeus_B_Cal$Eutroph, Rhodeus_B_Cal$Pesticide)
Rhodeus_B_Cal$Treatment1 <- revalue(Rhodeus_B_Cal$Treatment1, c("0.0"="0", "N.0"="N", "0.I"="I", "N.I"="N*I"))#Rename names

Rhodeus_B_plot <- ggplot(data=Rhodeus_B_Cal, aes(x = Treatment1, y = mean,fill=Temp)) + #
  geom_errorbar(aes( ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  scale_fill_manual(values = c("#00CCFF","red"))+
  xlab("Treatments") + labs (y = expression(bold(Bitterling))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)
Rhodeus_B_plot

tiff("Rhodeus_B_plot.tiff", width = 2.5, height = 2, units = 'in', res = 100, compression = 'none')
Rhodeus_B_plot
dev.off()

#glm analysis 
m1 <- glm(log(Rhodeus_B+1) ~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
Anova(m1, type = "II")

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- glm(log(Rhodeus_B+1)~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- glm(log(Rhodeus_B+1) ~ Temp, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

library(effectsize)

m_interaction2 <- lm(
  log(Rhodeus_B+1) ~ Temp, data = Final2021,
  contrasts = list(
    Temp = "contr.sum",
    Pesticide = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, type = 2))

##1.2.3 Shrimp biomass####
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
Shrimp_B_Cal <- ddply(Final2021, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(Shrimp_B)), 
                       mean = mean(Shrimp_B,na.rm=TRUE),
                       sd = sd(Shrimp_B,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Shrimp_B_Cal

Shrimp_B_Cal$Treatment <- interaction(Shrimp_B_Cal$Eutroph, Shrimp_B_Cal$Pesticide,Shrimp_B_Cal$Temp)
Shrimp_B_Cal$Treatment1 <- interaction(Shrimp_B_Cal$Eutroph, Shrimp_B_Cal$Pesticide)
Shrimp_B_Cal$Treatment1 <- revalue(Shrimp_B_Cal$Treatment1, c("0.0"="0", "N.0"="N", "0.I"="I", "N.I"="N*I"))#Rename names

Shrimp_B_plot <- ggplot(data=Shrimp_B_Cal, aes(x = Treatment1, y = mean,fill=Temp)) + #
  geom_errorbar(aes( ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  scale_fill_manual(values = c("#00CCFF","red"))+
  xlab("Treatments") + labs (y = expression(bold(Shrimp))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)
Shrimp_B_plot

tiff("Shrimp_B_plot.tiff", width = 2.5, height = 2, units = 'in', res = 100, compression = 'none')
Shrimp_B_plot
dev.off()

#glm analysis 
m1 <- glm(log(Shrimp_B+0.001) ~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
Anova(m1, type = "II")

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- glm(log(Shrimp_B+0.001)~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- glm(log(Shrimp_B+0.001) ~ Pesticide*Temp, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

library(effectsize)

m_interaction2 <- lm(
  log(Shrimp_B+0.001) ~ Temp*Pesticide, data = Final2021, 
  contrasts = list(
    Temp = "contr.sum",
    Pesticide = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, type = 2))

##1.2.4 Secondary species diversity, two fish and one shrimp####
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
Predator_S_Cal <- ddply(Final2021, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(Predator_Species)), 
                      mean = mean(Predator_Species,na.rm=TRUE),
                      sd = sd(Predator_Species,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Predator_S_Cal

Predator_S_Cal$Treatment <- interaction(Predator_S_Cal$Eutroph, Predator_S_Cal$Pesticide,Predator_S_Cal$Temp)
Predator_S_Cal$Treatment1 <- interaction(Predator_S_Cal$Eutroph, Predator_S_Cal$Pesticide)
Predator_S_Cal$Treatment1 <- revalue(Predator_S_Cal$Treatment1, c("0.0"="0", "N.0"="N", "0.I"="I", "N.I"="N*I"))#Rename names


Predator_S_plot <- ggplot(data=Predator_S_Cal, aes(x = Treatment1, y = mean,fill=Temp)) + #
  geom_errorbar(aes( ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  scale_fill_manual(values = c("#00CCFF","red"))+
  xlab("Treatments") + labs (y = expression(bold(Secondary~species))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)

Predator_S_plot

tiff("Predator_S_plot.tiff", width = 2.5, height = 2, units = 'in', res = 300, compression = 'none')
Predator_S_plot
dev.off()

#glm analysis 
m1 <- glm(Predator_Species~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
Anova(m1, type = "III")

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- glm(Predator_Species~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- glm(Predator_Species ~ Pesticide*Temp, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

library(effectsize)

m_interaction2 <- lm(
  Predator_Species ~ Pesticide*Temp, data = Final2021, 
  contrasts = list(
    Temp = "contr.sum",
    Pesticide = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, type = 2))

##1.2.5 Total secondary consumer biomass####
Final2021$Predator <-Final2021$Carp_B + Final2021$Rhodeus_B + Final2021$Shrimp_B

library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
Fish_B_Cal <- ddply(Final2021, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(Predator )), 
                        mean = mean(Predator ,na.rm=TRUE),
                        sd = sd(Predator ,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Fish_B_Cal

Fish_B_Cal$Treatment <- interaction(Fish_B_Cal$Eutroph, Fish_B_Cal$Pesticide,Fish_B_Cal$Temp)
Fish_B_Cal$Treatment1 <- interaction(Fish_B_Cal$Eutroph, Fish_B_Cal$Pesticide)
Fish_B_Cal$Treatment1 <- revalue(Fish_B_Cal$Treatment1, c("0.0"="0", "N.0"="N", "0.I"="I", "N.I"="N*I"))#Rename names


Fish_B_plot <- ggplot(data=Fish_B_Cal, aes(x = Treatment1, y = mean,fill=Temp)) + #
  geom_errorbar(aes( ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  scale_fill_manual(values = c("#00CCFF","red"))+
  xlab("Treatments") + labs (y = expression(bold(Secondary~biomass))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)

Fish_B_plot

tiff("Fish_B_plot.tiff", width = 2.5, height = 2, units = 'in', res = 300, compression = 'none')
Fish_B_plot
dev.off()

#glm analysis 
m1 <- glm(sqrt(Predator)~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
Anova(m1, type = "II")

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- glm(sqrt(Predator)~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- glm(sqrt(Predator ) ~ Temp, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

library(effectsize)

m_interaction2 <- lm(
  sqrt(Predator ) ~ Temp, data = Final2021, 
  contrasts = list(
    Temp = "contr.sum",
    Pesticide = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, type = 2))

#1.3 Zooplankton####
##1.3.1 Cladocera Biomass#### 

library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
Cladocera_B_Cal <- ddply(Final2021, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(Cladocera_B)), 
                           mean = mean(Cladocera_B,na.rm=TRUE),
                           sd = sd(Cladocera_B,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Cladocera_B_Cal

Cladocera_B_Cal$Treatment <- interaction(Cladocera_B_Cal$Eutroph, Cladocera_B_Cal$Pesticide,Cladocera_B_Cal$Temp)
Cladocera_B_Cal$Treatment1 <- interaction(Cladocera_B_Cal$Eutroph, Cladocera_B_Cal$Pesticide)
Cladocera_B_Cal$Treatment1 <- revalue(Cladocera_B_Cal$Treatment1, c("0.0"="0", "N.0"="N", "0.I"="I", "N.I"="N*I"))#Rename names

Cladocera_B_plot <- ggplot(data=Cladocera_B_Cal, aes(x = Treatment1, y = mean,fill=Temp)) + #
  geom_errorbar(aes( ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  scale_fill_manual(values = c("#00CCFF","red"))+
  xlab("Treatments") + labs (y = expression(bold(Cladocera))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)
Cladocera_B_plot

tiff("Cladocera_B_plot.tiff", width = 2.5, height = 2, units = 'in', res = 300, compression = 'none')
Cladocera_B_plot
dev.off()

#glm analysis 
m1 <- glm(log(Cladocera_B+0.01) ~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
Anova(m1, type = "II")

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- glm(log(Cladocera_B+0.01)~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- glm(log(Cladocera_B+0.01) ~ Temp+Pesticide*Eutroph, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
Anova(m1, type = "III")


library(effectsize)

m_interaction2 <- lm(
  log(Cladocera_B+0.01) ~ Temp+Pesticide*Eutroph, data = Final2021,
  contrasts = list(
    Temp = "contr.sum",
    Pesticide = "contr.sum",
    Eutroph = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, type = 2))

##1.3.2 Copepoda biomass#### 
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
Copepoda_B_Cal <- ddply(Final2021, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(Copepoda_B)), 
                         mean = mean(Copepoda_B,na.rm=TRUE),
                         sd = sd(Copepoda_B,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Copepoda_B_Cal

Copepoda_B_Cal$Treatment <- interaction(Copepoda_B_Cal$Eutroph, Copepoda_B_Cal$Pesticide,Copepoda_B_Cal$Temp)
Copepoda_B_Cal$Treatment1 <- interaction(Copepoda_B_Cal$Eutroph, Copepoda_B_Cal$Pesticide)
Copepoda_B_Cal$Treatment1 <- revalue(Copepoda_B_Cal$Treatment1, c("0.0"="0", "N.0"="N", "0.I"="I", "N.I"="N*I"))#Rename names

Copepoda_B_plot <- ggplot(data=Copepoda_B_Cal, aes(x = Treatment1, y = mean,fill=Temp)) + #
  geom_errorbar(aes( ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  scale_fill_manual(values = c("#00CCFF","red"))+
  xlab("Treatments") +labs (y = expression(bold(Copepoda))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)
Copepoda_B_plot

tiff("Copepoda_B_plot.tiff", width = 2.5, height = 2, units = 'in', res = 100, compression = 'none')
Copepoda_B_plot
dev.off()

#glm analysis 
m1 <- glm(log(Copepoda_B+0.0001) ~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
Anova(m1, type = "II")

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- glm(log(Copepoda_B+0.0001)~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- glm(log(Copepoda_B+0.0001) ~ Pesticide, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

library(effectsize)

m_interaction2 <- lm(
  log(Copepoda_B+0.0001) ~ Pesticide,
  data = Final2021, 
  contrasts = list(
    Pesticide = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, partial = T,type = 2))

##1.3.3 Rotifers biomass#### 
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
Rotifers_B_Cal <- ddply(Final2021, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(Rotifers_B)), 
                        mean = mean(Rotifers_B,na.rm=TRUE),
                        sd = sd(Rotifers_B,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Rotifers_B_Cal

Rotifers_B_Cal$Treatment <- interaction(Rotifers_B_Cal$Eutroph, Rotifers_B_Cal$Pesticide,Rotifers_B_Cal$Temp)
Rotifers_B_Cal$Treatment1 <- interaction(Rotifers_B_Cal$Eutroph, Rotifers_B_Cal$Pesticide)
Rotifers_B_Cal$Treatment1 <- revalue(Rotifers_B_Cal$Treatment1, c("0.0"="0", "N.0"="N", "0.I"="I", "N.I"="N*I"))#Rename names

Rotifers_B_plot <- ggplot(data=Rotifers_B_Cal, aes(x = Treatment1, y = mean,fill=Temp)) + #
  geom_errorbar(aes( ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  scale_fill_manual(values = c("#00CCFF","red"))+
  xlab("Treatments") +labs (y = expression(bold(Rotifers))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)
Rotifers_B_plot

tiff("Rotifers_B_plot.tiff", width = 2.5, height = 2, units = 'in', res = 100, compression = 'none')
Rotifers_B_plot
dev.off()

#glm analysis 
m1 <- glm(log(Rotifers_B+0.01) ~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
Anova(m1, type = "II")

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- glm(log(Rotifers_B+0.01)~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- glm(log(Rotifers_B+0.01) ~ Pesticide+Temp, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

library(effectsize)

m_interaction2 <- lm(
  log(Rotifers_B+0.01) ~ Pesticide+Temp,
  data = Final2021, 
  contrasts = list(
    Pesticide = "contr.sum",
    Temp = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, partial = T,type = 2))

##1.3.4 Zooplankton Biomass#### 
Final2021$Zooplankton_B <-Final2021$Cladocera_B + Final2021$Copepoda_B + Final2021$Rotifers_B

Zooplankton_B_Cal <- ddply(Final2021, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(Zooplankton_B)), 
                        mean = mean(Zooplankton_B,na.rm=TRUE),
                        sd = sd(Zooplankton_B,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Zooplankton_B_Cal

Zooplankton_B_Cal$Treatment <- interaction(Zooplankton_B_Cal$Eutroph, Zooplankton_B_Cal$Pesticide,Zooplankton_B_Cal$Temp)
Zooplankton_B_Cal$Treatment1 <- interaction(Zooplankton_B_Cal$Eutroph, Zooplankton_B_Cal$Pesticide)
Zooplankton_B_Cal$Treatment1 <- revalue(Zooplankton_B_Cal$Treatment1, c("0.0"="0", "N.0"="N", "0.I"="I", "N.I"="N*I"))#Rename names

Zooplankton_B_plot <- ggplot(data=Zooplankton_B_Cal, aes(x = Treatment1, y = mean,fill=Temp)) + #
  geom_errorbar(aes( ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  scale_fill_manual(values = c("#00CCFF","red"))+
  xlab("Treatments") +labs (y = expression(bold(Zooplankton))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)
Zooplankton_B_plot

tiff("Zooplankton_B_plot.tiff", width = 2.5, height = 2, units = 'in', res = 100, compression = 'none')
Zooplankton_B_plot
dev.off()

#glm analysis 
m1 <- glm(log(Zooplankton_B+0.01) ~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
Anova(m1, type = "II")

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- glm(log(Zooplankton_B+0.01)~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- glm(log(Zooplankton_B+0.01) ~ Pesticide, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

library(effectsize)

m_interaction2 <- lm(
  log(Zooplankton_B+0.01) ~ Pesticide, 
  data = Final2021, 
  contrasts = list(
    Pesticide = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, partial = T,type = 2))


#1.4 Macroinvertebrates####
##1.4.1 Oligochaeta biomass####
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
Oligochaeta_B_Cal <- ddply(Final2021, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(Oligochaeta_B)), 
                      mean = mean(Oligochaeta_B,na.rm=TRUE),
                      sd = sd(Oligochaeta_B,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Oligochaeta_B_Cal

Oligochaeta_B_Cal$Treatment <- interaction(Oligochaeta_B_Cal$Eutroph, Oligochaeta_B_Cal$Pesticide,Oligochaeta_B_Cal$Temp)
Oligochaeta_B_Cal$Treatment1 <- interaction(Oligochaeta_B_Cal$Eutroph, Oligochaeta_B_Cal$Pesticide)
Oligochaeta_B_Cal$Treatment1 <- revalue(Oligochaeta_B_Cal$Treatment1, c("0.0"="0", "N.0"="N", "0.I"="I", "N.I"="N*I"))#Rename names

Oligochaeta_B_plot <- ggplot(data=Oligochaeta_B_Cal, aes(x = Treatment1, y = mean,fill=Temp)) + #
  geom_errorbar(aes( ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  #facet_wrap(~ Temp, nrow = 1, strip.position = "top")+
  scale_fill_manual(values = c("#00CCFF","red"))+
  xlab("Treatments") + labs (y = expression(bold(Oligochaeta))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)
Oligochaeta_B_plot

tiff("Oligochaeta_B_plot.tiff", width = 2.5, height = 2, units = 'in', res = 100, compression = 'none')
Oligochaeta_B_plot
dev.off()

#glm analysis 
m1 <- glm(log(Oligochaeta_B+0.01) ~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
Anova(m1, type = "II")

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- glm(log(Oligochaeta_B+0.01)~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- glm(log(Oligochaeta_B+0.01) ~ Temp*Pesticide, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

library(effectsize)

m_interaction2 <- lm(
  log(Oligochaeta_B+0.01) ~ Temp*Pesticide, data = Final2021,
  contrasts = list(
    Temp = "contr.sum",
    Pesticide = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, type = 2))

##1.4.2 Insecta biomass####
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
Insecta_B_Cal <- ddply(Final2021, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(Insecta_B)), 
                           mean = mean(Insecta_B,na.rm=TRUE),
                           sd = sd(Insecta_B,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Insecta_B_Cal

Insecta_B_Cal$Treatment <- interaction(Insecta_B_Cal$Eutroph, Insecta_B_Cal$Pesticide,Insecta_B_Cal$Temp)
Insecta_B_Cal$Treatment1 <- interaction(Insecta_B_Cal$Eutroph, Insecta_B_Cal$Pesticide)
Insecta_B_Cal$Treatment1 <- revalue(Insecta_B_Cal$Treatment1, c("0.0"="0", "N.0"="N", "0.I"="I", "N.I"="N*I"))#Rename names

Insecta_B_plot <- ggplot(data=Insecta_B_Cal, aes(x = Treatment1, y = mean,fill=Temp)) + #
  geom_errorbar(aes( ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  scale_fill_manual(values = c("#00CCFF","red"))+
  xlab("Treatments") + labs (y = expression(bold(Insects))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)
Insecta_B_plot

tiff("Insecta1_B_plot.tiff", width = 2.5, height = 2, units = 'in', res = 100, compression = 'none')
Insecta_B_plot
dev.off()

#glm analysis 
m1 <- glm(log(Insecta_B+1) ~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
Anova(m1, type = "II")

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- glm(log(Insecta_B+1)~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- glm(log(Insecta_B+1) ~ Temp*Pesticide, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

library(effectsize)

m_interaction2 <- lm(
  log(Insecta_B+1) ~ Pesticide* Temp, data = Final2021,
  contrasts = list(
    Temp = "contr.sum",
    Pesticide = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, type = 2))


##1.4.3 Radix biomass####
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
Radix_B_Cal <- ddply(Final2021, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(Radix_B)), 
                       mean = mean(Radix_B,na.rm=TRUE),
                       sd = sd(Radix_B,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Radix_B_Cal

Radix_B_Cal$Treatment <- interaction(Radix_B_Cal$Eutroph, Radix_B_Cal$Pesticide,Radix_B_Cal$Temp)
Radix_B_Cal$Treatment1 <- interaction(Radix_B_Cal$Eutroph, Radix_B_Cal$Pesticide)
Radix_B_Cal$Treatment1 <- revalue(Radix_B_Cal$Treatment1, c("0.0"="0", "N.0"="N", "0.I"="I", "N.I"="N*I"))#Rename names

Radix_B_plot <- ggplot(data=Radix_B_Cal, aes(x = Treatment1, y = mean,fill=Temp)) + #
  geom_errorbar(aes( ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  #facet_wrap(~ Temp, nrow = 1, strip.position = "top")+
  scale_fill_manual(values = c("#00CCFF","red"))+
  xlab("Treatments") + labs (y = expression(bold(Radix))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)
Radix_B_plot

tiff("Radix_B_plot.tiff", width = 2.5, height = 2, units = 'in', res = 100, compression = 'none')
Radix_B_plot
dev.off()

#glm analysis 
m1 <- glm(log(Radix_B+1) ~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
Anova(m1, type = "II")

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- glm(log(Radix_B+1)~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- glm(log(Radix_B+1) ~ Temp, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

library(effectsize)

m_interaction2 <- lm(
  log(Radix_B+1) ~ Temp,
  data = Final2021,
  contrasts = list(
    Temp = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, type = 2))

##1.4.4 Bellamya biomass####
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
Bellamya_B_Cal <- ddply(Final2021, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(Bellamya_B)), 
                     mean = mean(Bellamya_B,na.rm=TRUE),
                     sd = sd(Bellamya_B,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Bellamya_B_Cal

Bellamya_B_Cal$Treatment <- interaction(Bellamya_B_Cal$Eutroph, Bellamya_B_Cal$Pesticide,Bellamya_B_Cal$Temp)
Bellamya_B_Cal$Treatment1 <- interaction(Bellamya_B_Cal$Eutroph, Bellamya_B_Cal$Pesticide)
Bellamya_B_Cal$Treatment1 <- revalue(Bellamya_B_Cal$Treatment1, c("0.0"="0", "N.0"="N", "0.I"="I", "N.I"="N*I"))#Rename names

Bellamya_B_plot <- ggplot(data=Bellamya_B_Cal, aes(x = Treatment1, y = mean,fill=Temp)) + #
  geom_errorbar(aes( ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  #facet_wrap(~ Temp, nrow = 1, strip.position = "top")+
  scale_fill_manual(values = c("#00CCFF","red"))+
  xlab("Treatments") + labs (y = expression(bold(Bellamya))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)
Bellamya_B_plot

tiff("Bellamya_B_plot.tiff", width = 2.5, height = 2, units = 'in', res = 100, compression = 'none')
Bellamya_B_plot
dev.off()

#glm analysis 
m1 <- glm(Bellamya_B ~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
Anova(m1, type = "II")

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- glm(Bellamya_B~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- glm(Bellamya_B ~ Pesticide*Eutroph + Temp, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

library(effectsize)

m_interaction2 <- lm(
  Bellamya_B ~ Pesticide*Eutroph + Temp, data = Final2021,
  contrasts = list(
    Temp = "contr.sum",
    Pesticide = "contr.sum",
    Eutroph = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, type = 2))

##1.4.5 Other tiny snails####
library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
Snail_Other_B_Cal <- ddply(Final2021, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(Snail_Other_B)), 
                        mean = mean(Snail_Other_B,na.rm=TRUE),
                        sd = sd(Snail_Other_B,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Snail_Other_B_Cal

Snail_Other_B_Cal$Treatment <- interaction(Snail_Other_B_Cal$Eutroph, Snail_Other_B_Cal$Pesticide,Snail_Other_B_Cal$Temp)
Snail_Other_B_Cal$Treatment1 <- interaction(Snail_Other_B_Cal$Eutroph, Snail_Other_B_Cal$Pesticide)
Snail_Other_B_Cal$Treatment1 <- revalue(Snail_Other_B_Cal$Treatment1,c("0.0"="0", "N.0"="N", "0.I"="I", "N.I"="N*I"))#Rename names

Snail_Other_B_plot <- ggplot(data=Snail_Other_B_Cal, aes(x = Treatment1, y = mean,fill=Temp)) + #
  geom_errorbar(aes( ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  scale_fill_manual(values = c("#00CCFF","red"))+
  xlab("Treatments") + labs (y = expression(bold(Other~tiny~snails))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)
Snail_Other_B_plot

tiff("Snail_Other_B_plot.tiff", width =2.5, height = 2, units = 'in', res = 100, compression = 'none')
Snail_Other_B_plot
dev.off()

#glm analysis 
m1 <- glm(log(Snail_Other_B+0.001) ~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
Anova(m1, type = "II")

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- glm(log(Snail_Other_B+0.001)~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- glm(log(Snail_Other_B+0.001) ~ Pesticide, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

library(effectsize)

m_interaction2 <- lm(
  log(Snail_Other_B+0.001) ~ Pesticide, data = Final2021,
  contrasts = list(
    Pesticide = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, type = 2))

##1.4.6 Macroinvertebrate Biomass####
Final2021$Macroinvertebrate_B <-Final2021$Oligochaeta_B + Final2021$Insecta_B + Final2021$Snail_Other_B + Final2021$Bellamya_B + Final2021$Radix_B

library(plyr)#group data based on some specified variables, and apply a summary function (like mean, standard deviation, etc.) to each group
Macroinvertebrate_B_Cal <- ddply(Final2021, c("Temp","Eutroph","Pesticide"), summarise, N = sum(!is.na(Macroinvertebrate_B)), 
                           mean = mean(Macroinvertebrate_B,na.rm=TRUE),
                           sd = sd(Macroinvertebrate_B,na.rm=TRUE), se = sd / sqrt(N)) #calculate mean,sd and se of group data
Macroinvertebrate_B_Cal

Macroinvertebrate_B_Cal$Treatment <- interaction(Macroinvertebrate_B_Cal$Eutroph, Macroinvertebrate_B_Cal$Pesticide,Macroinvertebrate_B_Cal$Temp)
Macroinvertebrate_B_Cal$Treatment1 <- interaction(Macroinvertebrate_B_Cal$Eutroph, Macroinvertebrate_B_Cal$Pesticide)
Macroinvertebrate_B_Cal$Treatment1 <- revalue(Macroinvertebrate_B_Cal$Treatment1, c("0.0"="0", "N.0"="N", "0.I"="I", "N.I"="N*I"))#Rename names

Macroinvertebrate_B_plot <- ggplot(data=Macroinvertebrate_B_Cal, aes(x = Treatment1, y = mean,fill=Temp)) + #
  geom_errorbar(aes( ymax = mean + se, ymin = mean-se), position=position_dodge(width = 0.8), width = 0.2) + 
  geom_bar(stat="identity", position="dodge", alpha=1, width = 0.8) +
  scale_fill_manual(values = c("#00CCFF","red"))+
  xlab("Treatments") + labs (y = expression(bold(Zoobenthos))) +
  theme(axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 0,size = 10), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 10), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") #c(0.1,0.85)
Macroinvertebrate_B_plot

tiff("Macroinvertebrate_B_plot.tiff", width =2.5, height = 2, units = 'in', res = 300, compression = 'none')
Macroinvertebrate_B_plot
dev.off()

#glm analysis 
m1 <- glm(sqrt(Macroinvertebrate_B) ~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)
Anova(m1, type = "II")

library(MuMIn)
# Fit the full model
options(na.action = "na.fail")
full_model <- glm(sqrt(Macroinvertebrate_B)~ Pesticide * Temp * Eutroph, data = Final2021,family=gaussian)
# Use dredge function to perform model selection
model_selection <- dredge(full_model)
model_selection
# Get the best model based on AICc
best_model <- get.models(model_selection, subset = 1)
# Display the best model summary
summary(best_model)

m1 <- glm(sqrt(Macroinvertebrate_B) ~ Temp + Pesticide * Eutroph, data = Final2021,family=gaussian)#[which(Macrophyte$Eutroph == "1"),]
hist(resid(m1))
qqnorm(resid(m1))
qqline(resid(m1))
summary(m1)

library(effectsize)
m_interaction2 <- lm(
  sqrt(Macroinvertebrate_B) ~ Temp + Pesticide * Eutroph,  data = Final2021,
  contrasts = list(
    Temp = "contr.sum",
    Pesticide = "contr.sum",
    Eutroph = "contr.sum"
  )
)

eta_squared(car::Anova(m_interaction2, type = 2))

#1.5 Align plots####
#1.5.1 Three primary producers####
library(cowplot)
Threeplant <- plot_grid(Phytoplankton_B_plot,  Periphyton_B_plot,Macrophyte_plot, align = "hv",
                       nrow = 1)
Threeplant
tiff("Threeplant.tiff", width = 7.5, height = 2, units = 'in', res = 300, compression = 'none')
Threeplant
dev.off()

#1.5.2 Three secondary consumers####
Threepredator <- plot_grid(Carp_B_plot,  Rhodeus_B_plot, Shrimp_B_plot, align = "hv",
                        nrow = 1)
Threepredator
tiff("Threepredator.tiff", width = 7.5, height = 2, units = 'in', res = 300, compression = 'none')
Threepredator
dev.off()

#1.5.3 Three zooplankton####
Threezooplankton <- plot_grid( Copepoda_B_plot, Cladocera_B_plot,  Rotifers_B_plot, align = "hv",
                           nrow = 3)
Threezooplankton
tiff("Threezooplankton.tiff", width = 2.5, height = 6, units = 'in', res = 300, compression = 'none')
Threezooplankton
dev.off()

#1.5.4 Five zoobenthos####
Fivezoobenthos <- plot_grid(Insecta_B_plot, Oligochaeta_B_plot,  
                            Radix_B_plot, Bellamya_B_plot,
                            Snail_Other_B_plot,
                            align = "hv",nrow = 3, ncol =2)
Fivezoobenthos
tiff("Fivezoobenthos.tiff", width = 5, height = 6, units = 'in', res = 300, compression = 'none')
Fivezoobenthos
dev.off()

#1.5.5 Group biomass####
Groupbiomass <- plot_grid(Predator_S_plot, Fish_B_plot,  
                          Zooplankton_B_plot, Macroinvertebrate_B_plot,
                            align = "hv",nrow = 2, ncol =2)
Groupbiomass
tiff("Groupbiomass.tiff", width = 5, height = 4, units = 'in', res = 300, compression = 'none')
Groupbiomass
dev.off()


#2.0 Structure equation model####
Final2021$Macrophyte <-Final2021$Hydrilla + Final2021$P.crispus
Final2021$Zooplankton_B <-Final2021$Cladocera_B + Final2021$Copepoda_B + Final2021$Rotifers_B
#Final2021$Macroinvertebrate_B <-Final2021$Oligochaeta + Final2021$Insecta1 + Final2021$Chironomidae + Final2021$Gastropoda
Final2021$Predator <-Final2021$Carp_B + Final2021$Rhodeus_B + Final2021$Shrimp_B

#primary producers
Final2021$Macrophyte1 <-log(Final2021$Macrophyte + 1)
Final2021$Phytoplankton_B1 <- log(Final2021$Phytoplankton_B + 1)
#Final2021$Periphyton_Chla1 <- log(Final2021$Periphyton_Chla)
Final2021$Periphyton_B1 <- log(Final2021$Periphyton_B)

#zooplankton
Final2021$Cladocera_B1 <- log(Final2021$Cladocera_B + 0.01)
Final2021$Rotifers_B1 <- log(Final2021$Rotifers_B + 0.01)
Final2021$Copepoda_B1 <- log(Final2021$Copepoda_B + 0.0001)
Final2021$Zooplankton_B1 <-log(Final2021$Zooplankton_B)

#macroinvertebrates
Final2021$Oligochaeta_B1 <- log(Final2021$Oligochaeta_B+0.01)
Final2021$Insecta_B1 <- log(Final2021$Insecta_B+1)
Final2021$Radix_B1 <- log(Final2021$Radix_B + 1)
Final2021$Bellamya_B1 <- sqrt(Final2021$Bellamya_B)
Final2021$Snail_Other_B1 <- log(Final2021$Snail_Other_B+0.001)
#Final2021$Macroinvertebrate_B1 <- log(Final2021$Macroinvertebrate_B)

#Predators
Final2021$Carp_B1 <- sqrt(Final2021$Carp_B)
Final2021$Rhodeus_B1 <- log(Final2021$Rhodeus_B+1)
Final2021$Shrimp_B1 <- log(Final2021$Shrimp_B+0.001)
Final2021$Predator1 <- log(Final2021$Predator + 1)


##2.1. model with all food web components ####
library(lavaan)#

# 1) With major food web components
Smodel1 <- '
#Lavaan regression
Phytoplankton_B1 ~ Eutroph + Copepoda_B1 #+ Macrophyte1
Macrophyte1 ~  Phytoplankton_B1 + Shrimp_B1  #+ Temp+ Insecta_B1 + Pesticide
Periphyton_B1 ~ Phytoplankton_B1 + Macrophyte1  #+ Bellamya_B1 +  Radix_B1

Copepoda_B1 ~ Pesticide  + Insecta_B1 + Carp_B1 #+  Eutroph  + Bellamya_B1#+ Temp + Macrophyte1
#Cladocera_B1 ~ Temp
#Rotifers_B1 ~ Copepoda_B1 + Shrimp_B1 #+ Phytoplankton_B1 #+ Rhodeus_B1

#Bellamya_B1 ~ Temp + Phytoplankton_B1 + Radix_B1 
#Radix_B1 ~ Carp_B1 + Shrimp_B1 
#Oligochaeta_B1 ~ Pesticide #+ Phytoplankton_B1
Insecta_B1 ~ Pesticide + Carp_B1 + Shrimp_B1 + Macrophyte1#

Carp_B1 ~ Temp + Pesticide 
#Rhodeus_B1 ~ Temp 
Shrimp_B1 ~ Temp + Pesticide
Phytoplankton_B1 ~~  Copepoda_B1 #this specifies a covariance parameter
#Phytoplankton_B1 ~~ Macrophyte1

'

fitS1 <- sem(Smodel1, data=Final2021,estimator = "MLR", missing = "ml")#, estimator = "MLR" OR "ML"
summary(fitS1, fit.measures=TRUE, standardized=TRUE,modindices = FALSE, rsquare = T)


#https://psu-psychology.github.io/r-bootcamp-2018/talks/lavaan_tutorial.html#use-lavaan-for-simple-multiple-regression
varTable(fitS1) #variances of variables
parTable(fitS1) #examine the ‘parameter’ table 
modificationindices(fitS1, minimum.value = 4)



##2.2. separate for pleagic and benthic webs ####
library(lavaan)#
#pleagic web
Smodel1 <- '
#Lavaan regression
Phytoplankton_B1 ~ Eutroph + Copepoda_B1

Copepoda_B1 ~ Pesticide + Temp 
Cladocera_B1 ~ Phytoplankton_B1 + Temp
Rotifers_B1 ~ Copepoda_B1 + Phytoplankton_B1 + Rhodeus_B1

Carp_B1 ~ Temp + Pesticide
Rhodeus_B1 ~ Temp + Pesticide
'

fitS1 <- sem(Smodel1, data=Final2021, missing = "ml")#, 
summary(fitS1, fit.measures=TRUE, standardized=TRUE,modindices = FALSE, rsquare = T)


#benthic web
Smodel2 <- '
#Lavaan regression
Macrophyte1 ~  Phytoplankton_B1 + Shrimp_B1
Periphyton_B1 ~ Phytoplankton_B1 + Radix_B1

Bellamya_B1 ~ Temp + Phytoplankton_B1 + Radix_B1 
Radix_B1 ~ Carp_B1+ Shrimp_B1 
#Oligochaeta_B1 ~ Pesticide + Phytoplankton_B1
Insecta_B1 ~ Pesticide + Carp_B1 + Shrimp_B1

Carp_B1 ~ Temp + Pesticide
Shrimp_B1 ~ Temp + Pesticide
'

fitS2 <- sem(Smodel2, data=Final2021,estimator = "ML", missing = "ml")#, 
summary(fitS2, fit.measures=TRUE, standardized=TRUE,modindices = FALSE, rsquare = T)


#3.0 Effect size, interaction calculation####
#3.1 Data loading####
Final2021<- read.delim("2021Final.txt")

Final2021$Temp <- as.factor(Final2021$Temp)
Final2021$Eutroph <- as.factor(Final2021$Eutroph)
Final2021$Pesticide <- as.factor(Final2021$Pesticide)

#{get summary stats and set up dataframe}

library(tidyverse)
#create treatment column
Final2021 <- Final2021 %>% unite('Treatment', Temp:Pesticide, remove = FALSE)

Final2021$Macrophyte <-Final2021$Hydrilla + Final2021$P.crispus

#mean and error of each column
summary_mean <- Final2021 %>% group_by(Treatment) %>% summarise(across(Hydrilla:Macrophyte, mean, na.rm=TRUE))

summary_SD <- Final2021 %>% group_by(Treatment) %>% summarise(across(Hydrilla:Macrophyte, sd, na.rm=TRUE))                                                              

#transpose and name columns
summary_mean <- as.data.frame(t(summary_mean))
names(summary_mean) <- summary_mean[1,]
summary_mean <- summary_mean[-1,]
summary_mean <- summary_mean %>% rename_with( ~ paste0("mean_", .x))

summary_SD <- as.data.frame(t(summary_SD))
names(summary_SD) <- summary_SD[1,]
summary_SD <- summary_SD[-1,]
summary_SD <- summary_SD %>% rename_with( ~ paste0("SD_", .x))

#merge datasets and ensure as.numeric 
DF <- merge(summary_mean,summary_SD, by="row.names")
DF <- DF %>% mutate_at(vars(2:17), as.numeric)

DF1 <- DF %>% filter(Row.names == "Macrophyte" | Row.names == "Phytoplankton_B"| Row.names == "Periphyton_B"
                     |Row.names == "Copepoda_B"| Row.names == "Cladocera_B" | Row.names == "Rotifers_B"
                     |Row.names == "Insecta_B"| Row.names == "Oligochaeta_B" | Row.names == "Snail_Other_B"| Row.names == "Radix_B" | Row.names == "Bellamya_B"
                     |Row.names == "Carp_B"| Row.names == "Rhodeus_B" | Row.names == "Shrimp_B"|Row.names == "Predator_Species")

DF <- DF1

#3.0 Additive null model####
#3.1 WI {calculate null model predictions for stressor pair W and I}####

#Here I have focused on the stressors coded as W and I. You will need to run it again for other stressor pair combinations

#Calculate additive null model prediction for each row
DF <- DF %>% mutate(AdditiveNullModel_WI = mean_W_0_0 + mean_0_0_I - mean_0_0_0)
                    
#{calculate null model predictions for stressor pair W and I}
                    
####Generate variables for effect size calculations
#There are 6 reps and  the standard equation for stressor 1 and pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_WI = sqrt(((5*(SD_W_0_0)^2) + 5*(SD_0_0_I)^2 ) / (6+6-2))) 
                    
#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)
                    
#j - weighting factor based on replicates
DF <- DF %>% mutate(j = (1-(3 / (4*(6+(n_p)-2)-1)) ) )
                    
#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_WI = sqrt( ( ((6-1)*(SD_W_0_I)^2) +((n_p)-1)*(Sd_p_WI)^2 ) / (6+(n_p)-2) ) )
                    
####Calculate hedges d - for additive null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdAdditive_WI = ((mean_W_0_I -  AdditiveNullModel_WI) / s_WI) * j )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdAdditive_WI = ifelse (AdditiveNullModel_WI - mean_0_0_0 < 0, -HedgesdAdditive_WI, HedgesdAdditive_WI) )
                    
#Vd - the variance around each interaction effect size for additive
DF <- DF %>% mutate ( VdAdditive_WI = ( (6+(n_p)) /  (6*(n_p)) ) +  
                                            ( ((HedgesdAdditive_WI)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is additive or non-additive}
#It is likely to be additive with a sample size of 6 - we have a paper on this coming out soon
                    
DF <- DF %>% mutate (SE_WI = sqrt(VdAdditive_WI))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 24)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_WI = SE_WI*T_value)
DF <- DF %>% mutate (upper_WI = HedgesdAdditive_WI+CI_WI)
DF <- DF %>% mutate (lower_WI = HedgesdAdditive_WI-CI_WI)
                    
#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (interaction_WI = case_when(upper_WI>0 & lower_WI<0 ~ "Additive", upper_WI>0 & lower_WI>0 ~ 'Synergistic', upper_WI<0 & lower_WI<0 ~ 'Antagonistic'))


#3.2 NI {calculate null model predictions for stressor pair E and I}####

#Here I have focused on the stressors coded as N and I. You will need to run it again for other stressor pair combinations

####Calculate additive null model prediction for each row
DF <- DF %>% mutate(AdditiveNullModel_EI = mean_0_N_0 + mean_0_0_I - mean_0_0_0)

#{calculate null model predictions for stressor pair W and I}

####Generate variables for effect size calculations
#There are 6 reps and  the standard equation for stressor 1 and pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_EI = sqrt(((5*(SD_0_N_0)^2) + 5*(SD_0_0_I)^2 ) / (6+6-2))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate( j = (1-(3 / (4*(6+(n_p)-2)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_EI = sqrt( ( ((6-1)*(SD_0_N_I)^2) +((n_p)-1)*(Sd_p_EI)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for additive null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdAdditive_EI = ((mean_0_N_I -  AdditiveNullModel_EI) / s_EI) * j )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdAdditive_EI = ifelse (AdditiveNullModel_EI - mean_0_0_0 < 0, -HedgesdAdditive_EI, HedgesdAdditive_EI) )

#Vd - the variance around each interaction effect size for additive
DF <- DF %>% mutate ( VdAdditive_EI = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdAdditive_EI)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is additive or non-additive}
#It is likely to be additive with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_EI = sqrt(VdAdditive_EI))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 24)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_EI = SE_EI*T_value)
DF <- DF %>% mutate (upper_EI = HedgesdAdditive_EI+CI_EI)
DF <- DF %>% mutate (lower_EI = HedgesdAdditive_EI-CI_EI)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (interaction_EI = case_when(upper_EI>0 & lower_EI<0 ~ "Additive", upper_EI>0 & lower_EI>0 ~ 'Synergistic', upper_EI<0 & lower_EI<0 ~ 'Antagonistic'))


#3.3 WN {calculate null model predictions for stressor pair W and E}####

#Here I have focused on the stressors coded as W and N. You will need to run it again for other stressor pair combinations

####Calculate additive null model prediction for each row
DF <- DF %>% mutate(AdditiveNullModel_WE = mean_W_0_0 + mean_0_N_0 - mean_0_0_0)

#{calculate null model predictions for stressor pair W and I}

####Generate variables for effect size calculations
#There are 6 reps and  the standard equation for stressor 1 and pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_WE = sqrt(((5*(SD_W_0_0)^2) + 5*(SD_0_N_0)^2 ) / (6+6-2))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate( j = (1-(3 / (4*(6+(n_p)-2)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_WE = sqrt( ( ((6-1)*(SD_W_N_0)^2) +((n_p)-1)*(Sd_p_WE)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for additive null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdAdditive_WE = ((mean_W_N_0 -  AdditiveNullModel_WE) / s_WE) * j )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdAdditive_WE = ifelse (AdditiveNullModel_WE - mean_0_0_0 < 0, -HedgesdAdditive_WE, HedgesdAdditive_WE) )

#Vd - the variance around each interaction effect size for additive
DF <- DF %>% mutate ( VdAdditive_WE = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdAdditive_WE)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is additive or non-additive}
#It is likely to be additive with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_WE = sqrt(VdAdditive_WE))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 24)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_WE = SE_WE*T_value)
DF <- DF %>% mutate (upper_WE = HedgesdAdditive_WE+CI_WE)
DF <- DF %>% mutate (lower_WE = HedgesdAdditive_WE-CI_WE)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (interaction_WE = case_when(upper_WE>0 & lower_WE<0 ~ "Additive", upper_WE>0 & lower_WE>0 ~ 'Synergistic', upper_WE<0 & lower_WE<0 ~ 'Antagonistic'))

#3.4 WEI {calculate null model predictions for three stressors}####

####Calculate additive null model prediction for each row
DF <- DF %>% mutate(AdditiveNullModel_WEI = mean_W_0_0 + mean_0_N_0 + mean_0_0_I - 2*mean_0_0_0)

#{calculate null model predictions for stressor pair W,E and I}

####Generate variables for effect size calculations
#There are 6 reps and  the standard equation for stressor 1 and pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_WEI = sqrt(((5*(SD_W_0_0)^2) + 5*(SD_0_N_0)^2 + 5*(SD_0_0_I)^2 ) / (6+6+6-3))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate( j_WEI = (1-(3 / (4*(6+6+(n_p)-3)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_WEI = sqrt( ( ((6-1)*(SD_W_N_I)^2) +((n_p)-1)*(Sd_p_WEI)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for additive null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdAdditive_WEI = ((mean_W_N_I -  AdditiveNullModel_WEI) / s_WEI) * j_WEI )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdAdditive_WEI = ifelse (AdditiveNullModel_WEI - mean_0_0_0 < 0, -HedgesdAdditive_WEI, HedgesdAdditive_WEI) )

#Vd - the variance around each interaction effect size for additive
DF <- DF %>% mutate ( VdAdditive_WEI = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdAdditive_WEI)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is additive or non-additive}
#It is likely to be additive with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_WEI = sqrt(VdAdditive_WEI))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 30)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_WEI = SE_WEI*T_value)
DF <- DF %>% mutate (upper_WEI = HedgesdAdditive_WEI+CI_WEI)
DF <- DF %>% mutate (lower_WEI = HedgesdAdditive_WEI-CI_WEI)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (interaction_WEI = case_when(upper_WEI>0 & lower_WEI<0 ~ "Additive", upper_WEI>0 & lower_WEI>0 ~ 'Synergistic', upper_WEI<0 & lower_WEI<0 ~ 'Antagonistic'))

#3.5 plot ####
DF$Row.names <- as.factor(DF$Row.names)
DF$interaction_WI <- as.factor(DF$interaction_WI)

DF <- DF %>% mutate(Row.names=recode(Row.names, Phytoplankton_B= 'Phytoplankton',Periphyton_B='Periphyton',
                                     Copepoda_B='Copepoda', Cladocera_B='Cladocera', Rotifers_B='Rotifers',
                                    Insecta_B ='Insecta', Oligochaeta_B='Oligochaeta',Snail_Other_B='Other tiny Snails',
                                    Radix_B= 'Radix', Bellamya_B='Bellamya',
                                    Carp_B= 'Carp', Rhodeus_B='Bitterling',Shrimp_B='Shrimp'))


library(ggplot2)
plot_WI <- DF %>%
  mutate(Row.names = fct_relevel(Row.names,"Macrophyte","Phytoplankton","Periphyton","Rotifers","Cladocera","Copepoda",
                            "Insecta","Oligochaeta","Other tiny Snails", "Radix", "Bellamya", "Carp", "Bitterling","Shrimp")) %>%
  ggplot(aes(x= Row.names, y = HedgesdAdditive_WI,color = interaction_WI))+
  geom_hline(yintercept = 0, linetype="solid", color = "grey75",size =1.5) +
  geom_point(size = 4)+ 
  geom_errorbar(aes(ymin=HedgesdAdditive_WI-CI_WI, ymax=HedgesdAdditive_WI+CI_WI),size=2, width = .2,position=position_dodge())+
  scale_color_manual(values = c("black","red","blue"))+
  ylab("W*I") + labs (x = expression(bold(Species))) +
  scale_y_continuous(limits=c(-9,9))+
  ggtitle("Additive null model") +
  theme(plot.title = element_text(face = "bold", size = 14,color = "brown", hjust = 0.5,vjust=-9),
        axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 90, size = 12, vjust=0.5), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 12), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") # +  #c(0.1,0.85)  
        #coord_flip() flip x and y axis
plot_WI

tiff("plot_WI.tiff", width = 8, height = 4, units = 'in', res = 300, compression = 'none')
plot_WI
dev.off()


plot_WE <- DF %>%
  mutate(Row.names = fct_relevel(Row.names,"Macrophyte","Phytoplankton","Periphyton","Rotifers","Cladocera","Copepoda",
                                 "Insecta","Oligochaeta","Other tiny Snails", "Radix", "Bellamya", "Carp", "Bitterling","Shrimp")) %>%
  ggplot(aes(x= Row.names, y = HedgesdAdditive_WE,color = interaction_WE))+
  geom_hline(yintercept = 0, linetype="solid", color = "grey75",size =1.5) +
  geom_point(size = 4)+ 
  geom_errorbar(aes(ymin=HedgesdAdditive_WE-CI_WE, ymax=HedgesdAdditive_WE+CI_WE),size=2, width = .2,position=position_dodge())+
  scale_color_manual(values = c("black","red","blue"))+
  ylab("W*N") + labs (x = expression(bold(Species))) +
  scale_y_continuous(limits=c(-9,9))+
  ggtitle("Additive null model") +
  theme(plot.title = element_text(face = "bold", size = 14,color = "brown", hjust = 0.5,vjust=-9),
    axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 90, size = 12, vjust=0.5), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 12), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") # +  #c(0.1,0.85)  
#coord_flip() flip x and y axis
plot_WE

tiff("plot_WE.tiff", width = 8, height = 4, units = 'in', res = 300, compression = 'none')
plot_WE
dev.off()

plot_EI <- DF %>%
  mutate(Row.names = fct_relevel(Row.names,"Macrophyte","Phytoplankton","Periphyton","Rotifers","Cladocera","Copepoda",
                                 "Insecta","Oligochaeta","Other tiny Snails", "Radix", "Bellamya", "Carp", "Bitterling","Shrimp")) %>%
  ggplot(aes(x= Row.names, y = HedgesdAdditive_EI,color = interaction_EI))+
  geom_hline(yintercept = 0, linetype="solid", color = "grey75",size =1.5) +
  geom_point(size = 4)+ 
  geom_errorbar(aes(ymin=HedgesdAdditive_EI-CI_EI, ymax=HedgesdAdditive_EI+CI_EI),size=2, width = .2,position=position_dodge())+
  scale_color_manual(values = c("black","red","blue"))+
  ylab("N*I") + labs (x = expression(bold(Species))) +
  scale_y_continuous(limits=c(-9,9))+
  ggtitle("Additive null model") +
  theme(plot.title = element_text(face = "bold", size = 14,color = "brown", hjust = 0.5,vjust=-9),
    axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 90, size = 12, vjust=0.5), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 12), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") # +  #c(0.1,0.85)  
#coord_flip() flip x and y axis
plot_EI

tiff("plot_EI.tiff", width = 8, height = 4, units = 'in', res = 300, compression = 'none')
plot_EI
dev.off()

plot_WEI <- DF %>%
  mutate(Row.names = fct_relevel(Row.names,"Macrophyte","Phytoplankton","Periphyton","Rotifers","Cladocera","Copepoda",
                                 "Insecta","Oligochaeta","Other tiny Snails", "Radix", "Bellamya", "Carp", "Bitterling","Shrimp")) %>%
  ggplot(aes(x= Row.names, y = HedgesdAdditive_WEI,color = interaction_WEI))+
  geom_hline(yintercept = 0, linetype="solid", color = "grey75",size =1.5) +
  geom_point(size = 4)+ 
  geom_errorbar(aes(ymin=HedgesdAdditive_WEI-CI_WEI, ymax=HedgesdAdditive_WEI+CI_WEI),size=2, width = .2,position=position_dodge())+
  scale_color_manual(values = c("black","red","blue"))+
  ylab("W*N*I") + labs (x = expression(bold(Species))) +
  scale_y_continuous(limits=c(-9,9))+
  ggtitle("Additive null model") +
  theme(plot.title = element_text(face = "bold", size = 14,color = "brown", hjust = 0.5,vjust=-9),
    axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 90, size = 12, vjust=0.5), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 12), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") # +  #c(0.1,0.85)  
#coord_flip() flip x and y axis
plot_WEI

tiff("plot_WEI.tiff", width = 8, height = 4, units = 'in', res = 300, compression = 'none')
plot_WEI
dev.off()



#5.0 Multiplicative null model####
#5.1 WI {calculate null model predictions for stressor pair W and I}####

####Calculate Multiplicative null model prediction for each row
DF <- DF %>% mutate(MultiplicativeNullModel_WI =(mean_W_0_0 * mean_0_0_I)/ mean_0_0_0)

#{calculate null model predictions for stressor pair W and I}

####Generate variables for effect size calculations
#There are 6 reps and  the standard equation for stressor 1 and pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_WI = sqrt(((5*(SD_W_0_0)^2) + 5*(SD_0_0_I)^2 ) / (6+6-2))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate( j = (1-(3 / (4*(6+(n_p)-2)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_WI = sqrt( ( ((6-1)*(SD_W_0_I)^2) +((n_p)-1)*(Sd_p_WI)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for Multiplicative null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdMultiplicative_WI = ((mean_W_0_I -  MultiplicativeNullModel_WI) / s_WI) * j )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdMultiplicative_WI = ifelse (MultiplicativeNullModel_WI - mean_0_0_0 < 0, -HedgesdMultiplicative_WI, HedgesdMultiplicative_WI) )

#Vd - the variance around each interaction effect size for Multiplicative
DF <- DF %>% mutate ( VdMultiplicative_WI = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdMultiplicative_WI)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is Multiplicative or non-Multiplicative}
#It is likely to be Multiplicative with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_WI = sqrt(VdMultiplicative_WI))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 24)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_WI = SE_WI*T_value)
DF <- DF %>% mutate (upper_WI = HedgesdMultiplicative_WI+CI_WI)
DF <- DF %>% mutate (lower_WI = HedgesdMultiplicative_WI-CI_WI)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (interaction_WI = case_when(upper_WI>0 & lower_WI<0 ~ "Additive", upper_WI>0 & lower_WI>0 ~ 'Synergistic', upper_WI<0 & lower_WI<0 ~ 'Antagonistic'))

#5.2 EI {calculate null model predictions for stressor pair E and I}####

#Here I have focused on the stressors coded as E and I. You will need to run it again for other stressor pair combinations

####Calculate Multiplicative null model prediction for each row
DF <- DF %>% mutate(MultiplicativeNullModel_EI = (mean_0_N_0 * mean_0_0_I)/ mean_0_0_0)

#{calculate null model predictions for stressor pair W and I}

####Generate variables for effect size calculations
#There are 6 reps and  the standard equation for stressor 1 and pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_EI = sqrt(((5*(SD_0_N_0)^2) + 5*(SD_0_0_I)^2 ) / (6+6-2))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate( j = (1-(3 / (4*(6+(n_p)-2)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_EI = sqrt( ( ((6-1)*(SD_0_E_I)^2) +((n_p)-1)*(Sd_p_EI)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for Multiplicative null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdMultiplicative_EI = ((mean_0_E_I -  MultiplicativeNullModel_EI) / s_EI) * j )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdMultiplicative_EI = ifelse (MultiplicativeNullModel_EI - mean_0_0_0 < 0, -HedgesdMultiplicative_EI, HedgesdMultiplicative_EI) )

#Vd - the variance around each interaction effect size for Multiplicative
DF <- DF %>% mutate ( VdMultiplicative_EI = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdMultiplicative_EI)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is Multiplicative or non-Multiplicative}
#It is likely to be Multiplicative with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_EI = sqrt(VdMultiplicative_EI))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 24)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_EI = SE_EI*T_value)
DF <- DF %>% mutate (upper_EI = HedgesdMultiplicative_EI+CI_EI)
DF <- DF %>% mutate (lower_EI = HedgesdMultiplicative_EI-CI_EI)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (interaction_EI = case_when(upper_EI>0 & lower_EI<0 ~ "Additive", upper_EI>0 & lower_EI>0 ~ 'Synergistic', upper_EI<0 & lower_EI<0 ~ 'Antagonistic'))


#5.3 WE {calculate null model predictions for stressor pair W and E}####

#Here I have focused on the stressors coded as W and E. You will need to run it again for other stressor pair combinations

####Calculate Multiplicative null model prediction for each row
DF <- DF %>% mutate(MultiplicativeNullModel_WE = (mean_W_0_0 * mean_0_N_0)/mean_0_0_0)

#{calculate null model predictions for stressor pair W and I}

####Generate variables for effect size calculations
#There are 6 reps and  the standard equation for stressor 1 and pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_WE = sqrt(((5*(SD_W_0_0)^2) + 5*(SD_0_N_0)^2 ) / (6+6-2))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate( j = (1-(3 / (4*(6+(n_p)-2)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_WE = sqrt( ( ((6-1)*(SD_W_N_0)^2) +((n_p)-1)*(Sd_p_WE)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for Multiplicative null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdMultiplicative_WE = ((mean_W_N_0 -  MultiplicativeNullModel_WE) / s_WE) * j )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdMultiplicative_WE = ifelse (MultiplicativeNullModel_WE - mean_0_0_0 < 0, -HedgesdMultiplicative_WE, HedgesdMultiplicative_WE) )

#Vd - the variance around each interaction effect size for Multiplicative
DF <- DF %>% mutate ( VdMultiplicative_WE = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdMultiplicative_WE)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is Multiplicative or non-Multiplicative}
#It is likely to be Multiplicative with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_WE = sqrt(VdMultiplicative_WE))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 24)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_WE = SE_WE*T_value)
DF <- DF %>% mutate (upper_WE = HedgesdMultiplicative_WE+CI_WE)
DF <- DF %>% mutate (lower_WE = HedgesdMultiplicative_WE-CI_WE)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (interaction_WE = case_when(upper_WE>0 & lower_WE<0 ~ "Additive", upper_WE>0 & lower_WE>0 ~ 'Synergistic', upper_WE<0 & lower_WE<0 ~ 'Antagonistic'))

#5.4 WEI {calculate null model predictions for three stressors}####

####Calculate Multiplicative null model prediction for each row
DF <- DF %>% mutate(MultiplicativeNullModel_WEI = (mean_W_0_0 * mean_0_N_0 * mean_0_0_I)/ (mean_0_0_0)^2)

#{calculate null model predictions for stressor pair W,E and I}

####Generate variables for effect size calculations
#There are 6 reps and  the standard equation for stressor 1 and pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_WEI = sqrt(((5*(SD_W_0_0)^2) + 5*(SD_0_N_0)^2 + 5*(SD_0_0_I)^2 ) / (6+6+6-3))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate( j_WEI = (1-(3 / (4*(6+6+(n_p)-3)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_WEI = sqrt( ( ((6-1)*(SD_W_N_I)^2) +((n_p)-1)*(Sd_p_WEI)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for Multiplicative null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdMultiplicative_WEI = ((mean_W_N_I -  MultiplicativeNullModel_WEI) / s_WEI) * j_WEI )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdMultiplicative_WEI = ifelse (MultiplicativeNullModel_WEI - mean_0_0_0 < 0, -HedgesdMultiplicative_WEI, HedgesdMultiplicative_WEI) )

#Vd - the variance around each interaction effect size for Multiplicative
DF <- DF %>% mutate ( VdMultiplicative_WEI = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdMultiplicative_WEI)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is additive or non-additive}
#It is likely to be additive with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_WEI = sqrt(VdMultiplicative_WEI))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 30)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_WEI = SE_WEI*T_value)
DF <- DF %>% mutate (upper_WEI = HedgesdMultiplicative_WEI+CI_WEI)
DF <- DF %>% mutate (lower_WEI = HedgesdMultiplicative_WEI-CI_WEI)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (interaction_WEI = case_when(upper_WEI>0 & lower_WEI<0 ~ "Additive", upper_WEI>0 & lower_WEI>0 ~ 'Synergistic', upper_WEI<0 & lower_WEI<0 ~ 'Antagonistic'))

#5.5 plot ####
DF$Row.names <- as.factor(DF$Row.names)
DF$interaction_WI <- as.factor(DF$interaction_WI)

DF <- DF %>% mutate(Row.names=recode(Row.names, Phytoplankton_B_Count= 'Phytoplankton',Periphyton_B_Count='Periphyton',
                                     Copepoda_B='Copepoda', Cladocera_B='Cladocera', Rotifers_B='Rotifers',
                                     Insecta_B ='Insecta', Oligochaeta_B='Oligochaeta',Snail_Other_B='Other tiny Snails',
                                     Radix_B= 'Radix', Bellamya_B='Bellamya',
                                     Carp_B= 'Carp', Rhodeus_B='Bitterling',Shrimp_B='Shrimp'))


library(ggplot2)
plot_WI <- DF %>%
  mutate(Row.names = fct_relevel(Row.names,"Macrophyte","Phytoplankton","Periphyton","Rotifers","Cladocera","Copepoda",
                                 "Insecta","Oligochaeta","Other tiny Snails", "Radix", "Bellamya", "Carp", "Bitterling","Shrimp")) %>%
  ggplot(aes(x= Row.names, y = HedgesdMultiplicative_WI,color = interaction_WI))+
  geom_hline(yintercept = 0, linetype="solid", color = "grey75",size =1.5) +
  geom_point(size = 4)+ 
  geom_errorbar(aes(ymin=HedgesdMultiplicative_WI-CI_WI, ymax=HedgesdMultiplicative_WI+CI_WI),size=2, width = .2,position=position_dodge())+
  scale_color_manual(values = c("black","red","blue"))+
  ylab("W*I") + labs (x = expression(bold(Species))) +
  scale_y_continuous(limits=c(-9,9))+
  ggtitle("Multiplicative null model") +
  theme(plot.title = element_text(face = "bold", size = 14,color = "brown", hjust = 0.5,vjust=-9),
    axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 90, size = 12, vjust=0.5), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 12), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") # +  #c(0.1,0.85)  
#coord_flip() flip x and y axis
plot_WI

tiff("plot_WI.tiff", width = 8, height = 4, units = 'in', res = 300, compression = 'none')
plot_WI
dev.off()


plot_WE <- DF %>%
  mutate(Row.names = fct_relevel(Row.names,"Macrophyte","Phytoplankton","Periphyton","Rotifers","Cladocera","Copepoda",
                                 "Insecta","Oligochaeta","Other tiny Snails", "Radix", "Bellamya", "Carp", "Bitterling","Shrimp")) %>%
  ggplot(aes(x= Row.names, y = HedgesdMultiplicative_WE,color = interaction_WE))+
  geom_hline(yintercept = 0, linetype="solid", color = "grey75",size =1.5) +
  geom_point(size = 4)+ 
  geom_errorbar(aes(ymin=HedgesdMultiplicative_WE-CI_WE, ymax=HedgesdMultiplicative_WE+CI_WE),size=2, width = .2,position=position_dodge())+
  scale_color_manual(values = c("black","red","blue"))+
  ylab("W*N") + labs (x = expression(bold(Species))) +
  scale_y_continuous(limits=c(-9,9))+
  ggtitle("Multiplicative null model") +
  theme(plot.title = element_text(face = "bold", size = 14,color = "brown", hjust = 0.5,vjust=-9),
    axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 90, size = 12, vjust=0.5), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 12), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") # +  #c(0.1,0.85)  
#coord_flip() flip x and y axis
plot_WE

tiff("plot_WE.tiff", width = 8, height = 4, units = 'in', res = 300, compression = 'none')
plot_WE
dev.off()

plot_EI <- DF %>%
  mutate(Row.names = fct_relevel(Row.names,"Macrophyte","Phytoplankton","Periphyton","Rotifers","Cladocera","Copepoda",
                                 "Insecta","Oligochaeta","Other tiny Snails", "Radix", "Bellamya", "Carp", "Bitterling","Shrimp")) %>%
  ggplot(aes(x= Row.names, y = HedgesdMultiplicative_EI,color = interaction_EI))+
  geom_hline(yintercept = 0, linetype="solid", color = "grey75",size =1.5) +
  geom_point(size = 4)+ 
  geom_errorbar(aes(ymin=HedgesdMultiplicative_EI-CI_EI, ymax=HedgesdMultiplicative_EI+CI_EI),size=2, width = .2,position=position_dodge())+
  scale_color_manual(values = c("black","red","blue"))+
  ylab("N*I") + labs (x = expression(bold(Species))) +
  scale_y_continuous(limits=c(-9,9))+
  ggtitle("Multiplicative null model") +
  theme(plot.title = element_text(face = "bold", size = 14,color = "brown", hjust = 0.5,vjust=-9),
    axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 90, size = 12, vjust=0.5), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 12), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") # +  #c(0.1,0.85)  
#coord_flip() flip x and y axis
plot_EI

tiff("plot_EI.tiff", width = 8, height = 4, units = 'in', res = 300, compression = 'none')
plot_EI
dev.off()

plot_WEI <- DF %>%
  mutate(Row.names = fct_relevel(Row.names,"Macrophyte","Phytoplankton","Periphyton","Rotifers","Cladocera","Copepoda",
                                 "Insecta","Oligochaeta","Other tiny Snails", "Radix", "Bellamya", "Carp", "Bitterling","Shrimp")) %>%
  ggplot(aes(x= Row.names, y = HedgesdMultiplicative_WEI,color = interaction_WEI))+
  geom_hline(yintercept = 0, linetype="solid", color = "grey75",size =1.5) +
  geom_point(size = 4)+ 
  geom_errorbar(aes(ymin=HedgesdMultiplicative_WEI-CI_WEI, ymax=HedgesdMultiplicative_WEI+CI_WEI),size=2, width = .2,position=position_dodge())+
  scale_color_manual(values = c("black","red","blue"))+
  ylab("W*N*I") + labs (x = expression(bold(Species))) +
  #scale_y_continuous(limits=c(-9,9))+
  ggtitle("Multiplicative null model") +
  theme(plot.title = element_text(face = "bold", size = 14,color = "brown", hjust = 0.5,vjust=-9),
    axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 90, size = 12, vjust=0.5), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 12), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") # +  #c(0.1,0.85)  
#coord_flip() flip x and y axis
plot_WEI

tiff("plot_WEI.tiff", width = 8, height = 4, units = 'in', res = 300, compression = 'none')
plot_WEI
dev.off()


#6.0 Dominance null model####
#6.1 WI {calculate null model predictions for stressor pair W and I}####

####Calculate Dominance null model prediction for each row
DF <- DF %>% mutate(DominanceNullModel_WI =ifelse(abs(mean_W_0_0 - mean_0_0_0)>abs(mean_0_0_I- mean_0_0_0),mean_W_0_0,mean_0_0_I))

#{calculate null model predictions for stressor pair W and I}

####Generate variables for effect size calculations
#There are 6 reps and  the standard equation for stressor 1 and pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_WI = sqrt(((5*(SD_W_0_0)^2) + 5*(SD_0_0_I)^2 ) / (6+6-2))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate( j = (1-(3 / (4*(6+(n_p)-2)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_WI = sqrt( ( ((6-1)*(SD_W_0_I)^2) +((n_p)-1)*(Sd_p_WI)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for Dominance null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdDominance_WI = ((mean_W_0_I -  DominanceNullModel_WI) / s_WI) * j )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdDominance_WI = ifelse (DominanceNullModel_WI - mean_0_0_0 < 0, -HedgesdDominance_WI, HedgesdDominance_WI) )

#Vd - the variance around each interaction effect size for Dominance
DF <- DF %>% mutate ( VdDominance_WI = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdDominance_WI)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is Dominance or non-Dominance}
#It is likely to be Dominance with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_WI = sqrt(VdDominance_WI))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 24)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_WI = SE_WI*T_value)
DF <- DF %>% mutate (upper_WI = HedgesdDominance_WI+CI_WI)
DF <- DF %>% mutate (lower_WI = HedgesdDominance_WI-CI_WI)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (interaction_WI = case_when(upper_WI>0 & lower_WI<0 ~ "Additive", upper_WI>0 & lower_WI>0 ~ 'Synergistic', upper_WI<0 & lower_WI<0 ~ 'Antagonistic'))

#6.2 EI {calculate null model predictions for stressor pair E and I}####

#Here I have focused on the stressors coded as E and I. You will need to run it again for other stressor pair combinations

####Calculate Dominance null model prediction for each row
DF <- DF %>% mutate(DominanceNullModel_EI = ifelse(abs(mean_0_N_0 - mean_0_0_0)>abs(mean_0_0_I- mean_0_0_0),mean_0_N_0,mean_0_0_I))

#{calculate null model predictions for stressor pair W and I}

####Generate variables for effect size calculations
#There are 6 reps and  the standard equation for stressor 1 and pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_EI = sqrt(((5*(SD_0_N_0)^2) + 5*(SD_0_0_I)^2 ) / (6+6-2))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate( j = (1-(3 / (4*(6+(n_p)-2)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_EI = sqrt( ( ((6-1)*(SD_0_E_I)^2) +((n_p)-1)*(Sd_p_EI)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for Dominance null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdDominance_EI = ((mean_0_E_I -  DominanceNullModel_EI) / s_EI) * j )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdDominance_EI = ifelse (DominanceNullModel_EI - mean_0_0_0 < 0, -HedgesdDominance_EI, HedgesdDominance_EI) )

#Vd - the variance around each interaction effect size for Dominance
DF <- DF %>% mutate ( VdDominance_EI = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdDominance_EI)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is Dominance or non-Dominance}
#It is likely to be Dominance with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_EI = sqrt(VdDominance_EI))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 24)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_EI = SE_EI*T_value)
DF <- DF %>% mutate (upper_EI = HedgesdDominance_EI+CI_EI)
DF <- DF %>% mutate (lower_EI = HedgesdDominance_EI-CI_EI)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (interaction_EI = case_when(upper_EI>0 & lower_EI<0 ~ "Additive", upper_EI>0 & lower_EI>0 ~ 'Synergistic', upper_EI<0 & lower_EI<0 ~ 'Antagonistic'))


#6.3 WE {calculate null model predictions for stressor pair W and E}####

#Here I have focused on the stressors coded as W and E. You will need to run it again for other stressor pair combinations

####Calculate Dominance null model prediction for each row
DF <- DF %>% mutate(DominanceNullModel_WE = ifelse(abs(mean_0_N_0 - mean_0_0_0)>abs(mean_W_0_0- mean_0_0_0),mean_0_N_0,mean_W_0_0))

#{calculate null model predictions for stressor pair W and I}

####Generate variables for effect size calculations
#There are 6 reps and  the standard equation for stressor 1 and pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_WE = sqrt(((5*(SD_W_0_0)^2) + 5*(SD_0_N_0)^2 ) / (6+6-2))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate( j = (1-(3 / (4*(6+(n_p)-2)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_WE = sqrt( ( ((6-1)*(SD_W_N_0)^2) +((n_p)-1)*(Sd_p_WE)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for Dominance null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdDominance_WE = ((mean_W_N_0 -  DominanceNullModel_WE) / s_WE) * j )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdDominance_WE = ifelse (DominanceNullModel_WE - mean_0_0_0 < 0, -HedgesdDominance_WE, HedgesdDominance_WE) )

#Vd - the variance around each interaction effect size for Dominance
DF <- DF %>% mutate ( VdDominance_WE = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdDominance_WE)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is Dominance or non-Dominance}
#It is likely to be Dominance with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_WE = sqrt(VdDominance_WE))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 24)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_WE = SE_WE*T_value)
DF <- DF %>% mutate (upper_WE = HedgesdDominance_WE+CI_WE)
DF <- DF %>% mutate (lower_WE = HedgesdDominance_WE-CI_WE)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (interaction_WE = case_when(upper_WE>0 & lower_WE<0 ~ "Additive", upper_WE>0 & lower_WE>0 ~ 'Synergistic', upper_WE<0 & lower_WE<0 ~ 'Antagonistic'))

#6.4 WEI {calculate null model predictions for three stressors}####

####Calculate Dominance null model prediction for each row
#DF <- DF %>% mutate(DominanceNullModel_WEI = max(abs(mean_0_N_0 - mean_0_0_0),abs(mean_W_0_0- mean_0_0_0),abs(mean_0_0_I- mean_0_0_0)))
# 计算每一列和 D 列的差异
diffs <- abs(DF[, c("mean_0_N_0", "mean_W_0_0", "mean_0_0_I")] - DF[, "mean_0_0_0"])

# 找出最大的差异所在的列
max_col <- names(diffs)[which.max(colSums(diffs))]

# 将最大差异的列复制到新的 E 列
DF$DominanceNullModel_WEI <- DF[, max_col]

#{calculate null model predictions for stressor pair W,E and I}

####Generate variables for effect size calculations
#There are 6 reps and  the standard equation for stressor 1 and pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_WEI = sqrt(((5*(SD_W_0_0)^2) + 5*(SD_0_N_0)^2 + 5*(SD_0_0_I)^2 ) / (6+6+6-3))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate( j_WEI = (1-(3 / (4*(6+6+(n_p)-3)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_WEI = sqrt( ( ((6-1)*(SD_W_N_I)^2) +((n_p)-1)*(Sd_p_WEI)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for Dominance null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdDominance_WEI = ((mean_W_N_I -  DominanceNullModel_WEI) / s_WEI) * j_WEI )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdDominance_WEI = ifelse (DominanceNullModel_WEI - mean_0_0_0 < 0, -HedgesdDominance_WEI, HedgesdDominance_WEI) )

#Vd - the variance around each interaction effect size for Dominance
DF <- DF %>% mutate ( VdDominance_WEI = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdDominance_WEI)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is additive or non-additive}
#It is likely to be additive with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_WEI = sqrt(VdDominance_WEI))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 30)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_WEI = SE_WEI*T_value)
DF <- DF %>% mutate (upper_WEI = HedgesdDominance_WEI+CI_WEI)
DF <- DF %>% mutate (lower_WEI = HedgesdDominance_WEI-CI_WEI)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (interaction_WEI = case_when(upper_WEI>0 & lower_WEI<0 ~ "Additive", upper_WEI>0 & lower_WEI>0 ~ 'Synergistic', upper_WEI<0 & lower_WEI<0 ~ 'Antagonistic'))

#6.5 plot ####
DF$Row.names <- as.factor(DF$Row.names)
DF$interaction_WI <- as.factor(DF$interaction_WI)

DF <- DF %>% mutate(Row.names=recode(Row.names, Phytoplankton_B_Count= 'Phytoplankton',Periphyton_B_Count='Periphyton',
                                     Copepoda_B='Copepoda', Cladocera_B='Cladocera', Rotifers_B='Rotifers',
                                     Insecta_B ='Insecta', Oligochaeta_B='Oligochaeta',Snail_Other_B='Other tiny Snails',
                                     Radix_B= 'Radix', Bellamya_B='Bellamya',
                                     Carp_B= 'Carp', Rhodeus_B='Bitterling',Shrimp_B='Shrimp'))


library(ggplot2)
plot_WI <- DF %>%
  mutate(Row.names = fct_relevel(Row.names,"Macrophyte","Phytoplankton","Periphyton","Rotifers","Cladocera","Copepoda",
                                 "Insecta","Oligochaeta","Other tiny Snails", "Radix", "Bellamya", "Carp", "Bitterling","Shrimp")) %>%
  ggplot(aes(x= Row.names, y = HedgesdDominance_WI,color = interaction_WI))+
  geom_hline(yintercept = 0, linetype="solid", color = "grey75",size =1.5) +
  geom_point(size = 4)+ 
  geom_errorbar(aes(ymin=HedgesdDominance_WI-CI_WI, ymax=HedgesdDominance_WI+CI_WI),size=2, width = .2,position=position_dodge())+
  scale_color_manual(values = c("black","red","blue"))+
  ylab("W*I") + labs (x = expression(bold(Species))) +
  scale_y_continuous(limits=c(-5,5))+
  ggtitle("Dominance null model") +
  theme(plot.title = element_text(face = "bold", size = 14,color = "brown", hjust = 0.5,vjust=-9),
    axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 90, size = 12, vjust=0.5), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 12), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") # +  #c(0.1,0.85)  
#coord_flip() flip x and y axis
plot_WI

tiff("plot_WI.tiff", width = 8, height = 4, units = 'in', res = 300, compression = 'none')
plot_WI
dev.off()


plot_WE <- DF %>%
  mutate(Row.names = fct_relevel(Row.names,"Macrophyte","Phytoplankton","Periphyton","Rotifers","Cladocera","Copepoda",
                                 "Insecta","Oligochaeta","Other tiny Snails", "Radix", "Bellamya", "Carp", "Bitterling","Shrimp")) %>%
  ggplot(aes(x= Row.names, y = HedgesdDominance_WE,color = interaction_WE))+
  geom_hline(yintercept = 0, linetype="solid", color = "grey75",size =1.5) +
  geom_point(size = 4)+ 
  geom_errorbar(aes(ymin=HedgesdDominance_WE-CI_WE, ymax=HedgesdDominance_WE+CI_WE),size=2, width = .2,position=position_dodge())+
  scale_color_manual(values = c("black","red","blue"))+
  ylab("W*N") + labs (x = expression(bold(Species))) +
  scale_y_continuous(limits=c(-5,5))+
  ggtitle("Dominance null model") +
  theme(plot.title = element_text(face = "bold", size = 14,color = "brown", hjust = 0.5,vjust=-9),
    axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 90, size = 12, vjust=0.5), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 12), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") # +  #c(0.1,0.85)  
#coord_flip() flip x and y axis
plot_WE

tiff("plot_WE.tiff", width = 8, height = 4, units = 'in', res = 300, compression = 'none')
plot_WE
dev.off()

plot_EI <- DF %>%
  mutate(Row.names = fct_relevel(Row.names,"Macrophyte","Phytoplankton","Periphyton","Rotifers","Cladocera","Copepoda",
                                 "Insecta","Oligochaeta","Other tiny Snails", "Radix", "Bellamya", "Carp", "Bitterling","Shrimp")) %>%
  ggplot(aes(x= Row.names, y = HedgesdDominance_EI,color = interaction_EI))+
  geom_hline(yintercept = 0, linetype="solid", color = "grey75",size =1.5) +
  geom_point(size = 4)+ 
  geom_errorbar(aes(ymin=HedgesdDominance_EI-CI_EI, ymax=HedgesdDominance_EI+CI_EI),size=2, width = .2,position=position_dodge())+
  scale_color_manual(values = c("black","red","blue"))+
  ylab("N*I") + labs (x = expression(bold(Species))) +
  scale_y_continuous(limits=c(-5,5))+
  ggtitle("Dominance null model") +
  theme(plot.title = element_text(face = "bold", size = 14,color = "brown", hjust = 0.5,vjust=-9),
    axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 90, size = 12, vjust=0.5), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 12), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") # +  #c(0.1,0.85)  
#coord_flip() flip x and y axis
plot_EI

tiff("plot_EI.tiff", width = 8, height = 4, units = 'in', res = 300, compression = 'none')
plot_EI
dev.off()

plot_WEI <- DF %>%
  mutate(Row.names = fct_relevel(Row.names,"Macrophyte","Phytoplankton","Periphyton","Rotifers","Cladocera","Copepoda",
                                 "Insecta","Oligochaeta","Other tiny Snails", "Radix", "Bellamya", "Carp", "Bitterling","Shrimp")) %>%
  ggplot(aes(x= Row.names, y = HedgesdDominance_WEI,color = interaction_WEI))+
  geom_hline(yintercept = 0, linetype="solid", color = "grey75",size =1.5) +
  geom_point(size = 4)+ 
  geom_errorbar(aes(ymin=HedgesdDominance_WEI-CI_WEI, ymax=HedgesdDominance_WEI+CI_WEI),size=2, width = .2,position=position_dodge())+
  scale_color_manual(values = c("black","red","blue"))+
  ylab("W*N*I") + labs (x = expression(bold(Species))) +
  scale_y_continuous(limits=c(-5,5))+
  ggtitle("Dominance null model") +
  theme(plot.title = element_text(face = "bold", size = 14,color = "brown", hjust = 0.5,vjust=-9),
    axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 90, size = 12, vjust=0.5), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 12), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "none") # +  #c(0.1,0.85)  
#coord_flip() flip x and y axis
plot_WEI

tiff("plot_WEI.tiff", width = 8, height = 4, units = 'in', res = 300, compression = 'none')
plot_WEI
dev.off()
