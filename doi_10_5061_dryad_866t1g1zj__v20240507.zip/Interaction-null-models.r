#Sys.setlocale("LC_ALL", "English")# change locale to English

#load the packages#
#library(nlme)


library(cowplot)
library(grid)
library(car)
library(lme4)
#plot
library(ggplot2)

library(tidyverse)

#0 Data loading####
Final2021<- read.delim("2021Final.txt")

Final2021$Temp <- as.factor(Final2021$Temp)
Final2021$Eutroph <- as.factor(Final2021$Eutroph)
Final2021$Pesticide <- as.factor(Final2021$Pesticide)

#{get summary stats and set up dataframe}


#create treatment column
Final2021 <- Final2021 %>% unite('Treatment', Temp:Pesticide, remove = FALSE)

Final2021$Macrophyte <-Final2021$Hydrilla + Final2021$P.crispus

#mean and error of each column
summary_mean <- Final2021 %>% group_by(Treatment) %>% summarise(across(Hydrilla:Macrophyte, mean, na.rm=TRUE))

summary_SD <- Final2021 %>% group_by(Treatment) %>% summarise(across(Hydrilla:Macrophyte, sd, na.rm=TRUE))                                                              

#transpose and name columns
summary_mean <- as.data.frame(t(summary_mean))
names(summary_mean) <- summary_mean[1,]
summary_mean <- summary_mean[-1,]
summary_mean <- summary_mean %>% rename_with( ~ paste0("mean_", .x))

summary_SD <- as.data.frame(t(summary_SD))
names(summary_SD) <- summary_SD[1,]
summary_SD <- summary_SD[-1,]
summary_SD <- summary_SD %>% rename_with( ~ paste0("SD_", .x))

#merge datasets and ensure as.numeric 
DF <- merge(summary_mean,summary_SD, by="row.names")
DF <- DF %>% mutate_at(vars(2:17), as.numeric)

DF1 <- DF %>% filter(Row.names == "Macrophyte" | Row.names == "Phytoplankton_B"| Row.names == "Periphyton_B"
                     |Row.names == "Copepoda_B"| Row.names == "Cladocera_B" | Row.names == "Rotifers_B"
                     |Row.names == "Insecta_B"| Row.names == "Oligochaeta_B" | Row.names == "Snail_Other_B"| Row.names == "Radix_B" | Row.names == "Bellamya_B"
                     |Row.names == "Carp_B"| Row.names == "Rhodeus_B" | Row.names == "Shrimp_B")#|Row.names == "Predator_Species"

DF <- DF1






#1.1 WI Additive  {calculate null model predictions for stressor pair W and I}####

#Calculate additive null model prediction for each row
DF <- DF %>% mutate(AdditiveNullModel_WI = mean_W_0_0 + mean_0_0_I - mean_0_0_0)
                    
#{calculate null model predictions for stressor pair W and I}
                    
####Generate variables for effect size calculations
#pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_WI = sqrt(((5*(SD_W_0_0)^2) + 5*(SD_0_0_I)^2 ) / (6+6-2))) 
                    
#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)
                    
#j - WNIghting factor based on replicates
DF <- DF %>% mutate(j = (1-(3 / (4*(6+(n_p)-2)-1)) ) )
                    
#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_WI = sqrt( ( ((6-1)*(SD_W_0_I)^2) +((n_p)-1)*(Sd_p_WI)^2 ) / (6+(n_p)-2) ) )
                    
####Calculate hedges d - for additive null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdAdditive_WI = ((mean_W_0_I -  AdditiveNullModel_WI) / s_WI) * j )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdAdditive_WI = ifelse (AdditiveNullModel_WI - mean_0_0_0 < 0, -HedgesdAdditive_WI, HedgesdAdditive_WI) )
                    
#Vd - the variance around each interaction effect size for additive
DF <- DF %>% mutate ( VdAdditive_WI = ( (6+(n_p)) /  (6*(n_p)) ) +  
                                            ( ((HedgesdAdditive_WI)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is additive or non-additive}
                    
DF <- DF %>% mutate (SE_Additive_WI = sqrt(VdAdditive_WI))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 24)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_Additive_WI = SE_Additive_WI*T_value)
DF <- DF %>% mutate (upper_Additive_WI = HedgesdAdditive_WI+CI_Additive_WI)
DF <- DF %>% mutate (lower_Additive_WI = HedgesdAdditive_WI-CI_Additive_WI)
                    
#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (Additive_interaction_WI = case_when(upper_Additive_WI>0 & lower_Additive_WI<0 ~ "Additive", upper_Additive_WI>0 & lower_Additive_WI>0 ~ 'Synergistic', upper_Additive_WI<0 & lower_Additive_WI<0 ~ 'Antagonistic'))


#1.2 WI Multiplicative  {calculate null model predictions for stressor pair W and I}####

####Calculate Multiplicative null model prediction for each row
DF <- DF %>% mutate(MultiplicativeNullModel_WI =(mean_W_0_0 * mean_0_0_I)/ mean_0_0_0)

#{calculate null model predictions for stressor pair W and I}

####Generate variables for effect size calculations
#pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_WI = sqrt(((5*(SD_W_0_0)^2) + 5*(SD_0_0_I)^2 ) / (6+6-2))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate(j = (1-(3 / (4*(6+(n_p)-2)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_WI = sqrt( ( ((6-1)*(SD_W_0_I)^2) +((n_p)-1)*(Sd_p_WI)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for Multiplicative null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdMultiplicative_WI = ((mean_W_0_I -  MultiplicativeNullModel_WI) / s_WI) * j )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdMultiplicative_WI = ifelse (MultiplicativeNullModel_WI - mean_0_0_0 < 0, -HedgesdMultiplicative_WI, HedgesdMultiplicative_WI) )

#Vd - the variance around each interaction effect size for Multiplicative
DF <- DF %>% mutate ( VdMultiplicative_WI = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdMultiplicative_WI)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is Multiplicative or non-Multiplicative}

DF <- DF %>% mutate (SE_Multiplicative_WI = sqrt(VdMultiplicative_WI))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 24)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_Multiplicative_WI = SE_Multiplicative_WI*T_value)
DF <- DF %>% mutate (upper_Multiplicative_WI = HedgesdMultiplicative_WI+CI_Multiplicative_WI)
DF <- DF %>% mutate (lower_Multiplicative_WI = HedgesdMultiplicative_WI-CI_Multiplicative_WI)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (Multiplicative_interaction_WI = case_when(upper_Multiplicative_WI>0 & lower_Multiplicative_WI<0 ~ "Additive", upper_Multiplicative_WI>0 & lower_Multiplicative_WI>0 ~ 'Synergistic', upper_Multiplicative_WI<0 & lower_Multiplicative_WI<0 ~ 'Antagonistic'))


#1.3 WI Dominance  {calculate null model predictions for stressor pair W and I}####

####Calculate Dominance null model prediction for each row
DF <- DF %>% mutate(DominanceNullModel_WI =ifelse(abs(mean_W_0_0 - mean_0_0_0)>abs(mean_0_0_I- mean_0_0_0),mean_W_0_0,mean_0_0_I))

####Generate variables for effect size calculations
#pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_WI = sqrt(((5*(SD_W_0_0)^2) + 5*(SD_0_0_I)^2 ) / (6+6-2))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate(j = (1-(3 / (4*(6+(n_p)-2)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_WI = sqrt( ( ((6-1)*(SD_W_0_I)^2) +((n_p)-1)*(Sd_p_WI)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for Dominance null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdDominance_WI = ((mean_W_0_I -  DominanceNullModel_WI) / s_WI) * j )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdDominance_WI = ifelse (DominanceNullModel_WI - mean_0_0_0 < 0, -HedgesdDominance_WI, HedgesdDominance_WI) )

#Vd - the variance around each interaction effect size for Dominance
DF <- DF %>% mutate ( VdDominance_WI = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdDominance_WI)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is Dominance or non-Dominance}

DF <- DF %>% mutate (SE_Dominance_WI = sqrt(VdDominance_WI))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 24)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_Dominance_WI = SE_Dominance_WI*T_value)
DF <- DF %>% mutate (upper_Dominance_WI = HedgesdDominance_WI+CI_Dominance_WI)
DF <- DF %>% mutate (lower_Dominance_WI = HedgesdDominance_WI-CI_Dominance_WI)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (Dominance_interaction_WI = case_when(upper_Dominance_WI>0 & lower_Dominance_WI<0 ~ "Additive", upper_Dominance_WI>0 & lower_Dominance_WI>0 ~ 'Synergistic', upper_Dominance_WI<0 & lower_Dominance_WI<0 ~ 'Antagonistic'))


#1.4  WI Plot ####
DF_WI_plot <- DF %>% 
  select(c(1,23,28,33,36,41,44)) %>%
  pivot_longer(c('HedgesdAdditive_WI', 'HedgesdMultiplicative_WI', 'HedgesdDominance_WI'), 
               names_to = "Null_models", values_to = "Hedgesd_WI") %>%
  pivot_longer(c('CI_Additive_WI', 'CI_Multiplicative_WI', 'CI_Dominance_WI'), 
               names_to = "Null_models1", values_to = "CI_WI")

DF_WI_plot$Row.names <- as.factor(DF_WI_plot$Row.names)
DF_WI_plot$Null_models <- factor(DF_WI_plot$Null_models, levels = c("HedgesdAdditive_WI","HedgesdMultiplicative_WI","HedgesdDominance_WI"))

DF_WI_plot <- DF_WI_plot %>% mutate(Row.names=recode(Row.names, Phytoplankton_B= 'Phytoplankton',Periphyton_B='Periphyton',
                                     Copepoda_B='Copepoda', Cladocera_B='Cladocera', Rotifers_B='Rotifers',
                                     Insecta_B ='Insecta', Oligochaeta_B='Oligochaeta',Snail_Other_B='Other tiny Snails',
                                     Radix_B= 'Radix', Bellamya_B='Bellamya',
                                     Carp_B= 'Carp', Rhodeus_B='Bitterling',Shrimp_B='Shrimp'))

plot_WI <- DF_WI_plot %>%
  mutate(Row.names = fct_relevel(Row.names,"Macrophyte","Phytoplankton","Periphyton","Rotifers","Cladocera","Copepoda",
                                 "Insecta","Oligochaeta","Other tiny Snails", "Radix", "Bellamya", "Carp", "Bitterling","Shrimp")) %>%
  ggplot(aes(x= Row.names, y = Hedgesd_WI,color = Null_models,group = Null_models))+
  geom_hline(yintercept = 0, linetype="solid", color = "grey75",size =1) +
  geom_point(size = 2,position=position_dodge(0.6))+ 
  geom_errorbar(aes(ymin=Hedgesd_WI-CI_WI, ymax=Hedgesd_WI+CI_WI),size=1, width = 0.2,position=position_dodge(0.6))+
  scale_color_manual(values = c("#008080","#FF6F61","#FFD700"),labels = c("Additive", "Multiplicative", "Dominance"))+
  ylab("W*I") + labs (x = expression(bold(Species))) +
  scale_y_continuous(limits=c(-9,9))+
  #ggtitle("Additive null model") +
  theme(plot.title = element_text(face = "bold", size = 14,color = "brown", hjust = 0.5,vjust=-9),
        axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 90, size = 12, vjust=0.5), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 12), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "top")+ # +  #c(0.1,0.85)  
        labs(color = "Null models")
#coord_flip() flip x and y axis
plot_WI

tiff("plot_WI.tiff", width = 6, height = 4, units = 'in', res = 300, compression = 'none')
plot_WI
dev.off()






#2.1 NI Additive {calculate null model predictions for stressor pair N and I}####

####Calculate additive null model prediction for each row
DF <- DF %>% mutate(AdditiveNullModel_NI = mean_0_N_0 + mean_0_0_I - mean_0_0_0)

#{calculate null model predictions for stressor pair W and I}

####Generate variables for effect size calculations
#There are 6 reps and  the standard equation for stressor 1 and pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_NI = sqrt(((5*(SD_0_N_0)^2) + 5*(SD_0_0_I)^2 ) / (6+6-2))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate( j = (1-(3 / (4*(6+(n_p)-2)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_NI = sqrt( ( ((6-1)*(SD_0_N_I)^2) +((n_p)-1)*(Sd_p_NI)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for additive null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdAdditive_NI = ((mean_0_N_I -  AdditiveNullModel_NI) / s_NI) * j )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdAdditive_NI = ifelse (AdditiveNullModel_NI - mean_0_0_0 < 0, -HedgesdAdditive_NI, HedgesdAdditive_NI) )

#Vd - the variance around each interaction effect size for additive
DF <- DF %>% mutate ( VdAdditive_NI = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdAdditive_NI)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is additive or non-additive}
#It is likely to be additive with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_Additive_NI = sqrt(VdAdditive_NI))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 24)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_Additive_NI = SE_Additive_NI*T_value)
DF <- DF %>% mutate (upper_Additive_NI = HedgesdAdditive_NI+CI_Additive_NI)
DF <- DF %>% mutate (lower_Additive_NI = HedgesdAdditive_NI-CI_Additive_NI)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (Additive_interaction_NI = case_when(upper_Additive_NI>0 & lower_Additive_NI<0 ~ "Additive", upper_Additive_NI>0 & lower_Additive_NI>0 ~ 'Synergistic', upper_Additive_NI<0 & lower_Additive_NI<0 ~ 'Antagonistic'))



#2.2 NI Multiplicative ####
####Calculate Multiplicative null model prediction for each row
DF <- DF %>% mutate(MultiplicativeNullModel_NI = (mean_0_N_0 * mean_0_0_I)/ mean_0_0_0)

DF <- DF %>% mutate(Sd_p_NI = sqrt(((5*(SD_0_N_0)^2) + 5*(SD_0_0_I)^2 ) / (6+6-2))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate( j = (1-(3 / (4*(6+(n_p)-2)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_NI = sqrt( ( ((6-1)*(SD_0_N_I)^2) +((n_p)-1)*(Sd_p_NI)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for Multiplicative null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdMultiplicative_NI = ((mean_0_N_I -  MultiplicativeNullModel_NI) / s_NI) * j )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdMultiplicative_NI = ifelse (MultiplicativeNullModel_NI - mean_0_0_0 < 0, -HedgesdMultiplicative_NI, HedgesdMultiplicative_NI) )

#Vd - the variance around each interaction effect size for Multiplicative
DF <- DF %>% mutate ( VdMultiplicative_NI = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdMultiplicative_NI)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is Multiplicative or non-Multiplicative}
#It is likely to be Multiplicative with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_Multiplicative_NI = sqrt(VdMultiplicative_NI))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 24)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_Multiplicative_NI = SE_Multiplicative_NI*T_value)
DF <- DF %>% mutate (upper_Multiplicative_NI = HedgesdMultiplicative_NI+CI_Multiplicative_NI)
DF <- DF %>% mutate (lower_Multiplicative_NI = HedgesdMultiplicative_NI-CI_Multiplicative_NI)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (Multiplicative_interaction_NI = case_when(upper_Multiplicative_NI>0 & lower_Multiplicative_NI<0 ~ "Additive", upper_Multiplicative_NI>0 & lower_Multiplicative_NI>0 ~ 'Synergistic', upper_Multiplicative_NI<0 & lower_Multiplicative_NI<0 ~ 'Antagonistic'))



#2.3 NI Dominance ####

####Calculate Dominance null model prediction for each row
DF <- DF %>% mutate(DominanceNullModel_NI = ifelse(abs(mean_0_N_0 - mean_0_0_0)>abs(mean_0_0_I- mean_0_0_0),mean_0_N_0,mean_0_0_I))

DF <- DF %>% mutate(Sd_p_NI = sqrt(((5*(SD_0_N_0)^2) + 5*(SD_0_0_I)^2 ) / (6+6-2))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate( j = (1-(3 / (4*(6+(n_p)-2)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_NI = sqrt( ( ((6-1)*(SD_0_N_I)^2) +((n_p)-1)*(Sd_p_NI)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for Dominance null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdDominance_NI = ((mean_0_N_I -  DominanceNullModel_NI) / s_NI) * j )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdDominance_NI = ifelse (DominanceNullModel_NI - mean_0_0_0 < 0, -HedgesdDominance_NI, HedgesdDominance_NI) )

#Vd - the variance around each interaction effect size for Dominance
DF <- DF %>% mutate ( VdDominance_NI = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdDominance_NI)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is Dominance or non-Dominance}
#It is likely to be Dominance with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_Dominance_NI = sqrt(VdDominance_NI))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 24)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_Dominance_NI = SE_Dominance_NI*T_value)
DF <- DF %>% mutate (upper_Dominance_NI = HedgesdDominance_NI+CI_Dominance_NI)
DF <- DF %>% mutate (lower_Dominance_NI = HedgesdDominance_NI-CI_Dominance_NI)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (Dominance_interaction_NI = case_when(upper_Dominance_NI>0 & lower_Dominance_NI<0 ~ "Additive", upper_Dominance_NI>0 & lower_Dominance_NI>0 ~ 'Synergistic', upper_Dominance_NI<0 & lower_Dominance_NI<0 ~ 'Antagonistic'))


# 2.4 NI plot####
DF_NI_plot <- DF %>% 
  select(c(1,51,54,59,62,67,70)) %>%
  pivot_longer(c('HedgesdAdditive_NI', 'HedgesdMultiplicative_NI', 'HedgesdDominance_NI'), 
               names_to = "Null_models", values_to = "Hedgesd_NI") %>%
  pivot_longer(c('CI_Additive_NI', 'CI_Multiplicative_NI', 'CI_Dominance_NI'), 
               names_to = "Null_models1", values_to = "CI_NI")

DF_NI_plot$Row.names <- as.factor(DF_NI_plot$Row.names)
DF_NI_plot$Null_models <- factor(DF_NI_plot$Null_models, levels = c("HedgesdAdditive_NI","HedgesdMultiplicative_NI","HedgesdDominance_NI"))

DF_NI_plot <- DF_NI_plot %>% mutate(Row.names=recode(Row.names, Phytoplankton_B= 'Phytoplankton',Periphyton_B='Periphyton',
                                                     Copepoda_B='Copepoda', Cladocera_B='Cladocera', Rotifers_B='Rotifers',
                                                     Insecta_B ='Insecta', Oligochaeta_B='Oligochaeta',Snail_Other_B='Other tiny Snails',
                                                     Radix_B= 'Radix', Bellamya_B='Bellamya',
                                                     Carp_B= 'Carp', Rhodeus_B='Bitterling',Shrimp_B='Shrimp'))

plot_NI <- DF_NI_plot %>%
  mutate(Row.names = fct_relevel(Row.names,"Macrophyte","Phytoplankton","Periphyton","Rotifers","Cladocera","Copepoda",
                                 "Insecta","Oligochaeta","Other tiny Snails", "Radix", "Bellamya", "Carp", "Bitterling","Shrimp")) %>%
  ggplot(aes(x= Row.names, y = Hedgesd_NI,color = Null_models,group = Null_models))+
  geom_hline(yintercept = 0, linetype="solid", color = "grey75",size =1) +
  geom_point(size = 2,position=position_dodge(0.6))+ 
  geom_errorbar(aes(ymin=Hedgesd_NI-CI_NI, ymax=Hedgesd_NI+CI_NI),size=1, width = 0.2,position=position_dodge(0.6))+
  scale_color_manual(values = c("#008080","#FF6F61","#FFD700"),labels = c("Additive", "Multiplicative", "Dominance"))+
  ylab("N*I") + labs (x = expression(bold(Species))) +
  #scale_y_continuous(limits=c(-9,9))+
  #ggtitle("Additive null model") +
  theme(plot.title = element_text(face = "bold", size = 14,color = "brown", hjust = 0.5,vjust=-9),
        axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 90, size = 12, vjust=0.5), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 12), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "top")+ # +  #c(0.1,0.85)  
  labs(color = "Null models")
#coord_flip() flip x and y axis
plot_NI

tiff("plot_NI.tiff", width = 6, height = 4, units = 'in', res = 300, compression = 'none')
plot_NI
dev.off()




#3.1 WN Additive {calculate null model predictions for stressor pair W and E}####

####Calculate additive null model prediction for each row
DF <- DF %>% mutate(AdditiveNullModel_WN = mean_W_0_0 + mean_0_N_0 - mean_0_0_0)

####Generate variables for effect size calculations
#pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_WN = sqrt(((5*(SD_W_0_0)^2) + 5*(SD_0_N_0)^2 ) / (6+6-2))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - WNighting factor based on replicates
DF <- DF %>% mutate( j = (1-(3 / (4*(6+(n_p)-2)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_WN = sqrt( ( ((6-1)*(SD_W_N_0)^2) +((n_p)-1)*(Sd_p_WN)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for additive null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdAdditive_WN = ((mean_W_N_0 -  AdditiveNullModel_WN) / s_WN) * j )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdAdditive_WN = ifelse (AdditiveNullModel_WN - mean_0_0_0 < 0, -HedgesdAdditive_WN, HedgesdAdditive_WN) )

#Vd - the variance around each interaction effect size for additive
DF <- DF %>% mutate ( VdAdditive_WN = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdAdditive_WN)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is additive or non-additive}
#It is likely to be additive with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_Additive_WN = sqrt(VdAdditive_WN))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 24)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_Additive_WN = SE_Additive_WN*T_value)
DF <- DF %>% mutate (upper_Additive_WN = HedgesdAdditive_WN+CI_Additive_WN)
DF <- DF %>% mutate (lower_Additive_WN = HedgesdAdditive_WN-CI_Additive_WN)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (interaction_Additive_WN = case_when(upper_Additive_WN>0 & lower_Additive_WN<0 ~ "Additive", upper_Additive_WN>0 & lower_Additive_WN>0 ~ 'Synergistic', upper_Additive_WN<0 & lower_Additive_WN<0 ~ 'Antagonistic'))


#3.2 WN Multiplicative {calculate null model predictions for stressor pair W and E}####

####Calculate Multiplicative null model prediction for each row
DF <- DF %>% mutate(MultiplicativeNullModel_WN = (mean_W_0_0 * mean_0_N_0)/mean_0_0_0)

####Generate variables for effect size calculations
#pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_WN = sqrt(((5*(SD_W_0_0)^2) + 5*(SD_0_N_0)^2 ) / (6+6-2))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate( j = (1-(3 / (4*(6+(n_p)-2)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_WN = sqrt( ( ((6-1)*(SD_W_N_0)^2) +((n_p)-1)*(Sd_p_WN)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for Multiplicative null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdMultiplicative_WN = ((mean_W_N_0 -  MultiplicativeNullModel_WN) / s_WN) * j )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdMultiplicative_WN = ifelse (MultiplicativeNullModel_WN - mean_0_0_0 < 0, -HedgesdMultiplicative_WN, HedgesdMultiplicative_WN) )

#Vd - the variance around each interaction effect size for Multiplicative
DF <- DF %>% mutate ( VdMultiplicative_WN = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdMultiplicative_WN)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is Multiplicative or non-Multiplicative}
#It is likely to be Multiplicative with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_Multiplicative_WN = sqrt(VdMultiplicative_WN))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 24)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_Multiplicative_WN = SE_Multiplicative_WN*T_value)
DF <- DF %>% mutate (upper_Multiplicative_WN = HedgesdMultiplicative_WN+CI_Multiplicative_WN)
DF <- DF %>% mutate (lower_Multiplicative_WN = HedgesdMultiplicative_WN-CI_Multiplicative_WN)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (interaction_Multiplicative_WN = case_when(upper_Multiplicative_WN>0 & lower_Multiplicative_WN<0 ~ "Additive", upper_Multiplicative_WN>0 & lower_Multiplicative_WN>0 ~ 'Synergistic', upper_Multiplicative_WN<0 & lower_Multiplicative_WN<0 ~ 'Antagonistic'))


#3.3 WN Dominance####
####Calculate Dominance null model prediction for each row
DF <- DF %>% mutate(DominanceNullModel_WN = ifelse(abs(mean_0_N_0 - mean_0_0_0)>abs(mean_W_0_0- mean_0_0_0),mean_0_N_0,mean_W_0_0))

#pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_WN = sqrt(((5*(SD_W_0_0)^2) + 5*(SD_0_N_0)^2 ) / (6+6-2))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate( j = (1-(3 / (4*(6+(n_p)-2)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_WN = sqrt( ( ((6-1)*(SD_W_N_0)^2) +((n_p)-1)*(Sd_p_WN)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for Dominance null model
#calculate hedges d - difference betWNen observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdDominance_WN = ((mean_W_N_0 -  DominanceNullModel_WN) / s_WN) * j )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdDominance_WN = ifelse (DominanceNullModel_WN - mean_0_0_0 < 0, -HedgesdDominance_WN, HedgesdDominance_WN) )

#Vd - the variance around each interaction effect size for Dominance
DF <- DF %>% mutate ( VdDominance_WN = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdDominance_WN)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is Dominance or non-Dominance}
#It is likely to be Dominance with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_Dominance_WN = sqrt(VdDominance_WN))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 24)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_Dominance_WN = SE_Dominance_WN*T_value)
DF <- DF %>% mutate (upper_Dominance_WN = HedgesdDominance_WN+CI_Dominance_WN)
DF <- DF %>% mutate (lower_Dominance_WN = HedgesdDominance_WN-CI_Dominance_WN)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (interaction_Dominance_WN = case_when(upper_Dominance_WN>0 & lower_Dominance_WN<0 ~ "Additive", upper_Dominance_WN>0 & lower_Dominance_WN>0 ~ 'Synergistic', upper_Dominance_WN<0 & lower_Dominance_WN<0 ~ 'Antagonistic'))


#3.4 WN plot####
DF_WN_plot <- DF %>% 
  select(c(1,77,80,85,88,93,96)) %>%
  pivot_longer(c('HedgesdAdditive_WN', 'HedgesdMultiplicative_WN', 'HedgesdDominance_WN'), 
               names_to = "Null_models", values_to = "Hedgesd_WN") %>%
  pivot_longer(c('CI_Additive_WN', 'CI_Multiplicative_WN', 'CI_Dominance_WN'), 
               names_to = "Null_models1", values_to = "CI_WN")

DF_WN_plot$Row.names <- as.factor(DF_WN_plot$Row.names)
DF_WN_plot$Null_models <- factor(DF_WN_plot$Null_models, levels = c("HedgesdAdditive_WN","HedgesdMultiplicative_WN","HedgesdDominance_WN"))

DF_WN_plot <- DF_WN_plot %>% mutate(Row.names=recode(Row.names, Phytoplankton_B= 'Phytoplankton',Periphyton_B='Periphyton',
                                                     Copepoda_B='Copepoda', Cladocera_B='Cladocera', Rotifers_B='Rotifers',
                                                     Insecta_B ='Insecta', Oligochaeta_B='Oligochaeta',Snail_Other_B='Other tiny Snails',
                                                     Radix_B= 'Radix', Bellamya_B='Bellamya',
                                                     Carp_B= 'Carp', Rhodeus_B='Bitterling',Shrimp_B='Shrimp'))

plot_WN <- DF_WN_plot %>%
  mutate(Row.names = fct_relevel(Row.names,"Macrophyte","Phytoplankton","Periphyton","Rotifers","Cladocera","Copepoda",
                                 "Insecta","Oligochaeta","Other tiny Snails", "Radix", "Bellamya", "Carp", "Bitterling","Shrimp")) %>%
  ggplot(aes(x= Row.names, y = Hedgesd_WN,color = Null_models,group = Null_models))+
  geom_hline(yintercept = 0, linetype="solid", color = "grey75",size =1) +
  geom_point(size = 2,position=position_dodge(0.6))+ 
  geom_errorbar(aes(ymin=Hedgesd_WN-CI_WN, ymax=Hedgesd_WN+CI_WN),size=1, width = 0.2,position=position_dodge(0.6))+
  scale_color_manual(values = c("#008080","#FF6F61","#FFD700"),labels = c("Additive", "Multiplicative", "Dominance"))+
  ylab("W*N") + labs (x = expression(bold(Species))) +
  #scale_y_continuous(limits=c(-9,9))+
  #ggtitle("Additive null model") +
  theme(plot.title = element_text(face = "bold", size = 14,color = "brown", hjust = 0.5,vjust=-9),
        axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 90, size = 12, vjust=0.5), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 12), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "top")+ # +  #c(0.1,0.85)  
  labs(color = "Null models")
#coord_flip() flip x and y axis
plot_WN

tiff("plot_WN.tiff", width = 6, height = 4, units = 'in', res = 300, compression = 'none')
plot_WN
dev.off()





# 4.1 WNI Additive ####
####Calculate additive null model prediction for each row
DF <- DF %>% mutate(AdditiveNullModel_WNI = mean_W_0_0 + mean_0_N_0 + mean_0_0_I - 2*mean_0_0_0)

#{calculate null model predictions for stressor pair W,E and I}

####Generate variables for effect size calculations
#There are 6 reps and  the standard equation for stressor 1 and pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_WNI = sqrt(((5*(SD_W_0_0)^2) + 5*(SD_0_N_0)^2 + 5*(SD_0_0_I)^2 ) / (6+6+6-3))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate( j_WNI = (1-(3 / (4*(6+6+(n_p)-3)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_WNI = sqrt( ( ((6-1)*(SD_W_N_I)^2) +((n_p)-1)*(Sd_p_WNI)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for additive null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdAdditive_WNI = ((mean_W_N_I -  AdditiveNullModel_WNI) / s_WNI) * j_WNI )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdAdditive_WNI = ifelse (AdditiveNullModel_WNI - mean_0_0_0 < 0, -HedgesdAdditive_WNI, HedgesdAdditive_WNI) )

#Vd - the variance around each interaction effect size for additive
DF <- DF %>% mutate ( VdAdditive_WNI = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdAdditive_WNI)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is additive or non-additive}
#It is likely to be additive with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_Additive_WNI = sqrt(VdAdditive_WNI))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 30)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_Additive_WNI = SE_Additive_WNI*T_value)
DF <- DF %>% mutate (upper_Additive_WNI = HedgesdAdditive_WNI+CI_Additive_WNI)
DF <- DF %>% mutate (lower_Additive_WNI = HedgesdAdditive_WNI-CI_Additive_WNI)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (interaction_Additive_WNI = case_when(upper_Additive_WNI>0 & lower_Additive_WNI<0 ~ "Additive", upper_Additive_WNI>0 & lower_Additive_WNI>0 ~ 'Synergistic', upper_Additive_WNI<0 & lower_Additive_WNI<0 ~ 'Antagonistic'))



# 4.2 WNI Multiplicative ####
####Calculate Multiplicative null model prediction for each row
DF <- DF %>% mutate(MultiplicativeNullModel_WNI = (mean_W_0_0 * mean_0_N_0 * mean_0_0_I)/ (mean_0_0_0)^2)

#{calculate null model predictions for stressor pair W,E and I}

####Generate variables for effect size calculations
#There are 6 reps and  the standard equation for stressor 1 and pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_WNI = sqrt(((5*(SD_W_0_0)^2) + 5*(SD_0_N_0)^2 + 5*(SD_0_0_I)^2 ) / (6+6+6-3))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate( j_WNI = (1-(3 / (4*(6+6+(n_p)-3)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_WNI = sqrt( ( ((6-1)*(SD_W_N_I)^2) +((n_p)-1)*(Sd_p_WNI)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for Multiplicative null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdMultiplicative_WNI = ((mean_W_N_I -  MultiplicativeNullModel_WNI) / s_WNI) * j_WNI )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdMultiplicative_WNI = ifelse (MultiplicativeNullModel_WNI - mean_0_0_0 < 0, -HedgesdMultiplicative_WNI, HedgesdMultiplicative_WNI) )

#Vd - the variance around each interaction effect size for Multiplicative
DF <- DF %>% mutate ( VdMultiplicative_WNI = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdMultiplicative_WNI)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is Multiplicative or non-Multiplicative}
#It is likely to be Multiplicative with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_Multiplicative_WNI = sqrt(VdMultiplicative_WNI))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 30)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_Multiplicative_WNI = SE_Multiplicative_WNI*T_value)
DF <- DF %>% mutate (upper_Multiplicative_WNI = HedgesdMultiplicative_WNI+CI_Multiplicative_WNI)
DF <- DF %>% mutate (lower_Multiplicative_WNI = HedgesdMultiplicative_WNI-CI_Multiplicative_WNI)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (interaction_Multiplicative_WNI = case_when(upper_Multiplicative_WNI>0 & lower_Multiplicative_WNI<0 ~ "Additive", upper_Multiplicative_WNI>0 & lower_Multiplicative_WNI>0 ~ 'Synergistic', upper_Multiplicative_WNI<0 & lower_Multiplicative_WNI<0 ~ 'Antagonistic'))



# 4.3 WNI Dominance ####
diffs <- abs(DF[, c("mean_0_N_0", "mean_W_0_0", "mean_0_0_I")] - DF[, "mean_0_0_0"])

max_col <- names(diffs)[which.max(colSums(diffs))]

DF$DominanceNullModel_WNI <- DF[, max_col]

####Generate variables for effect size calculations
#There are 6 reps and  the standard equation for stressor 1 and pooled SD is Sd_p = sqrt((((S1_n-1)*(S1_sd)^2) +((S2_n)-1)*(S2_sd)^2 ) / (S1_n+S2_n-2) ) 
DF <- DF %>% mutate(Sd_p_WNI = sqrt(((5*(SD_W_0_0)^2) + 5*(SD_0_N_0)^2 + 5*(SD_0_0_I)^2 ) / (6+6+6-3))) 

#n_p of null expectation
DF <- DF %>% mutate(n_p = 6)

#j - weighting factor based on replicates
DF <- DF %>% mutate( j_WNI = (1-(3 / (4*(6+6+(n_p)-3)-1)) ) )

#s - pooled standard deviation of predicted and combined responses
DF <- DF %>% mutate(s_WNI = sqrt( ( ((6-1)*(SD_W_N_I)^2) +((n_p)-1)*(Sd_p_WNI)^2 ) / (6+(n_p)-2) ) )

####Calculate hedges d - for Dominance null model
#calculate hedges d - difference between observed interaction and predicted interaction
DF <- DF %>% mutate (HedgesdDominance_WNI = ((mean_W_N_I -  DominanceNullModel_WNI) / s_WNI) * j_WNI )
#Invert the hedges d if effect is negative
DF <- DF %>% mutate ( HedgesdDominance_WNI = ifelse (DominanceNullModel_WNI - mean_0_0_0 < 0, -HedgesdDominance_WNI, HedgesdDominance_WNI) )

#Vd - the variance around each interaction effect size for Dominance
DF <- DF %>% mutate ( VdDominance_WNI = ( (6+(n_p)) /  (6*(n_p)) ) +  
                        ( ((HedgesdDominance_WNI)^2) / (2*( 6+(n_p))  ) ) )

#{code if each response is Dominance or non-Dominance}
#It is likely to be Dominance with a sample size of 6 - we have a paper on this coming out soon

DF <- DF %>% mutate (SE_Dominance_WNI = sqrt(VdDominance_WNI))
#pooled sample size - sum of all reps
DF <- DF %>% mutate (pooled_n = 30)  
#calculate confidence intervals
DF <- DF %>% mutate (T_value= qt(0.95, pooled_n-1)) 
DF <- DF %>% mutate (CI_Dominance_WNI = SE_Dominance_WNI*T_value)
DF <- DF %>% mutate (upper_Dominance_WNI = HedgesdDominance_WNI+CI_Dominance_WNI)
DF <- DF %>% mutate (lower_Dominance_WNI = HedgesdDominance_WNI-CI_Dominance_WNI)

#Give interaction type based on CI crossing 0 or not
DF <- DF %>% mutate (interaction_Dominance_WNI = case_when(upper_Dominance_WNI>0 & lower_Dominance_WNI<0 ~ "Additive", upper_Dominance_WNI>0 & lower_Dominance_WNI>0 ~ 'Synergistic', upper_Dominance_WNI<0 & lower_Dominance_WNI<0 ~ 'Antagonistic'))



# 4.4 WNI plot ####

DF_WNI_plot <- DF %>% 
  select(c(1,104,107,112,115,120,123)) %>%
  pivot_longer(c('HedgesdAdditive_WNI', 'HedgesdMultiplicative_WNI', 'HedgesdDominance_WNI'), 
               names_to = "Null_models", values_to = "Hedgesd_WNI") %>%
  pivot_longer(c('CI_Additive_WNI', 'CI_Multiplicative_WNI', 'CI_Dominance_WNI'), 
               names_to = "Null_models1", values_to = "CI_WNI")

DF_WNI_plot$Row.names <- as.factor(DF_WNI_plot$Row.names)
DF_WNI_plot$Null_models <- factor(DF_WNI_plot$Null_models, levels = c("HedgesdAdditive_WNI","HedgesdMultiplicative_WNI","HedgesdDominance_WNI"))

DF_WNI_plot <- DF_WNI_plot %>% mutate(Row.names=recode(Row.names, Phytoplankton_B= 'Phytoplankton',Periphyton_B='Periphyton',
                                                     Copepoda_B='Copepoda', Cladocera_B='Cladocera', Rotifers_B='Rotifers',
                                                     Insecta_B ='Insecta', Oligochaeta_B='Oligochaeta',Snail_Other_B='Other tiny snails',
                                                     Radix_B= 'Snail Radix', Bellamya_B='Snail Bellamya',
                                                     Carp_B= 'Carp', Rhodeus_B='Bitterling',Shrimp_B='Shrimp'))

plot_WNI <- DF_WNI_plot %>%
  mutate(Row.names = fct_relevel(Row.names,"Macrophyte","Phytoplankton","Periphyton","Rotifers","Cladocera","Copepoda",
                                 "Insecta","Oligochaeta","Other tiny snails", "Snail Radix", "Snail Bellamya", "Carp", "Bitterling","Shrimp")) %>%
  ggplot(aes(x= Row.names, y = Hedgesd_WNI,color = Null_models,group = Null_models))+
  geom_hline(yintercept = 0, linetype="solid", color = "grey75",size =1) +
  geom_point(size = 2,position=position_dodge(0.6))+ 
  geom_errorbar(aes(ymin=Hedgesd_WNI-CI_WNI, ymax=Hedgesd_WNI+CI_WNI),size=1, width = 0.2,position=position_dodge(0.6))+
  scale_color_manual(values = c("#008080","#FF6F61","#FFD700"),labels = c("Additive", "Multiplicative", "Dominance"))+
  ylab("W*N*I") + labs (x = expression(bold(Species))) +
  scale_y_continuous(limits=c(-13,9))+
  #ggtitle("Additive null model") +
  theme(plot.title = element_text(face = "bold", size = 14,color = "brown", hjust = 0.5,vjust=-9),
        axis.title.x = element_text(face = "bold", size = 12), axis.text.x = element_text(angle = 90, size = 12, vjust=0.5), # use element_blank() to close 
        axis.title.y = element_text(face = "bold", size = 12), axis.text.y = element_text(size = 12), #axis.text.x = element_text(angle = 0, vjust=0.5, hjust=0),
        panel.background = element_rect(fill= 0, colour = "black"), # change background color, ( size,linetype, color)
        panel.grid.major = element_blank(), #remove major grid lines,colour, size, linetype,lineend, color
        panel.grid.minor = element_blank(), #remove minor grid lines, colour, size, linetype,lineend, color
        strip.background = element_rect(fill= "white"), strip.placement = "outside", # adjust facet lables
        panel.spacing = unit(0, "lines"), #set panel space
        legend.position = "top")+ # +  #c(0.1,0.85)  
  labs(color = "Null models")
#coord_flip() flip x and y axis
plot_WNI

tiff("plot_WNI.tiff", width = 6, height = 4, units = 'in', res = 300, compression = 'none')
plot_WNI
dev.off()

#5. Align biomass interaction plots####

# Modify plot_WE to keep only the legend
plot_WE <- plot_WE + theme(legend.position = "none", axis.title.x = element_blank(),  axis.text.x = element_blank())

plot_WI <- plot_WI + theme(legend.position = "none", axis.title.x = element_blank(),  axis.text.x = element_blank())

plot_EI <- plot_EI + theme(legend.position = "none", axis.title.x = element_blank(),  axis.text.x = element_blank())

plot_WNI <- plot_WNI + theme(legend.position = "none", axis.title.x = element_blank(),  axis.text.x = element_blank())

Biomassinterplot <- plot_grid(plot_WE,plot_WI, plot_EI,plot_WNI, align = "v", nrow = 4)

Biomassinterplot

tiff("Biomassinterplot.tiff", width = 6, height = 8, units = 'in', res = 300, compression = 'none')
Biomassinterplot
dev.off()
