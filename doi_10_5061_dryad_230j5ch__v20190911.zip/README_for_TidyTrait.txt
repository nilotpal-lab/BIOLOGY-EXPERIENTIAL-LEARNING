Code for analyses involving this data sets is available on github (https://github.com/jcdterry/BCI_Seed_Predator).

***TidyTrait.csv*** � Data on selected traits of the plant species. For details see Appendix S2
Codigo: 4-letter species code of host plant species 
Old_Plant_Species: Plant species name prior to update of nomenclature
TotUnits_collected: Number of seeds or fruits collected for insect rearing
Lifeform: Life form of plant species
Freestanding: Free-standing or non-freestanding life form
Woody_or_nonwoody: Woody or non-woody plant species
seed_dry: Dry seed mass (g) 
fruitrecord: Counts of seeds falling into seed traps during the period between January 1987 and October 2010
cvseed: Variable reflecting interannual variation in seed crop sizes
RGR_10: Relative growth rate of saplings
Tot_dissected: Number of seeds dissected at the end of the rearing period
Tot_predated: Number of dissected seeds scored as predated by insects
SeedPredationRate: Proportion of dissected seeds scored as predated by insects
Code6: Alternative (6-letter) plant species code
Family: Plant family
Plant_species19: Current plant species name (valid in January 2019)
Genus19: Current plant genus name (valid in January 2019)
Specific19: Current specific epithet (valid in January 2019)
Var19: Current variety name (valid in January 2019)
Tree_or_Liana: Tree or liana
Coleo_n: Number of Coleopteran seed predator species reared from this plant species 
Hymeno_n: Number of Hymenopteran seed predator species reared from this plant species 
Lepid_n: Number of Lepidopteran seed predator species reared from this plant species 
Coleo_pres: Coleopteran seed predators reared from this species (yes=1, no=0)
Hymeno_pres: Hymenopteran seed predators reared from this species (yes=1, no=0)
Lepid_pres: Lepidopteran seed predators reared from this species (yes=1, no=0)
SeedPred_n: Total number of seed predator species (all orders combined) reared from this plant species
SeedPred_pres: Seed predator species reared from this plant species (yes=1, no=0)
SpInGenusOnBCI: Number of species within the plant genus recorded on BCI
SpInFamilyOnBCI: Number of species within the plant family recorded on BCI
HEIGHT_AVG: Average height of the 5 tallest tree individuals in the 50 ha forest dynamics plot (for free-standing species only)
BCIReproductive: Number of reproductive-sized individuals in the 50ha plot (for free-standing species only)
Endocarp_investment: Protective tissue content (a measure of the investment in mechanical seed defences)
POLY_concentration: Mean overall concentration of polyphenols in seeds
FruitSeason: Fruiting season (wet season or dry season) based on mean date of fruit fall
CoFruit: Overlap in fruit production by other species
