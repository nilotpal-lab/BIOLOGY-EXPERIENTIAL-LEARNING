Code for analyses involving this data set is available on github (https://github.com/jcdterry/BCI_Seed_Predator).

***Insect data.csv*** � List of all observed predator � prey interactions
InsectSpCode: Numeric species code
FullSpeciesNameValid: Species name (where known) or species code
Codigo: 4-letter species code of host plant species (for species names, see Table S1)
BIN: Barcode Index Number of insect species
Alias: Project-specific code for each insect species � plant species interaction (used prior to identification of insects by taxonomic experts)
TOTAL: Number of times the predator � prey interaction was observed
Order: Insect order
Family: Insect family
Genus: Insect genus
In50haPlotTraps: Indicates whether seeds/fruits of the host plant species have been observed in seed traps in 50ha forest dynamics plot (Yes/No)
IncludeInFoodWeb: Indicates whether the interaction was included in the food web or not
ReasonNotIncluded: Indicates reason for why an interaction was not included in the food web
SeedEquiv_rearing: Number of seeds collected for insect rearing
InsectsPerPredatedSeed: Average number of insect individuals emerging from each infested seed
Seedeqv_traps_c1: Number of �seed equivalents� recorded across the network of seed traps in the 50ha forest dynamics plot  
AbsKilled_collected: Number of collected seeds predated by the seed predator species
PropKilled_collected: Proportion of seeds collected for seed predator rearing that were killed by the seed predator species
KilledAcross200traps_c1: Estimated number of seeds falling into network of seed traps killed by the seed predator
KilledPerTrap_c1: Estimated average number of predated seeds per trap (each trap is 0.5m2 in size)
KilledPerM2: Estimated number of seeds killed per m2