Code for analyses involving this data set is available on github (https://github.com/jcdterry/BCI_Seed_Predator).

***FW.csv*** - Data set used for quantitative food web construction
InsectSpCode: Numeric insect species code
FullSpeciesNameValid: Binomial insect species name (where known) or species code
Codigo: 4-letter species code of host plant species (for plant species names, see Table S1)
Order: Insect order
Family: Insect family
InsectGenus: Insect genus
TOTAL: Number of times the predator � prey interaction was observed
KilledPerM2: Estimated number of seeds killed per m2   